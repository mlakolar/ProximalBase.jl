	.file	"copyto!"
	.section	.ltext,"axl",@progbits
	.globl	"julia_copyto!_787"             # -- Begin function julia_copyto!_787
	.p2align	4
	.type	"julia_copyto!_787",@function
"julia_copyto!_787":                    # @"julia_copyto!_787"
; Function Signature: copyto!(ProximalBase.BlockIterate{Float32, Array{Base.StepRange{Int64, Int64}, 1}}, ProximalBase.BlockIterate{Float32, Array{Base.StepRange{Int64, Int64}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: copyto!:dest <- [$rdi+0]
	#DEBUG_VALUE: copyto!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r13
	push	r12
	push	rbx
	sub	rsp, 40
	vxorps	xmm0, xmm0, xmm0
	vmovaps	xmmword ptr [rbp - 64], xmm0
	mov	qword ptr [rbp - 48], 0
	#APP
	mov	rax, qword ptr fs:[0]
	#NO_APP
	mov	r14, qword ptr [rax - 8]
	mov	qword ptr [rbp - 64], 4
	mov	rax, qword ptr [r14]
	mov	qword ptr [rbp - 56], rax
	lea	rax, [rbp - 64]
	mov	qword ptr [r14], rax
	cmp	rdi, rsi
	je	.LBB0_18
# %bb.1:                                # %L4
	mov	rax, qword ptr [rdi]
	mov	rax, qword ptr [rax + 16]
	mov	rcx, qword ptr [rsi]
	cmp	rax, qword ptr [rcx + 16]
	jne	.LBB0_27
# %bb.2:                                # %L12
	mov	r8, qword ptr [rsi + 8]
	cmp	qword ptr [rdi + 8], r8
	je	.LBB0_26
# %bb.3:                                # %L18
	mov	rax, qword ptr [rdi + 24]
	movabs	rcx, offset jl_nothing
	cmp	rax, qword ptr [rcx]
	je	.LBB0_8
# %bb.4:                                # %L22
	mov	rcx, qword ptr [rsi + 24]
	cmp	rax, rcx
	je	.LBB0_26
# %bb.5:                                # %guard_pass
	mov	rdx, qword ptr [rax - 8]
	and	rdx, -16
	mov	r9, qword ptr [rcx - 8]
	and	r9, -16
	cmp	rdx, r9
	jne	.LBB0_8
# %bb.6:                                # %L27
	movabs	r8, offset jl_egal__unboxed
	mov	rbx, rdi
	mov	rdi, rax
	mov	r15, rsi
	mov	rsi, rcx
	call	r8
	mov	rsi, r15
	mov	rdi, rbx
	test	al, 1
	jne	.LBB0_26
# %bb.7:                                # %L27.L30_crit_edge
	mov	rax, qword ptr [rdi + 24]
	mov	r8, qword ptr [rsi + 8]
.LBB0_8:                                # %L30
	cmp	rax, r8
	je	.LBB0_26
# %bb.9:                                # %L35
	mov	rcx, qword ptr [rdi + 8]
	cmp	qword ptr [rsi + 24], rcx
	je	.LBB0_26
# %bb.10:                               # %L35.L42_crit_edge
	mov	rax, qword ptr [r8 + 16]
	cmp	qword ptr [rcx + 16], rax
	jne	.LBB0_17
# %bb.11:                               # %L61
	test	rax, rax
	je	.LBB0_26
# %bb.12:                               # %L96
	mov	rcx, qword ptr [rcx]
	mov	qword ptr [rbp - 72], rcx       # 8-byte Spill
	mov	rdx, qword ptr [r8]
	dec	rax
	mov	r8d, 16
	.p2align	4
.LBB0_13:                               # %L150
                                        # =>This Inner Loop Header: Depth=1
	mov	rcx, qword ptr [rbp - 72]       # 8-byte Reload
	mov	r9, qword ptr [rcx + r8]
	mov	r15, qword ptr [rcx + r8 - 16]
	mov	r11, qword ptr [rcx + r8 - 8]
	test	r11, r11
	setg	r13b
	mov	r10, qword ptr [rdx + r8]
	mov	rbx, qword ptr [rdx + r8 - 16]
	mov	r12, qword ptr [rdx + r8 - 8]
	cmp	r15, r9
	setge	cl
	je	.LBB0_19
# %bb.14:                               # %L150
                                        #   in Loop: Header=BB0_13 Depth=1
	xor	r13b, cl
	jne	.LBB0_19
# %bb.15:                               # %L167
                                        #   in Loop: Header=BB0_13 Depth=1
	test	r12, r12
	setg	r9b
	cmp	rbx, r10
	setl	cl
	je	.LBB0_17
# %bb.16:                               # %L167
                                        #   in Loop: Header=BB0_13 Depth=1
	xor	r9b, cl
	jne	.LBB0_25
	jmp	.LBB0_17
	.p2align	4
.LBB0_19:                               # %L180
                                        #   in Loop: Header=BB0_13 Depth=1
	cmp	r15, r9
	jne	.LBB0_22
# %bb.20:                               # %L184
                                        #   in Loop: Header=BB0_13 Depth=1
	cmp	rbx, r10
	jne	.LBB0_17
# %bb.21:                               # %L184
                                        #   in Loop: Header=BB0_13 Depth=1
	cmp	r9, rbx
	je	.LBB0_25
	jmp	.LBB0_17
.LBB0_22:                               # %L204
                                        #   in Loop: Header=BB0_13 Depth=1
	cmp	r15, rbx
	jne	.LBB0_17
# %bb.23:                               # %L204
                                        #   in Loop: Header=BB0_13 Depth=1
	cmp	r11, r12
	jne	.LBB0_17
# %bb.24:                               # %L204
                                        #   in Loop: Header=BB0_13 Depth=1
	cmp	r9, r10
	jne	.LBB0_17
.LBB0_25:                               # %L208
                                        #   in Loop: Header=BB0_13 Depth=1
	sub	rax, 1
	jb	.LBB0_26
# %bb.28:                               # %guard_exit161
                                        #   in Loop: Header=BB0_13 Depth=1
	add	r8, 24
	jmp	.LBB0_13
.LBB0_26:                               # %L301
	movabs	rax, offset "j__copy_active!_789"
	call	rax
	mov	rdi, rax
.LBB0_18:                               # %common.ret
	mov	rax, qword ptr [rbp - 56]
	mov	qword ptr [r14], rax
	mov	rax, rdi
	add	rsp, 40
	pop	rbx
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB0_17:                               # %L307
	movabs	rax, offset "j_copyto!_790"
	call	rax
	mov	rdi, rax
	jmp	.LBB0_18
.LBB0_27:                               # %L309
	movabs	rdi, offset ".Ljl_global#793.jit"
	movabs	rax, offset j_DimensionMismatch_792
	call	rax
	mov	rbx, rax
	mov	qword ptr [rbp - 48], rax
	mov	rdi, qword ptr [r14 + 16]
	movabs	rax, offset ijl_gc_small_alloc
	movabs	r14, 136082836598848
	mov	esi, 360
	mov	edx, 16
	mov	rcx, r14
	call	rax
	mov	qword ptr [rax - 8], r14
	mov	qword ptr [rax], rbx
	mov	qword ptr [rbp - 48], 0
	movabs	rcx, offset ijl_throw
	mov	rdi, rax
	call	rcx
.Lfunc_end0:
	.size	"julia_copyto!_787", .Lfunc_end0-"julia_copyto!_787"
                                        # -- End function
.set ".L+Main.Base.DimensionMismatch#794.jit", 136082836598848
	.size	".L+Main.Base.DimensionMismatch#794.jit", 8
.set ".Ljl_global#793.jit", 136082965839056
	.size	".Ljl_global#793.jit", 8
	.section	".note.GNU-stack","",@progbits
