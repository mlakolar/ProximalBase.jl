; Function Signature: _copy_active!(ProximalBase.BlockIterate{Float32, Array{Array{Int64, 1}, 1}}, ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}})
define nonnull ptr @"julia__copy_active!_1155"(ptr noundef nonnull align 8 dereferenceable(56) %"dest::BlockIterate", ptr noundef nonnull align 8 dereferenceable(56) %"src::BlockIterate") local_unnamed_addr #0 {
top:
  %"dest::BlockIterate.nactive_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 48
  %"dest::BlockIterate.nactive" = load i64, ptr %"dest::BlockIterate.nactive_ptr", align 8
  %".dest::BlockIterate.nactive" = call i64 @llvm.smax.i64(i64 %"dest::BlockIterate.nactive", i64 0)
  %0 = icmp slt i64 %"dest::BlockIterate.nactive", 1
  br i1 %0, label %L200, label %L18.preheader

L18.preheader:                                    ; preds = %top
  %"dest::BlockIterate.active_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 32
  %"dest::BlockIterate.active" = load atomic ptr, ptr %"dest::BlockIterate.active_ptr" unordered, align 8
  %memoryref_data = load ptr, ptr %"dest::BlockIterate.active", align 8
  %invariant.gep250 = getelementptr i8, ptr %memoryref_data, i64 -8
  %"src::BlockIterate.position_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 40
  %"src::BlockIterate.position" = load atomic ptr, ptr %"src::BlockIterate.position_ptr" unordered, align 8
  %memoryref_data8 = load ptr, ptr %"src::BlockIterate.position", align 8
  %"dest::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 8
  %"dest::BlockIterate.groups" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %"dest::BlockIterate.storage" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  %"dest::BlockIterate.position_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 40
  %"dest::BlockIterate.position" = load atomic ptr, ptr %"dest::BlockIterate.position_ptr" unordered, align 8
  br label %L18

L18:                                              ; preds = %L170, %L18.preheader
  %value_phi4 = phi i64 [ %22, %L170 ], [ 1, %L18.preheader ]
  %memoryref_offset = shl i64 %value_phi4, 3
  %gep251 = getelementptr i8, ptr %invariant.gep250, i64 %memoryref_offset
  %1 = load i64, ptr %gep251, align 8
  %memoryref_offset10 = shl i64 %1, 3
  %memoryref_byteoffset11 = add i64 %memoryref_offset10, -8
  %memoryref_data16 = getelementptr inbounds i8, ptr %memoryref_data8, i64 %memoryref_byteoffset11
  %2 = load i64, ptr %memoryref_data16, align 8
  %.not = icmp eq i64 %2, 0
  br i1 %.not, label %L60, label %L170

L60:                                              ; preds = %L18
  %memoryref_data18 = load ptr, ptr %"dest::BlockIterate.groups", align 8
  %memoryref_data26 = getelementptr inbounds i8, ptr %memoryref_data18, i64 %memoryref_byteoffset11
  %3 = load atomic ptr, ptr %memoryref_data26 unordered, align 8
  %.not232.not.not = icmp eq ptr %3, null
  br i1 %.not232.not.not, label %fail, label %pass

L112:                                             ; preds = %pass
  %memoryref_data31 = load ptr, ptr %3, align 8
  %4 = load i64, ptr %memoryref_data31, align 8
  %memoryref_data44 = load ptr, ptr %"dest::BlockIterate.storage", align 8
  %invariant.gep = getelementptr i8, ptr %memoryref_data44, i64 -4
  %memoryref_offset46246 = shl i64 %4, 2
  %gep247 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46246
  store i32 0, ptr %gep247, align 4
  %.not234.not248.not = icmp eq i64 %.size_ptr.copyload, 1
  br i1 %.not234.not248.not, label %L170, label %L167.preheader

L167.preheader:                                   ; preds = %L112
  %5 = add i64 %.size_ptr.copyload, -1
  %6 = add i64 %.size_ptr.copyload, -2
  %xtraiter = and i64 %5, 7
  %7 = icmp ult i64 %6, 7
  br i1 %7, label %L170.loopexit.unr-lcssa, label %L167.preheader.new

L167.preheader.new:                               ; preds = %L167.preheader
  %unroll_iter = and i64 %5, -8
  br label %L167

L167:                                             ; preds = %L167, %L167.preheader.new
  %8 = phi i64 [ 1, %L167.preheader.new ], [ %16, %L167 ]
  %value_phi42249 = phi i64 [ 2, %L167.preheader.new ], [ %18, %L167 ]
  %niter = phi i64 [ 0, %L167.preheader.new ], [ %niter.next.7, %L167 ]
  %memoryref_byteoffset63 = shl i64 %8, 3
  %memoryref_data68 = getelementptr inbounds i8, ptr %memoryref_data31, i64 %memoryref_byteoffset63
  %9 = load i64, ptr %memoryref_data68, align 8
  %memoryref_offset46 = shl i64 %9, 2
  %gep = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46
  store i32 0, ptr %gep, align 4
  %memoryref_byteoffset63.1 = shl i64 %value_phi42249, 3
  %memoryref_data68.1 = getelementptr i8, ptr %memoryref_data31, i64 %memoryref_byteoffset63.1
  %10 = load i64, ptr %memoryref_data68.1, align 8
  %memoryref_offset46.1 = shl i64 %10, 2
  %gep.1 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.1
  store i32 0, ptr %gep.1, align 4
  %memoryref_byteoffset63.2 = or disjoint i64 %memoryref_byteoffset63.1, 8
  %memoryref_data68.2 = getelementptr inbounds i8, ptr %memoryref_data31, i64 %memoryref_byteoffset63.2
  %11 = load i64, ptr %memoryref_data68.2, align 8
  %memoryref_offset46.2 = shl i64 %11, 2
  %gep.2 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.2
  store i32 0, ptr %gep.2, align 4
  %memoryref_data68.3 = getelementptr i8, ptr %memoryref_data68.1, i64 16
  %12 = load i64, ptr %memoryref_data68.3, align 8
  %memoryref_offset46.3 = shl i64 %12, 2
  %gep.3 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.3
  store i32 0, ptr %gep.3, align 4
  %memoryref_data68.4 = getelementptr i8, ptr %memoryref_data68.1, i64 24
  %13 = load i64, ptr %memoryref_data68.4, align 8
  %memoryref_offset46.4 = shl i64 %13, 2
  %gep.4 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.4
  store i32 0, ptr %gep.4, align 4
  %memoryref_data68.5 = getelementptr i8, ptr %memoryref_data68.1, i64 32
  %14 = load i64, ptr %memoryref_data68.5, align 8
  %memoryref_offset46.5 = shl i64 %14, 2
  %gep.5 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.5
  store i32 0, ptr %gep.5, align 4
  %memoryref_data68.6 = getelementptr i8, ptr %memoryref_data68.1, i64 40
  %15 = load i64, ptr %memoryref_data68.6, align 8
  %16 = add i64 %value_phi42249, 7
  %memoryref_offset46.6 = shl i64 %15, 2
  %gep.6 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.6
  store i32 0, ptr %gep.6, align 4
  %memoryref_data68.7 = getelementptr i8, ptr %memoryref_data68.1, i64 48
  %17 = load i64, ptr %memoryref_data68.7, align 8
  %18 = add i64 %value_phi42249, 8
  %memoryref_offset46.7 = shl i64 %17, 2
  %gep.7 = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.7
  store i32 0, ptr %gep.7, align 4
  %niter.next.7 = add i64 %niter, 8
  %niter.ncmp.7 = icmp eq i64 %niter.next.7, %unroll_iter
  br i1 %niter.ncmp.7, label %L170.loopexit.unr-lcssa, label %L167

L170.loopexit.unr-lcssa:                          ; preds = %L167, %L167.preheader
  %.unr = phi i64 [ 1, %L167.preheader ], [ %16, %L167 ]
  %value_phi42249.unr = phi i64 [ 2, %L167.preheader ], [ %18, %L167 ]
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %L170, label %L167.epil

L167.epil:                                        ; preds = %L167.epil, %L170.loopexit.unr-lcssa
  %19 = phi i64 [ %value_phi42249.epil, %L167.epil ], [ %.unr, %L170.loopexit.unr-lcssa ]
  %value_phi42249.epil = phi i64 [ %21, %L167.epil ], [ %value_phi42249.unr, %L170.loopexit.unr-lcssa ]
  %epil.iter = phi i64 [ %epil.iter.next, %L167.epil ], [ 0, %L170.loopexit.unr-lcssa ]
  %memoryref_byteoffset63.epil = shl i64 %19, 3
  %memoryref_data68.epil = getelementptr inbounds i8, ptr %memoryref_data31, i64 %memoryref_byteoffset63.epil
  %20 = load i64, ptr %memoryref_data68.epil, align 8
  %21 = add i64 %value_phi42249.epil, 1
  %memoryref_offset46.epil = shl i64 %20, 2
  %gep.epil = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset46.epil
  store i32 0, ptr %gep.epil, align 4
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %L170, label %L167.epil

L170:                                             ; preds = %pass, %L167.epil, %L170.loopexit.unr-lcssa, %L112, %L18
  %memoryref_data73 = load ptr, ptr %"dest::BlockIterate.position", align 8
  %memoryref_data81 = getelementptr inbounds i8, ptr %memoryref_data73, i64 %memoryref_byteoffset11
  store i64 0, ptr %memoryref_data81, align 8
  %.not235 = icmp eq i64 %value_phi4, %".dest::BlockIterate.nactive"
  %22 = add nuw i64 %value_phi4, 1
  br i1 %.not235, label %L200, label %L18

L200:                                             ; preds = %L170, %top
  %"src::BlockIterate.nactive_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 48
  %"src::BlockIterate.nactive" = load i64, ptr %"src::BlockIterate.nactive_ptr", align 8
  %".src::BlockIterate.nactive" = call i64 @llvm.smax.i64(i64 %"src::BlockIterate.nactive", i64 0)
  %23 = icmp slt i64 %"src::BlockIterate.nactive", 1
  br i1 %23, label %L417, label %L217.preheader

L217.preheader:                                   ; preds = %L200
  %"src::BlockIterate.active_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 32
  %"src::BlockIterate.active" = load atomic ptr, ptr %"src::BlockIterate.active_ptr" unordered, align 8
  %memoryref_data92 = load ptr, ptr %"src::BlockIterate.active", align 8
  %"src::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 8
  %"src::BlockIterate.groups" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  %memoryref_data102 = load ptr, ptr %"src::BlockIterate.groups", align 8
  %"src::BlockIterate.storage" = load atomic ptr, ptr %"src::BlockIterate" unordered, align 8
  %"dest::BlockIterate.storage143" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  %"dest::BlockIterate.active_ptr173" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 32
  %"dest::BlockIterate.active174" = load atomic ptr, ptr %"dest::BlockIterate.active_ptr173" unordered, align 8
  %"dest::BlockIterate.position_ptr185" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 40
  %"dest::BlockIterate.position186" = load atomic ptr, ptr %"dest::BlockIterate.position_ptr185" unordered, align 8
  br label %L217

L217:                                             ; preds = %L368, %L217.preheader
  %value_phi89 = phi i64 [ %52, %L368 ], [ 1, %L217.preheader ]
  %memoryref_offset94 = shl i64 %value_phi89, 3
  %memoryref_byteoffset95 = add i64 %memoryref_offset94, -8
  %memoryref_data100 = getelementptr inbounds i8, ptr %memoryref_data92, i64 %memoryref_byteoffset95
  %24 = load i64, ptr %memoryref_data100, align 8
  %memoryref_offset104 = shl i64 %24, 3
  %memoryref_byteoffset105 = add i64 %memoryref_offset104, -8
  %memoryref_data110 = getelementptr inbounds i8, ptr %memoryref_data102, i64 %memoryref_byteoffset105
  %25 = load atomic ptr, ptr %memoryref_data110 unordered, align 8
  %.not236.not.not = icmp eq ptr %25, null
  br i1 %.not236.not.not, label %fail112, label %pass113

L290:                                             ; preds = %pass113
  %memoryref_data121 = load ptr, ptr %25, align 8
  %26 = load i64, ptr %memoryref_data121, align 8
  %memoryref_data134 = load ptr, ptr %"src::BlockIterate.storage", align 8
  %memoryref_data145 = load ptr, ptr %"dest::BlockIterate.storage143", align 8
  %memoryref_offset136252 = add i64 %26, -1
  %memoryref_byteoffset137253 = shl i64 %memoryref_offset136252, 3
  %memoryref_data142254 = getelementptr inbounds i8, ptr %memoryref_data134, i64 %memoryref_byteoffset137253
  %27 = load double, ptr %memoryref_data142254, align 8
  %28 = fptrunc double %27 to float
  %memoryref_byteoffset148255 = shl i64 %memoryref_offset136252, 2
  %memoryref_data153256 = getelementptr inbounds i8, ptr %memoryref_data145, i64 %memoryref_byteoffset148255
  store float %28, ptr %memoryref_data153256, align 4
  %.not238.not257.not = icmp eq i64 %.size_ptr114.copyload, 1
  br i1 %.not238.not257.not, label %L368, label %L365.preheader

L365.preheader:                                   ; preds = %L290
  %29 = add i64 %.size_ptr114.copyload, -1
  %30 = add i64 %.size_ptr114.copyload, -2
  %xtraiter260 = and i64 %29, 3
  %31 = icmp ult i64 %30, 3
  br i1 %31, label %L368.loopexit.unr-lcssa, label %L365.preheader.new

L365.preheader.new:                               ; preds = %L365.preheader
  %unroll_iter264 = and i64 %29, -4
  br label %L365

L365:                                             ; preds = %L365, %L365.preheader.new
  %32 = phi i64 [ 1, %L365.preheader.new ], [ %40, %L365 ]
  %value_phi132258 = phi i64 [ 2, %L365.preheader.new ], [ %44, %L365 ]
  %niter265 = phi i64 [ 0, %L365.preheader.new ], [ %niter265.next.3, %L365 ]
  %memoryref_byteoffset164 = shl i64 %32, 3
  %memoryref_data169 = getelementptr inbounds i8, ptr %memoryref_data121, i64 %memoryref_byteoffset164
  %33 = load i64, ptr %memoryref_data169, align 8
  %memoryref_offset136 = add i64 %33, -1
  %memoryref_byteoffset137 = shl i64 %memoryref_offset136, 3
  %memoryref_data142 = getelementptr inbounds i8, ptr %memoryref_data134, i64 %memoryref_byteoffset137
  %34 = load double, ptr %memoryref_data142, align 8
  %35 = fptrunc double %34 to float
  %memoryref_byteoffset148 = shl i64 %memoryref_offset136, 2
  %memoryref_data153 = getelementptr inbounds i8, ptr %memoryref_data145, i64 %memoryref_byteoffset148
  store float %35, ptr %memoryref_data153, align 4
  %memoryref_byteoffset164.1 = shl i64 %value_phi132258, 3
  %memoryref_data169.1 = getelementptr i8, ptr %memoryref_data121, i64 %memoryref_byteoffset164.1
  %36 = load i64, ptr %memoryref_data169.1, align 8
  %memoryref_offset136.1 = add i64 %36, -1
  %memoryref_byteoffset137.1 = shl i64 %memoryref_offset136.1, 3
  %memoryref_data142.1 = getelementptr inbounds i8, ptr %memoryref_data134, i64 %memoryref_byteoffset137.1
  %37 = load double, ptr %memoryref_data142.1, align 8
  %38 = fptrunc double %37 to float
  %memoryref_byteoffset148.1 = shl i64 %memoryref_offset136.1, 2
  %memoryref_data153.1 = getelementptr inbounds i8, ptr %memoryref_data145, i64 %memoryref_byteoffset148.1
  store float %38, ptr %memoryref_data153.1, align 4
  %memoryref_byteoffset164.2 = or disjoint i64 %memoryref_byteoffset164.1, 8
  %memoryref_data169.2 = getelementptr inbounds i8, ptr %memoryref_data121, i64 %memoryref_byteoffset164.2
  %39 = load i64, ptr %memoryref_data169.2, align 8
  %40 = add i64 %value_phi132258, 3
  %memoryref_offset136.2 = add i64 %39, -1
  %memoryref_byteoffset137.2 = shl i64 %memoryref_offset136.2, 3
  %memoryref_data142.2 = getelementptr inbounds i8, ptr %memoryref_data134, i64 %memoryref_byteoffset137.2
  %41 = load double, ptr %memoryref_data142.2, align 8
  %42 = fptrunc double %41 to float
  %memoryref_byteoffset148.2 = shl i64 %memoryref_offset136.2, 2
  %memoryref_data153.2 = getelementptr inbounds i8, ptr %memoryref_data145, i64 %memoryref_byteoffset148.2
  store float %42, ptr %memoryref_data153.2, align 4
  %memoryref_data169.3 = getelementptr i8, ptr %memoryref_data169.1, i64 16
  %43 = load i64, ptr %memoryref_data169.3, align 8
  %44 = add i64 %value_phi132258, 4
  %memoryref_offset136.3 = add i64 %43, -1
  %memoryref_byteoffset137.3 = shl i64 %memoryref_offset136.3, 3
  %memoryref_data142.3 = getelementptr inbounds i8, ptr %memoryref_data134, i64 %memoryref_byteoffset137.3
  %45 = load double, ptr %memoryref_data142.3, align 8
  %46 = fptrunc double %45 to float
  %memoryref_byteoffset148.3 = shl i64 %memoryref_offset136.3, 2
  %memoryref_data153.3 = getelementptr inbounds i8, ptr %memoryref_data145, i64 %memoryref_byteoffset148.3
  store float %46, ptr %memoryref_data153.3, align 4
  %niter265.next.3 = add i64 %niter265, 4
  %niter265.ncmp.3 = icmp eq i64 %niter265.next.3, %unroll_iter264
  br i1 %niter265.ncmp.3, label %L368.loopexit.unr-lcssa, label %L365

L368.loopexit.unr-lcssa:                          ; preds = %L365, %L365.preheader
  %.unr262 = phi i64 [ 1, %L365.preheader ], [ %40, %L365 ]
  %value_phi132258.unr = phi i64 [ 2, %L365.preheader ], [ %44, %L365 ]
  %lcmp.mod263.not = icmp eq i64 %xtraiter260, 0
  br i1 %lcmp.mod263.not, label %L368, label %L365.epil

L365.epil:                                        ; preds = %L365.epil, %L368.loopexit.unr-lcssa
  %47 = phi i64 [ %value_phi132258.epil, %L365.epil ], [ %.unr262, %L368.loopexit.unr-lcssa ]
  %value_phi132258.epil = phi i64 [ %49, %L365.epil ], [ %value_phi132258.unr, %L368.loopexit.unr-lcssa ]
  %epil.iter261 = phi i64 [ %epil.iter261.next, %L365.epil ], [ 0, %L368.loopexit.unr-lcssa ]
  %memoryref_byteoffset164.epil = shl i64 %47, 3
  %memoryref_data169.epil = getelementptr inbounds i8, ptr %memoryref_data121, i64 %memoryref_byteoffset164.epil
  %48 = load i64, ptr %memoryref_data169.epil, align 8
  %49 = add i64 %value_phi132258.epil, 1
  %memoryref_offset136.epil = add i64 %48, -1
  %memoryref_byteoffset137.epil = shl i64 %memoryref_offset136.epil, 3
  %memoryref_data142.epil = getelementptr inbounds i8, ptr %memoryref_data134, i64 %memoryref_byteoffset137.epil
  %50 = load double, ptr %memoryref_data142.epil, align 8
  %51 = fptrunc double %50 to float
  %memoryref_byteoffset148.epil = shl i64 %memoryref_offset136.epil, 2
  %memoryref_data153.epil = getelementptr inbounds i8, ptr %memoryref_data145, i64 %memoryref_byteoffset148.epil
  store float %51, ptr %memoryref_data153.epil, align 4
  %epil.iter261.next = add i64 %epil.iter261, 1
  %epil.iter261.cmp.not = icmp eq i64 %epil.iter261.next, %xtraiter260
  br i1 %epil.iter261.cmp.not, label %L368, label %L365.epil

L368:                                             ; preds = %pass113, %L365.epil, %L368.loopexit.unr-lcssa, %L290
  %memoryref_data176 = load ptr, ptr %"dest::BlockIterate.active174", align 8
  %memoryref_data184 = getelementptr inbounds i8, ptr %memoryref_data176, i64 %memoryref_byteoffset95
  store i64 %24, ptr %memoryref_data184, align 8
  %memoryref_data188 = load ptr, ptr %"dest::BlockIterate.position186", align 8
  %memoryref_data196 = getelementptr inbounds i8, ptr %memoryref_data188, i64 %memoryref_byteoffset105
  store i64 %value_phi89, ptr %memoryref_data196, align 8
  %.not239 = icmp eq i64 %value_phi89, %".src::BlockIterate.nactive"
  %52 = add nuw i64 %value_phi89, 1
  br i1 %.not239, label %L417, label %L217

L417:                                             ; preds = %L368, %L200
  store i64 %"src::BlockIterate.nactive", ptr %"dest::BlockIterate.nactive_ptr", align 8
  ret ptr %"dest::BlockIterate"

fail:                                             ; preds = %L60
  %jl_undefref_exception = load ptr, ptr @jl_undefref_exception, align 8
  call void @ijl_throw(ptr nonnull %jl_undefref_exception)
  unreachable

pass:                                             ; preds = %L60
  %.size_ptr = getelementptr inbounds nuw i8, ptr %3, i64 16
  %.size_ptr.copyload = load i64, ptr %.size_ptr, align 8
  %.not233 = icmp eq i64 %.size_ptr.copyload, 0
  br i1 %.not233, label %L170, label %L112

fail112:                                          ; preds = %L217
  %jl_undefref_exception111 = load ptr, ptr @jl_undefref_exception, align 8
  call void @ijl_throw(ptr nonnull %jl_undefref_exception111)
  unreachable

pass113:                                          ; preds = %L217
  %.size_ptr114 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %.size_ptr114.copyload = load i64, ptr %.size_ptr114, align 8
  %.not237 = icmp eq i64 %.size_ptr114.copyload, 0
  br i1 %.not237, label %L368, label %L290
}
