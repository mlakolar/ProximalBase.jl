	.file	"_copy_active!"
	.section	.ltext,"axl",@progbits
	.globl	"julia__copy_active!_1166"      # -- Begin function julia__copy_active!_1166
	.p2align	4
	.type	"julia__copy_active!_1166",@function
"julia__copy_active!_1166":             # @"julia__copy_active!_1166"
; Function Signature: _copy_active!(ProximalBase.BlockIterate{Float32, Array{Array{Int64, 1}, 1}}, ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: _copy_active!:dest <- [$rdi+0]
	#DEBUG_VALUE: _copy_active!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r13
	push	r12
	push	rbx
	sub	rsp, 40
	mov	qword ptr [rbp - 48], rsi       # 8-byte Spill
	mov	qword ptr [rbp - 56], rdi       # 8-byte Spill
	mov	rcx, qword ptr [rdi + 48]
	xor	eax, eax
	test	rcx, rcx
	cmovg	rax, rcx
	jle	.LBB0_14
# %bb.1:                                # %L18.preheader
	mov	rsi, qword ptr [rbp - 56]       # 8-byte Reload
	mov	rcx, qword ptr [rsi + 32]
	mov	rcx, qword ptr [rcx]
	mov	rdx, qword ptr [rbp - 48]       # 8-byte Reload
	mov	rdx, qword ptr [rdx + 40]
	mov	rdx, qword ptr [rdx]
	mov	r8, qword ptr [rsi + 8]
	mov	rdi, qword ptr [rsi]
	mov	qword ptr [rbp - 64], rdi       # 8-byte Spill
	mov	r10, qword ptr [rsi + 40]
	mov	r11d, 1
	jmp	.LBB0_2
	.p2align	4
.LBB0_13:                               # %L170
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	rsi, qword ptr [r10]
	mov	qword ptr [rsi + 8*rbx - 8], 0
	lea	rsi, [r11 + 1]
	cmp	r11, rax
	mov	r11, rsi
	je	.LBB0_14
.LBB0_2:                                # %L18
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_9 Depth 2
                                        #     Child Loop BB0_12 Depth 2
	mov	rbx, qword ptr [rcx + 8*r11 - 8]
	cmp	qword ptr [rdx + 8*rbx - 8], 0
	jne	.LBB0_13
# %bb.3:                                # %L60
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	rdi, qword ptr [r8]
	mov	r9, qword ptr [rdi + 8*rbx - 8]
	test	r9, r9
	je	.LBB0_28
# %bb.4:                                # %pass
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	rdi, qword ptr [r9 + 16]
	test	rdi, rdi
	je	.LBB0_13
# %bb.5:                                # %L112
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	r14, qword ptr [r9]
	mov	r9, qword ptr [r14]
	mov	rsi, qword ptr [rbp - 64]       # 8-byte Reload
	mov	r15, qword ptr [rsi]
	mov	dword ptr [r15 + 4*r9 - 4], 0
	cmp	rdi, 1
	je	.LBB0_13
# %bb.6:                                # %L167.preheader
                                        #   in Loop: Header=BB0_2 Depth=1
	lea	r12, [rdi - 1]
	add	rdi, -2
	cmp	rdi, 7
	jae	.LBB0_8
# %bb.7:                                #   in Loop: Header=BB0_2 Depth=1
	mov	r9d, 2
	mov	r13d, 1
	and	r12d, 7
	jne	.LBB0_12
	jmp	.LBB0_13
.LBB0_8:                                # %L167.preheader.new
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	rdi, r12
	and	rdi, -8
	mov	r13d, 1
	mov	r9, -2
	.p2align	4
.LBB0_9:                                # %L167
                                        #   Parent Loop BB0_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	mov	rsi, qword ptr [r14 + 8*r13]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	mov	rsi, qword ptr [r14 + 8*r13 + 8]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	mov	rsi, qword ptr [r14 + 8*r13 + 16]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	mov	rsi, qword ptr [r14 + 8*r13 + 24]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	mov	rsi, qword ptr [r14 + 8*r13 + 32]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	mov	rsi, qword ptr [r14 + 8*r13 + 40]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	mov	rsi, qword ptr [r14 + 8*r13 + 48]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	mov	rsi, qword ptr [r14 + 8*r13 + 56]
	mov	dword ptr [r15 + 4*rsi - 4], 0
	add	r13, 8
	lea	rsi, [rdi + r9]
	add	rsi, -8
	add	r9, -8
	cmp	rsi, -2
	jne	.LBB0_9
# %bb.10:                               # %L170.loopexit.unr-lcssa.loopexit
                                        #   in Loop: Header=BB0_2 Depth=1
	neg	r9
	and	r12d, 7
	je	.LBB0_13
	.p2align	4
.LBB0_12:                               # %L167.epil
                                        #   Parent Loop BB0_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	mov	rsi, qword ptr [r14 + 8*r13]
	mov	r13, r9
	inc	r9
	mov	dword ptr [r15 + 4*rsi - 4], 0
	dec	r12
	jne	.LBB0_12
	jmp	.LBB0_13
.LBB0_14:                               # %L200
	mov	rsi, qword ptr [rbp - 48]       # 8-byte Reload
	mov	rax, qword ptr [rsi + 48]
	xor	ecx, ecx
	test	rax, rax
	mov	qword ptr [rbp - 72], rax       # 8-byte Spill
	cmovg	rcx, rax
	jle	.LBB0_27
# %bb.15:                               # %L217.preheader
	mov	rax, qword ptr [rsi + 32]
	mov	rdx, qword ptr [rax]
	mov	rax, qword ptr [rsi + 8]
	mov	r8, qword ptr [rax]
	mov	rax, qword ptr [rsi]
	mov	qword ptr [rbp - 64], rax       # 8-byte Spill
	mov	rax, qword ptr [rbp - 56]       # 8-byte Reload
	mov	rsi, qword ptr [rax]
	mov	qword ptr [rbp - 48], rsi       # 8-byte Spill
	mov	r10, qword ptr [rax + 32]
	mov	r11, qword ptr [rax + 40]
	mov	ebx, 1
	jmp	.LBB0_16
	.p2align	4
.LBB0_26:                               # %L368
                                        #   in Loop: Header=BB0_16 Depth=1
	mov	rax, qword ptr [r10]
	mov	qword ptr [rax + 8*rbx - 8], r14
	mov	rax, qword ptr [r11]
	mov	qword ptr [rax + 8*r14 - 8], rbx
	lea	rax, [rbx + 1]
	cmp	rbx, rcx
	mov	rbx, rax
	je	.LBB0_27
.LBB0_16:                               # %L217
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_22 Depth 2
                                        #     Child Loop BB0_25 Depth 2
	mov	r14, qword ptr [rdx + 8*rbx - 8]
	mov	rax, qword ptr [r8 + 8*r14 - 8]
	test	rax, rax
	je	.LBB0_29
# %bb.17:                               # %pass113
                                        #   in Loop: Header=BB0_16 Depth=1
	mov	rsi, qword ptr [rax + 16]
	test	rsi, rsi
	je	.LBB0_26
# %bb.18:                               # %L290
                                        #   in Loop: Header=BB0_16 Depth=1
	mov	r15, qword ptr [rax]
	mov	rax, qword ptr [r15]
	mov	rdi, qword ptr [rbp - 64]       # 8-byte Reload
	mov	r12, qword ptr [rdi]
	mov	rdi, qword ptr [rbp - 48]       # 8-byte Reload
	mov	r13, qword ptr [rdi]
	vmovsd	xmm0, qword ptr [r12 + 8*rax - 8] # xmm0 = mem[0],zero
	vcvtsd2ss	xmm0, xmm0, xmm0
	vmovss	dword ptr [r13 + 4*rax - 4], xmm0
	cmp	rsi, 1
	je	.LBB0_26
# %bb.19:                               # %L365.preheader
                                        #   in Loop: Header=BB0_16 Depth=1
	lea	rax, [rsi - 1]
	add	rsi, -2
	cmp	rsi, 3
	jae	.LBB0_21
# %bb.20:                               #   in Loop: Header=BB0_16 Depth=1
	mov	esi, 2
	mov	edi, 1
	and	eax, 3
	jne	.LBB0_25
	jmp	.LBB0_26
.LBB0_21:                               # %L365.preheader.new
                                        #   in Loop: Header=BB0_16 Depth=1
	mov	rdi, rax
	and	rdi, -4
	neg	rdi
	mov	esi, 2
	.p2align	4
.LBB0_22:                               # %L365
                                        #   Parent Loop BB0_16 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	mov	r9, qword ptr [r15 + 8*rsi - 8]
	vmovsd	xmm0, qword ptr [r12 + 8*r9 - 8] # xmm0 = mem[0],zero
	vcvtsd2ss	xmm0, xmm0, xmm0
	vmovss	dword ptr [r13 + 4*r9 - 4], xmm0
	mov	r9, qword ptr [r15 + 8*rsi]
	vmovsd	xmm0, qword ptr [r12 + 8*r9 - 8] # xmm0 = mem[0],zero
	vcvtsd2ss	xmm0, xmm0, xmm0
	vmovss	dword ptr [r13 + 4*r9 - 4], xmm0
	mov	r9, qword ptr [r15 + 8*rsi + 8]
	vmovsd	xmm0, qword ptr [r12 + 8*r9 - 8] # xmm0 = mem[0],zero
	vcvtsd2ss	xmm0, xmm0, xmm0
	vmovss	dword ptr [r13 + 4*r9 - 4], xmm0
	mov	r9, qword ptr [r15 + 8*rsi + 16]
	vmovsd	xmm0, qword ptr [r12 + 8*r9 - 8] # xmm0 = mem[0],zero
	vcvtsd2ss	xmm0, xmm0, xmm0
	vmovss	dword ptr [r13 + 4*r9 - 4], xmm0
	lea	r9, [rdi + rsi]
	add	r9, 4
	add	rsi, 4
	cmp	r9, 2
	jne	.LBB0_22
# %bb.23:                               # %L368.loopexit.unr-lcssa.loopexit
                                        #   in Loop: Header=BB0_16 Depth=1
	lea	rdi, [rsi - 1]
	and	eax, 3
	je	.LBB0_26
	.p2align	4
.LBB0_25:                               # %L365.epil
                                        #   Parent Loop BB0_16 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	mov	r9, qword ptr [r15 + 8*rdi]
	mov	rdi, rsi
	inc	rsi
	vmovsd	xmm0, qword ptr [r12 + 8*r9 - 8] # xmm0 = mem[0],zero
	vcvtsd2ss	xmm0, xmm0, xmm0
	vmovss	dword ptr [r13 + 4*r9 - 4], xmm0
	dec	rax
	jne	.LBB0_25
	jmp	.LBB0_26
.LBB0_27:                               # %L417
	mov	rax, qword ptr [rbp - 56]       # 8-byte Reload
	mov	rcx, qword ptr [rbp - 72]       # 8-byte Reload
	mov	qword ptr [rax + 48], rcx
	add	rsp, 40
	pop	rbx
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB0_29:                               # %fail112
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	movabs	rax, offset ijl_throw
	call	rax
.LBB0_28:                               # %fail
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	movabs	rax, offset ijl_throw
	call	rax
.Lfunc_end0:
	.size	"julia__copy_active!_1166", .Lfunc_end0-"julia__copy_active!_1166"
                                        # -- End function
	.section	".note.GNU-stack","",@progbits
