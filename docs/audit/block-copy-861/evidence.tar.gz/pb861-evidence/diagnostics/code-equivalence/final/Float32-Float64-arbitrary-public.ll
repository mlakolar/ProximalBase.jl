; Function Signature: copyto!(ProximalBase.BlockIterate{Float32, Array{Array{Int64, 1}, 1}}, ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}})
define nonnull ptr @"julia_copyto!_1125"(ptr noundef nonnull align 8 dereferenceable(56) %"dest::BlockIterate", ptr noundef nonnull align 8 dereferenceable(56) %"src::BlockIterate") local_unnamed_addr #0 {
top:
  %gcframe5 = alloca [6 x ptr], align 16
  call void @llvm.memset.p0.i64(ptr align 16 %gcframe5, i8 0, i64 48, i1 true)
  %thread_ptr = call ptr asm "movq %fs:0, $0", "=r"() #14
  %tls_ppgcstack = getelementptr inbounds i8, ptr %thread_ptr, i64 -8
  %tls_pgcstack = load ptr, ptr %tls_ppgcstack, align 8
  store i64 16, ptr %gcframe5, align 8
  %frame.prev = getelementptr inbounds nuw i8, ptr %gcframe5, i64 8
  %task.gcstack = load ptr, ptr %tls_pgcstack, align 8
  store ptr %task.gcstack, ptr %frame.prev, align 8
  store ptr %gcframe5, ptr %tls_pgcstack, align 8
  %"dest::BlockIterate.storage" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  %"dest::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.storage", i64 16
  %"dest::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"dest::BlockIterate.storage.size_ptr", align 8
  %"src::BlockIterate.storage" = load atomic ptr, ptr %"src::BlockIterate" unordered, align 8
  %"src::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate.storage", i64 16
  %"src::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"src::BlockIterate.storage.size_ptr", align 8
  %.not = icmp eq i64 %"dest::BlockIterate.storage.size_ptr.copyload", %"src::BlockIterate.storage.size_ptr.copyload"
  br i1 %.not, label %L10, label %L282

L10:                                              ; preds = %top
  %"dest::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 8
  %"dest::BlockIterate.groups" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %"src::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 8
  %"src::BlockIterate.groups" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  %0 = icmp eq ptr %"dest::BlockIterate.groups", %"src::BlockIterate.groups"
  br i1 %0, label %L274, label %L16

L16:                                              ; preds = %L10
  %"dest::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 24
  %"dest::BlockIterate.layout_cache" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %jl_nothing = load ptr, ptr @jl_nothing, align 8
  %1 = icmp eq ptr %"dest::BlockIterate.layout_cache", %jl_nothing
  br i1 %1, label %L28, label %L20

L20:                                              ; preds = %L16
  %"src::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr" unordered, align 8
  %.not130 = icmp eq ptr %"dest::BlockIterate.layout_cache", %"src::BlockIterate.layout_cache"
  br i1 %.not130, label %L274, label %guard_pass

L25:                                              ; preds = %guard_pass
  %2 = call i32 @jl_egal__unboxed(ptr nonnull %"dest::BlockIterate.layout_cache", ptr nonnull %"src::BlockIterate.layout_cache", i64 %25)
  %3 = trunc i32 %2 to i1
  br i1 %3, label %L274, label %L25.L28_crit_edge

L25.L28_crit_edge:                                ; preds = %L25
  %"dest::BlockIterate.layout_cache117.pre" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %"src::BlockIterate.groups119.pre" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  br label %L28

L28:                                              ; preds = %guard_pass, %L25.L28_crit_edge, %L16
  %gclift209 = phi ptr [ %"src::BlockIterate.groups119.pre", %L25.L28_crit_edge ], [ %"src::BlockIterate.groups", %L16 ], [ %"src::BlockIterate.groups", %guard_pass ]
  %gclift = phi ptr [ %"dest::BlockIterate.layout_cache117.pre", %L25.L28_crit_edge ], [ %"dest::BlockIterate.layout_cache", %L16 ], [ %"dest::BlockIterate.layout_cache", %guard_pass ]
  %4 = icmp eq ptr %gclift, %gclift209
  br i1 %4, label %L274, label %L33

L33:                                              ; preds = %L28
  %"src::BlockIterate.layout_cache_ptr120" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache121" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr120" unordered, align 8
  %"dest::BlockIterate.groups123" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %5 = icmp eq ptr %"src::BlockIterate.layout_cache121", %"dest::BlockIterate.groups123"
  br i1 %5, label %L274, label %L33.L40_crit_edge

L33.L40_crit_edge:                                ; preds = %L33
  %"src::BlockIterate.groups5.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %gclift209, i64 16
  %"src::BlockIterate.groups5.size_ptr.copyload.pre" = load i64, ptr %"src::BlockIterate.groups5.size_ptr.phi.trans.insert", align 8
  %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.groups123", i64 16
  %"dest::BlockIterate.groups3.size_ptr.copyload.pre" = load i64, ptr %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert", align 8
  %.not131 = icmp eq i64 %"dest::BlockIterate.groups3.size_ptr.copyload.pre", %"src::BlockIterate.groups5.size_ptr.copyload.pre"
  br i1 %.not131, label %L59, label %L280

L59:                                              ; preds = %L33.L40_crit_edge
  %.not132.not = icmp eq i64 %"src::BlockIterate.groups5.size_ptr.copyload.pre", 0
  br i1 %.not132.not, label %L274, label %L80

L80:                                              ; preds = %L59
  %memoryref_data = load ptr, ptr %"dest::BlockIterate.groups123", align 8
  %6 = load atomic ptr, ptr %memoryref_data unordered, align 8
  %.not133 = icmp eq ptr %6, null
  br i1 %.not133, label %fail, label %L115

L115:                                             ; preds = %L80
  %memoryref_data90 = load ptr, ptr %gclift209, align 8
  %7 = load atomic ptr, ptr %memoryref_data90 unordered, align 8
  %.not135 = icmp eq ptr %7, null
  br i1 %.not135, label %fail98, label %L134

L134:                                             ; preds = %L115
  %value_phi25.size_ptr197 = getelementptr inbounds nuw i8, ptr %6, i64 16
  %value_phi25.size_ptr.copyload198 = load i64, ptr %value_phi25.size_ptr197, align 8
  %value_phi26.size_ptr199 = getelementptr inbounds nuw i8, ptr %7, i64 16
  %value_phi26.size_ptr.copyload200 = load i64, ptr %value_phi26.size_ptr199, align 8
  %.not136201 = icmp eq i64 %value_phi25.size_ptr.copyload198, %value_phi26.size_ptr.copyload200
  br i1 %.not136201, label %L177, label %L280

L148:                                             ; preds = %L236
  %8 = add i64 %value_phi28203, 1
  %value_phi25.size_ptr = getelementptr inbounds nuw i8, ptr %19, i64 16
  %value_phi25.size_ptr.copyload = load i64, ptr %value_phi25.size_ptr, align 8
  %value_phi26.size_ptr = getelementptr inbounds nuw i8, ptr %20, i64 16
  %value_phi26.size_ptr.copyload = load i64, ptr %value_phi26.size_ptr, align 8
  %.not136 = icmp eq i64 %value_phi25.size_ptr.copyload, %value_phi26.size_ptr.copyload
  br i1 %.not136, label %L177, label %L280

L177:                                             ; preds = %L148, %L134
  %gclift210 = phi ptr [ %20, %L148 ], [ %7, %L134 ]
  %value_phi25.size_ptr.copyload204 = phi i64 [ %value_phi25.size_ptr.copyload, %L148 ], [ %value_phi25.size_ptr.copyload198, %L134 ]
  %gclift211 = phi ptr [ %19, %L148 ], [ %6, %L134 ]
  %value_phi28203 = phi i64 [ %8, %L148 ], [ 2, %L134 ]
  %9 = load ptr, ptr %gclift211, align 8
  %10 = getelementptr inbounds nuw i8, ptr %gclift211, i64 8
  %11 = load ptr, ptr %10, align 8
  %12 = load ptr, ptr %gclift210, align 8
  %13 = getelementptr inbounds nuw i8, ptr %gclift210, i64 8
  %14 = load ptr, ptr %13, align 8
  %15 = shl i64 %value_phi25.size_ptr.copyload204, 3
  %gc_slot_addr_3 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 40
  store ptr %gclift209, ptr %gc_slot_addr_3, align 8
  %gc_slot_addr_2 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 32
  store ptr %"dest::BlockIterate.groups123", ptr %gc_slot_addr_2, align 8
  %gc_slot_addr_1 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 24
  store ptr %14, ptr %gc_slot_addr_1, align 8
  %gc_slot_addr_0 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 16
  store ptr %11, ptr %gc_slot_addr_0, align 8
  %16 = call i32 @jlplt_memcmp_1130_got.jit(ptr %9, ptr %12, i64 %15)
  %17 = icmp eq i32 %16, 0
  br i1 %17, label %L181, label %L280

L181:                                             ; preds = %L177
  %18 = add i64 %value_phi28203, -1
  %"dest::BlockIterate.groups3.size_ptr31.copyload" = load i64, ptr %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert", align 8
  %.not137.not = icmp ult i64 %18, %"dest::BlockIterate.groups3.size_ptr31.copyload"
  br i1 %.not137.not, label %L202, label %L274

L202:                                             ; preds = %L181
  %memoryref_data38 = load ptr, ptr %"dest::BlockIterate.groups123", align 8
  %memoryref_byteoffset = shl i64 %18, 3
  %memoryref_data44 = getelementptr inbounds i8, ptr %memoryref_data38, i64 %memoryref_byteoffset
  %19 = load atomic ptr, ptr %memoryref_data44 unordered, align 8
  %.not138 = icmp eq ptr %19, null
  br i1 %.not138, label %fail46, label %L215

L215:                                             ; preds = %L202
  %"src::BlockIterate.groups5.size_ptr59.copyload" = load i64, ptr %"src::BlockIterate.groups5.size_ptr.phi.trans.insert", align 8
  %.not139.not.not = icmp ult i64 %18, %"src::BlockIterate.groups5.size_ptr59.copyload"
  br i1 %.not139.not.not, label %L236, label %L274

L236:                                             ; preds = %L215
  %memoryref_data65 = load ptr, ptr %gclift209, align 8
  %memoryref_data73 = getelementptr inbounds i8, ptr %memoryref_data65, i64 %memoryref_byteoffset
  %20 = load atomic ptr, ptr %memoryref_data73 unordered, align 8
  %.not140 = icmp eq ptr %20, null
  br i1 %.not140, label %fail75, label %L148

common.ret:                                       ; preds = %L280, %L274
  %common.ret.op = phi ptr [ %21, %L274 ], [ %22, %L280 ]
  %frame.prev238 = load ptr, ptr %frame.prev, align 8
  store ptr %frame.prev238, ptr %tls_pgcstack, align 8
  ret ptr %common.ret.op

L274:                                             ; preds = %L215, %L181, %L59, %L33, %L28, %L25, %L20, %L10
  %21 = call nonnull ptr @"j__copy_active!_1127"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L280:                                             ; preds = %L177, %L148, %L134, %L33.L40_crit_edge
  %22 = call nonnull ptr @"j_copyto!_1128"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L282:                                             ; preds = %top
  %23 = call [1 x ptr] @j_DimensionMismatch_1132(ptr nonnull @"jl_global#1133.jit")
  %gc_slot_addr_0212 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 16
  %24 = extractvalue [1 x ptr] %23, 0
  store ptr %24, ptr %gc_slot_addr_0212, align 8
  %ptls_field = getelementptr inbounds nuw i8, ptr %tls_pgcstack, i64 16
  %ptls_load = load ptr, ptr %ptls_field, align 8
  %"box::DimensionMismatch" = call noalias nonnull align 8 dereferenceable(16) ptr @ijl_gc_small_alloc(ptr %ptls_load, i32 360, i32 16, i64 136082836598848) #10
  %"box::DimensionMismatch.tag_addr" = getelementptr inbounds i8, ptr %"box::DimensionMismatch", i64 -8
  store atomic i64 136082836598848, ptr %"box::DimensionMismatch.tag_addr" unordered, align 8
  store ptr %24, ptr %"box::DimensionMismatch", align 8
  store ptr null, ptr %gc_slot_addr_0212, align 8
  call void @ijl_throw(ptr nonnull %"box::DimensionMismatch")
  unreachable

fail:                                             ; preds = %L80
  %jl_undefref_exception = load ptr, ptr @jl_undefref_exception, align 8
  call void @ijl_throw(ptr nonnull %jl_undefref_exception)
  unreachable

fail46:                                           ; preds = %L202
  %jl_undefref_exception45 = load ptr, ptr @jl_undefref_exception, align 8
  store ptr null, ptr %gc_slot_addr_3, align 8
  store ptr null, ptr %gc_slot_addr_2, align 8
  store ptr null, ptr %gc_slot_addr_1, align 8
  store ptr null, ptr %gc_slot_addr_0, align 8
  call void @ijl_throw(ptr nonnull %jl_undefref_exception45)
  unreachable

fail75:                                           ; preds = %L236
  %jl_undefref_exception74 = load ptr, ptr @jl_undefref_exception, align 8
  store ptr null, ptr %gc_slot_addr_3, align 8
  store ptr null, ptr %gc_slot_addr_2, align 8
  store ptr null, ptr %gc_slot_addr_1, align 8
  store ptr null, ptr %gc_slot_addr_0, align 8
  call void @ijl_throw(ptr nonnull %jl_undefref_exception74)
  unreachable

fail98:                                           ; preds = %L115
  %jl_undefref_exception97 = load ptr, ptr @jl_undefref_exception, align 8
  call void @ijl_throw(ptr nonnull %jl_undefref_exception97)
  unreachable

guard_pass:                                       ; preds = %L20
  %"dest::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"dest::BlockIterate.layout_cache", i64 -8
  %"dest::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"dest::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %25 = and i64 %"dest::BlockIterate.layout_cache.tag", -16
  %"src::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"src::BlockIterate.layout_cache", i64 -8
  %"src::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"src::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %26 = and i64 %"src::BlockIterate.layout_cache.tag", -16
  %27 = icmp eq i64 %25, %26
  br i1 %27, label %L25, label %L28
}
