	.file	"copyto!"
	.section	.ltext,"axl",@progbits
	.globl	"julia_copyto!_1140"            # -- Begin function julia_copyto!_1140
	.p2align	4
	.type	"julia_copyto!_1140",@function
"julia_copyto!_1140":                   # @"julia_copyto!_1140"
; Function Signature: copyto!(ProximalBase.BlockIterate{Float32, Array{Array{Int64, 1}, 1}}, ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: copyto!:dest <- [$rdi+0]
	#DEBUG_VALUE: copyto!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r13
	push	r12
	push	rbx
	sub	rsp, 72
	vxorps	xmm0, xmm0, xmm0
	vmovups	ymmword ptr [rbp - 96], ymm0
	mov	qword ptr [rbp - 56], 0
	mov	qword ptr [rbp - 64], 0
	#APP
	mov	rax, qword ptr fs:[0]
	#NO_APP
	mov	r14, qword ptr [rax - 8]
	mov	qword ptr [rbp - 96], 16
	mov	rax, qword ptr [r14]
	mov	qword ptr [rbp - 88], rax
	lea	rax, [rbp - 96]
	mov	qword ptr [r14], rax
	mov	rax, qword ptr [rdi]
	mov	rax, qword ptr [rax + 16]
	mov	rcx, qword ptr [rsi]
	cmp	rax, qword ptr [rcx + 16]
	jne	.LBB0_25
# %bb.1:                                # %L10
	mov	rbx, qword ptr [rsi + 8]
	cmp	qword ptr [rdi + 8], rbx
	je	.LBB0_4
# %bb.2:                                # %L16
	mov	rax, qword ptr [rdi + 24]
	movabs	rcx, offset jl_nothing
	cmp	rax, qword ptr [rcx]
	je	.LBB0_8
# %bb.3:                                # %L20
	mov	rcx, qword ptr [rsi + 24]
	cmp	rax, rcx
	je	.LBB0_4
# %bb.5:                                # %guard_pass
	mov	rdx, qword ptr [rax - 8]
	and	rdx, -16
	mov	r8, qword ptr [rcx - 8]
	and	r8, -16
	cmp	rdx, r8
	jne	.LBB0_8
# %bb.6:                                # %L25
	movabs	r8, offset jl_egal__unboxed
	mov	rbx, rdi
	mov	rdi, rax
	mov	r15, rsi
	mov	rsi, rcx
	vzeroupper
	call	r8
	mov	rdi, rbx
	mov	rsi, r15
	test	al, 1
	jne	.LBB0_4
# %bb.7:                                # %L25.L28_crit_edge
	mov	rax, qword ptr [rdi + 24]
	mov	rbx, qword ptr [rsi + 8]
.LBB0_8:                                # %L28
	cmp	rax, rbx
	je	.LBB0_4
# %bb.9:                                # %L33
	mov	r13, qword ptr [rdi + 8]
	cmp	qword ptr [rsi + 24], r13
	je	.LBB0_4
# %bb.10:                               # %L33.L40_crit_edge
	mov	rax, qword ptr [rbx + 16]
	cmp	qword ptr [r13 + 16], rax
	jne	.LBB0_23
# %bb.11:                               # %L59
	test	rax, rax
	je	.LBB0_4
# %bb.12:                               # %L80
	mov	rax, qword ptr [r13]
	mov	rcx, qword ptr [rax]
	test	rcx, rcx
	je	.LBB0_26
# %bb.13:                               # %L115
	mov	rax, qword ptr [rbx]
	mov	r8, qword ptr [rax]
	test	r8, r8
	je	.LBB0_28
# %bb.14:                               # %L134
	mov	rdx, qword ptr [rcx + 16]
	cmp	rdx, qword ptr [r8 + 16]
	jne	.LBB0_23
# %bb.15:                               # %L177.preheader
	mov	r12d, 1
	mov	qword ptr [rbp - 104], rdi      # 8-byte Spill
	.p2align	4
.LBB0_17:                               # %L177
                                        # =>This Inner Loop Header: Depth=1
	mov	rdi, qword ptr [rcx]
	mov	r9, qword ptr [rcx + 8]
	mov	rcx, qword ptr [r8]
	mov	r8, qword ptr [r8 + 8]
	shl	rdx, 3
	mov	qword ptr [rbp - 56], rbx
	mov	qword ptr [rbp - 64], r13
	mov	qword ptr [rbp - 72], r8
	mov	qword ptr [rbp - 80], r9
	mov	r15, rsi
	mov	rsi, rcx
	movabs	rax, offset .Ljlplt_memcmp_1145_got.jit
	vzeroupper
	call	rax
	mov	rdi, qword ptr [rbp - 104]      # 8-byte Reload
	mov	rsi, r15
	test	eax, eax
	jne	.LBB0_23
# %bb.18:                               # %L181
                                        #   in Loop: Header=BB0_17 Depth=1
	cmp	r12, qword ptr [r13 + 16]
	jae	.LBB0_4
# %bb.19:                               # %L202
                                        #   in Loop: Header=BB0_17 Depth=1
	mov	rax, qword ptr [r13]
	mov	rcx, qword ptr [rax + 8*r12]
	test	rcx, rcx
	je	.LBB0_27
# %bb.20:                               # %L215
                                        #   in Loop: Header=BB0_17 Depth=1
	cmp	r12, qword ptr [rbx + 16]
	jae	.LBB0_4
# %bb.21:                               # %L236
                                        #   in Loop: Header=BB0_17 Depth=1
	mov	rax, qword ptr [rbx]
	mov	r8, qword ptr [rax + 8*r12]
	test	r8, r8
	je	.LBB0_22
# %bb.16:                               # %L148
                                        #   in Loop: Header=BB0_17 Depth=1
	mov	rdx, qword ptr [rcx + 16]
	inc	r12
	cmp	rdx, qword ptr [r8 + 16]
	je	.LBB0_17
.LBB0_23:                               # %L280
	movabs	rax, offset "j_copyto!_1143"
	vzeroupper
	call	rax
	jmp	.LBB0_24
.LBB0_4:                                # %L274
	movabs	rax, offset "j__copy_active!_1142"
	vzeroupper
	call	rax
.LBB0_24:                               # %common.ret
	mov	rcx, qword ptr [rbp - 88]
	mov	qword ptr [r14], rcx
	add	rsp, 72
	pop	rbx
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB0_25:                               # %L282
	movabs	rdi, offset ".Ljl_global#1148.jit"
	movabs	rax, offset j_DimensionMismatch_1147
	vzeroupper
	call	rax
	mov	rbx, rax
	mov	qword ptr [rbp - 80], rax
	mov	rdi, qword ptr [r14 + 16]
	movabs	rax, offset ijl_gc_small_alloc
	movabs	r14, 136082836598848
	mov	esi, 360
	mov	edx, 16
	mov	rcx, r14
	call	rax
	mov	qword ptr [rax - 8], r14
	mov	qword ptr [rax], rbx
	mov	qword ptr [rbp - 80], 0
	movabs	rcx, offset ijl_throw
	mov	rdi, rax
	call	rcx
.LBB0_27:                               # %fail46
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	vxorps	xmm0, xmm0, xmm0
	vmovups	ymmword ptr [rbp - 80], ymm0
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.LBB0_22:                               # %fail75
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	vxorps	xmm0, xmm0, xmm0
	vmovups	ymmword ptr [rbp - 80], ymm0
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.LBB0_26:                               # %fail
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.LBB0_28:                               # %fail98
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.Lfunc_end0:
	.size	"julia_copyto!_1140", .Lfunc_end0-"julia_copyto!_1140"
                                        # -- End function
.set ".L+Main.Base.DimensionMismatch#1149.jit", 136082836598848
	.size	".L+Main.Base.DimensionMismatch#1149.jit", 8
.set ".Ljl_global#1148.jit", 136082965839056
	.size	".Ljl_global#1148.jit", 8
.set .Ljlplt_memcmp_1145_got.jit, 136083131631136
	.size	.Ljlplt_memcmp_1145_got.jit, 8
	.section	".note.GNU-stack","",@progbits
