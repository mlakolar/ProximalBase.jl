	.file	"copyto!"
	.section	.ltext,"axl",@progbits
	.globl	"julia_copyto!_992"             # -- Begin function julia_copyto!_992
	.p2align	4
	.type	"julia_copyto!_992",@function
"julia_copyto!_992":                    # @"julia_copyto!_992"
; Function Signature: copyto!(ProximalBase.BlockIterate{Float32, Array{Base.UnitRange{Int64}, 1}}, ProximalBase.BlockIterate{Float64, Array{Base.UnitRange{Int64}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: copyto!:dest <- [$rdi+0]
	#DEBUG_VALUE: copyto!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r12
	push	rbx
	sub	rsp, 32
	vxorps	xmm0, xmm0, xmm0
	vmovaps	xmmword ptr [rbp - 64], xmm0
	mov	qword ptr [rbp - 48], 0
	#APP
	mov	rax, qword ptr fs:[0]
	#NO_APP
	mov	r14, qword ptr [rax - 8]
	mov	qword ptr [rbp - 64], 4
	mov	rax, qword ptr [r14]
	mov	qword ptr [rbp - 56], rax
	lea	rax, [rbp - 64]
	mov	qword ptr [r14], rax
	mov	rax, qword ptr [rdi]
	mov	rax, qword ptr [rax + 16]
	mov	rcx, qword ptr [rsi]
	cmp	rax, qword ptr [rcx + 16]
	jne	.LBB0_16
# %bb.1:                                # %L10
	mov	r8, qword ptr [rsi + 8]
	cmp	qword ptr [rdi + 8], r8
	je	.LBB0_4
# %bb.2:                                # %L16
	mov	rax, qword ptr [rdi + 24]
	movabs	rcx, offset jl_nothing
	cmp	rax, qword ptr [rcx]
	je	.LBB0_8
# %bb.3:                                # %L20
	mov	rcx, qword ptr [rsi + 24]
	cmp	rax, rcx
	je	.LBB0_4
# %bb.5:                                # %guard_pass
	mov	rdx, qword ptr [rax - 8]
	and	rdx, -16
	mov	r9, qword ptr [rcx - 8]
	and	r9, -16
	cmp	rdx, r9
	jne	.LBB0_8
# %bb.6:                                # %L25
	movabs	r8, offset jl_egal__unboxed
	mov	rbx, rdi
	mov	rdi, rax
	mov	r15, rsi
	mov	rsi, rcx
	call	r8
	mov	rdi, rbx
	mov	rsi, r15
	test	al, 1
	jne	.LBB0_4
# %bb.7:                                # %L25.L28_crit_edge
	mov	rax, qword ptr [rdi + 24]
	mov	r8, qword ptr [rsi + 8]
.LBB0_8:                                # %L28
	cmp	rax, r8
	je	.LBB0_4
# %bb.9:                                # %L33
	mov	rcx, qword ptr [rdi + 8]
	cmp	qword ptr [rsi + 24], rcx
	je	.LBB0_4
# %bb.10:                               # %L33.L40_crit_edge
	mov	rax, qword ptr [r8 + 16]
	cmp	qword ptr [rcx + 16], rax
	jne	.LBB0_14
# %bb.11:                               # %L59
	test	rax, rax
	je	.LBB0_4
# %bb.12:                               # %L94
	mov	rcx, qword ptr [rcx]
	mov	r9, qword ptr [rcx]
	mov	r10, qword ptr [rcx + 8]
	mov	rdx, qword ptr [r8]
	mov	r8, qword ptr [rdx]
	mov	r11, qword ptr [rdx + 8]
	cmp	r10, r9
	setl	bl
	cmp	r11, r8
	setl	r15b
	xor	r9, r8
	xor	r10, r11
	or	r10, r9
	sete	r8b
	test	bl, r15b
	jne	.LBB0_17
# %bb.13:                               # %L94
	test	r8b, r8b
	je	.LBB0_14
.LBB0_17:                               # %L170.lr.ph
	mov	r9d, 24
	.p2align	4
.LBB0_18:                               # %L170
                                        # =>This Inner Loop Header: Depth=1
	dec	rax
	je	.LBB0_4
# %bb.19:                               # %guard_exit164
                                        #   in Loop: Header=BB0_18 Depth=1
	lea	r8, [r9 + 16]
	mov	r10, qword ptr [rcx + r9 - 8]
	mov	r11, qword ptr [rcx + r9]
	mov	rbx, qword ptr [rdx + r9 - 8]
	mov	r9, qword ptr [rdx + r9]
	cmp	r11, r10
	setl	r15b
	cmp	r9, rbx
	setl	r12b
	xor	r10, rbx
	xor	r11, r9
	or	r11, r10
	sete	r10b
	mov	r9, r8
	test	r15b, r12b
	jne	.LBB0_18
# %bb.20:                               # %guard_exit164
                                        #   in Loop: Header=BB0_18 Depth=1
	mov	r9, r8
	test	r10b, r10b
	jne	.LBB0_18
.LBB0_14:                               # %L269
	movabs	rax, offset "j_copyto!_995"
	call	rax
	jmp	.LBB0_15
.LBB0_4:                                # %L263
	movabs	rax, offset "j__copy_active!_994"
	call	rax
.LBB0_15:                               # %common.ret
	mov	rcx, qword ptr [rbp - 56]
	mov	qword ptr [r14], rcx
	add	rsp, 32
	pop	rbx
	pop	r12
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB0_16:                               # %L271
	movabs	rdi, offset ".Ljl_global#998.jit"
	movabs	rax, offset j_DimensionMismatch_997
	call	rax
	mov	rbx, rax
	mov	qword ptr [rbp - 48], rax
	mov	rdi, qword ptr [r14 + 16]
	movabs	rax, offset ijl_gc_small_alloc
	movabs	r14, 136082836598848
	mov	esi, 360
	mov	edx, 16
	mov	rcx, r14
	call	rax
	mov	qword ptr [rax - 8], r14
	mov	qword ptr [rax], rbx
	mov	qword ptr [rbp - 48], 0
	movabs	rcx, offset ijl_throw
	mov	rdi, rax
	call	rcx
.Lfunc_end0:
	.size	"julia_copyto!_992", .Lfunc_end0-"julia_copyto!_992"
                                        # -- End function
.set ".L+Main.Base.DimensionMismatch#999.jit", 136082836598848
	.size	".L+Main.Base.DimensionMismatch#999.jit", 8
.set ".Ljl_global#998.jit", 136082965839056
	.size	".Ljl_global#998.jit", 8
	.section	".note.GNU-stack","",@progbits
