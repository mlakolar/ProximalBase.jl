	.file	"_copy_active!"
	.section	.ltext,"axl",@progbits
	.globl	"julia__copy_active!_1090"      # -- Begin function julia__copy_active!_1090
	.p2align	4
	.type	"julia__copy_active!_1090",@function
"julia__copy_active!_1090":             # @"julia__copy_active!_1090"
; Function Signature: _copy_active!(ProximalBase.BlockIterate{Float32, Array{Base.StepRange{Int64, Int64}, 1}}, ProximalBase.BlockIterate{Float64, Array{Base.StepRange{Int64, Int64}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: _copy_active!:dest <- [$rdi+0]
	#DEBUG_VALUE: _copy_active!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r13
	push	r12
	push	rbx
	mov	qword ptr [rbp - 48], rdi       # 8-byte Spill
	mov	rax, qword ptr [rdi + 48]
	xor	ecx, ecx
	test	rax, rax
	cmovg	rcx, rax
	jle	.LBB0_8
# %bb.1:                                # %L18.preheader
	mov	r10, qword ptr [rbp - 48]       # 8-byte Reload
	mov	rax, qword ptr [r10 + 32]
	mov	rdx, qword ptr [rax]
	mov	rax, qword ptr [rsi + 40]
	mov	rdi, qword ptr [rax]
	mov	rax, qword ptr [r10 + 40]
	mov	r8, qword ptr [rax]
	mov	r9, qword ptr [r10 + 8]
	mov	r10, qword ptr [r10]
	mov	r11d, 1
	jmp	.LBB0_2
	.p2align	4
.LBB0_7:                                # %L135
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	qword ptr [r8 + 8*rbx - 8], 0
	lea	rax, [r11 + 1]
	cmp	r11, rcx
	mov	r11, rax
	je	.LBB0_8
.LBB0_2:                                # %L18
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_6 Depth 2
	mov	rbx, qword ptr [rdx + 8*r11 - 8]
	cmp	qword ptr [rdi + 8*rbx - 8], 0
	jne	.LBB0_7
# %bb.3:                                # %L60
                                        #   in Loop: Header=BB0_2 Depth=1
	lea	rax, [rbx - 1]
	mov	r12, qword ptr [r9]
	lea	rax, [rax + 2*rax]
	mov	r14, qword ptr [r12 + 8*rax]
	mov	r15, qword ptr [r12 + 8*rax + 8]
	mov	r12, qword ptr [r12 + 8*rax + 16]
	test	r15, r15
	setg	al
	cmp	r14, r12
	setl	r13b
	je	.LBB0_5
# %bb.4:                                # %L60
                                        #   in Loop: Header=BB0_2 Depth=1
	xor	al, r13b
	jne	.LBB0_7
.LBB0_5:                                # %L101.preheader
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	rax, qword ptr [r10]
	add	r12, r15
	.p2align	4
.LBB0_6:                                # %L101
                                        #   Parent Loop BB0_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	mov	dword ptr [rax + 4*r14 - 4], 0
	add	r14, r15
	cmp	r12, r14
	jne	.LBB0_6
	jmp	.LBB0_7
.LBB0_8:                                # %L165
	mov	rax, qword ptr [rsi + 48]
	xor	edx, edx
	test	rax, rax
	mov	qword ptr [rbp - 56], rax       # 8-byte Spill
	cmovg	rdx, rax
	jle	.LBB0_15
# %bb.9:                                # %L182.preheader
	mov	rax, qword ptr [rsi + 32]
	mov	rdi, qword ptr [rax]
	mov	rax, qword ptr [rsi + 8]
	mov	r8, qword ptr [rax]
	mov	rcx, qword ptr [rbp - 48]       # 8-byte Reload
	mov	rax, qword ptr [rcx + 32]
	mov	r9, qword ptr [rax]
	mov	rax, qword ptr [rcx + 40]
	mov	r10, qword ptr [rax]
	mov	rax, qword ptr [rsi]
	mov	r11, qword ptr [rcx]
	mov	ebx, 1
	jmp	.LBB0_10
	.p2align	4
.LBB0_14:                               # %L298
                                        #   in Loop: Header=BB0_10 Depth=1
	mov	qword ptr [r9 + 8*rbx - 8], r14
	mov	qword ptr [r10 + 8*r14 - 8], rbx
	lea	rcx, [rbx + 1]
	cmp	rbx, rdx
	mov	rbx, rcx
	je	.LBB0_15
.LBB0_10:                               # %L182
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_13 Depth 2
	mov	r14, qword ptr [rdi + 8*rbx - 8]
	lea	rcx, [r14 + 2*r14]
	mov	r15, qword ptr [r8 + 8*rcx - 24]
	mov	r12, qword ptr [r8 + 8*rcx - 16]
	mov	r13, qword ptr [r8 + 8*rcx - 8]
	test	r12, r12
	setg	cl
	cmp	r15, r13
	setl	sil
	je	.LBB0_12
# %bb.11:                               # %L182
                                        #   in Loop: Header=BB0_10 Depth=1
	xor	cl, sil
	jne	.LBB0_14
.LBB0_12:                               # %L244.preheader
                                        #   in Loop: Header=BB0_10 Depth=1
	mov	rcx, qword ptr [rax]
	mov	rsi, qword ptr [r11]
	add	r13, r12
	.p2align	4
.LBB0_13:                               # %L244
                                        #   Parent Loop BB0_10 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovsd	xmm0, qword ptr [rcx + 8*r15 - 8] # xmm0 = mem[0],zero
	vcvtsd2ss	xmm0, xmm0, xmm0
	vmovss	dword ptr [rsi + 4*r15 - 4], xmm0
	add	r15, r12
	cmp	r13, r15
	jne	.LBB0_13
	jmp	.LBB0_14
.LBB0_15:                               # %L347
	mov	rax, qword ptr [rbp - 48]       # 8-byte Reload
	mov	rcx, qword ptr [rbp - 56]       # 8-byte Reload
	mov	qword ptr [rax + 48], rcx
	pop	rbx
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.Lfunc_end0:
	.size	"julia__copy_active!_1090", .Lfunc_end0-"julia__copy_active!_1090"
                                        # -- End function
	.section	".note.GNU-stack","",@progbits
