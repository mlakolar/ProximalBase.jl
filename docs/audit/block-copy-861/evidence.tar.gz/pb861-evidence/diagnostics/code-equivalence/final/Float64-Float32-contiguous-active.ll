; Function Signature: _copy_active!(ProximalBase.BlockIterate{Float64, Array{Base.UnitRange{Int64}, 1}}, ProximalBase.BlockIterate{Float32, Array{Base.UnitRange{Int64}, 1}})
define nonnull ptr @"julia__copy_active!_1203"(ptr noundef nonnull align 8 dereferenceable(56) %"dest::BlockIterate", ptr noundef nonnull align 8 dereferenceable(56) %"src::BlockIterate") local_unnamed_addr #0 {
top:
  %"dest::BlockIterate.nactive_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 48
  %"dest::BlockIterate.nactive" = load i64, ptr %"dest::BlockIterate.nactive_ptr", align 8
  %".dest::BlockIterate.nactive" = call i64 @llvm.smax.i64(i64 %"dest::BlockIterate.nactive", i64 0)
  %0 = icmp slt i64 %"dest::BlockIterate.nactive", 1
  br i1 %0, label %L155, label %L18.preheader

L18.preheader:                                    ; preds = %top
  %"dest::BlockIterate.active_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 32
  %"dest::BlockIterate.active" = load atomic ptr, ptr %"dest::BlockIterate.active_ptr" unordered, align 8
  %memoryref_data = load ptr, ptr %"dest::BlockIterate.active", align 8
  %invariant.gep203 = getelementptr i8, ptr %memoryref_data, i64 -8
  %"src::BlockIterate.position_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 40
  %"src::BlockIterate.position" = load atomic ptr, ptr %"src::BlockIterate.position_ptr" unordered, align 8
  %memoryref_data8 = load ptr, ptr %"src::BlockIterate.position", align 8
  %"dest::BlockIterate.position_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 40
  %"dest::BlockIterate.position" = load atomic ptr, ptr %"dest::BlockIterate.position_ptr" unordered, align 8
  %memoryref_data48 = load ptr, ptr %"dest::BlockIterate.position", align 8
  %"dest::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 8
  %"dest::BlockIterate.groups" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %"dest::BlockIterate.storage" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  br label %L18

L18:                                              ; preds = %L125, %L18.preheader
  %value_phi4 = phi i64 [ %8, %L125 ], [ 1, %L18.preheader ]
  %memoryref_offset = shl i64 %value_phi4, 3
  %gep204 = getelementptr i8, ptr %invariant.gep203, i64 %memoryref_offset
  %1 = load i64, ptr %gep204, align 8
  %memoryref_offset10 = add i64 %1, -1
  %memoryref_byteoffset11 = shl i64 %memoryref_offset10, 3
  %memoryref_data16 = getelementptr inbounds i8, ptr %memoryref_data8, i64 %memoryref_byteoffset11
  %2 = load i64, ptr %memoryref_data16, align 8
  %.not = icmp eq i64 %2, 0
  br i1 %.not, label %L60, label %L125

L60:                                              ; preds = %L18
  %memoryref_data18 = load ptr, ptr %"dest::BlockIterate.groups", align 8
  %memoryref_byteoffset21 = shl i64 %memoryref_offset10, 4
  %memoryref_data26 = getelementptr inbounds i8, ptr %memoryref_data18, i64 %memoryref_byteoffset21
  %memoryref_data26.copyload = load i64, ptr %memoryref_data26, align 8
  %3 = getelementptr inbounds nuw i8, ptr %memoryref_data26, i64 8
  %memoryref_data26.copyload27 = load i64, ptr %3, align 8
  %.not197 = icmp slt i64 %memoryref_data26.copyload27, %memoryref_data26.copyload
  br i1 %.not197, label %L125, label %L92.preheader

L92.preheader:                                    ; preds = %L60
  %memoryref_data34 = load ptr, ptr %"dest::BlockIterate.storage", align 8
  %invariant.gep = getelementptr i8, ptr %memoryref_data34, i64 -8
  %4 = shl i64 %memoryref_data26.copyload, 3
  %scevgep = getelementptr i8, ptr %invariant.gep, i64 %4
  %5 = add i64 %memoryref_data26.copyload27, 1
  %6 = sub i64 %5, %memoryref_data26.copyload
  %7 = shl nuw i64 %6, 3
  call void @llvm.memset.p0.i64(ptr align 8 %scevgep, i8 0, i64 %7, i1 false)
  br label %L125

L125:                                             ; preds = %L92.preheader, %L60, %L18
  %memoryref_data56 = getelementptr inbounds i8, ptr %memoryref_data48, i64 %memoryref_byteoffset11
  store i64 0, ptr %memoryref_data56, align 8
  %.not199 = icmp eq i64 %value_phi4, %".dest::BlockIterate.nactive"
  %8 = add nuw i64 %value_phi4, 1
  br i1 %.not199, label %L155, label %L18

L155:                                             ; preds = %L125, %top
  %"src::BlockIterate.nactive_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 48
  %"src::BlockIterate.nactive" = load i64, ptr %"src::BlockIterate.nactive_ptr", align 8
  %".src::BlockIterate.nactive" = call i64 @llvm.smax.i64(i64 %"src::BlockIterate.nactive", i64 0)
  %9 = icmp slt i64 %"src::BlockIterate.nactive", 1
  br i1 %9, label %L327, label %L172.preheader

L172.preheader:                                   ; preds = %L155
  %"src::BlockIterate.active_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 32
  %"src::BlockIterate.active" = load atomic ptr, ptr %"src::BlockIterate.active_ptr" unordered, align 8
  %memoryref_data67 = load ptr, ptr %"src::BlockIterate.active", align 8
  %"src::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 8
  %"src::BlockIterate.groups" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  %memoryref_data77 = load ptr, ptr %"src::BlockIterate.groups", align 8
  %"dest::BlockIterate.active_ptr119" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 32
  %"dest::BlockIterate.active120" = load atomic ptr, ptr %"dest::BlockIterate.active_ptr119" unordered, align 8
  %memoryref_data122 = load ptr, ptr %"dest::BlockIterate.active120", align 8
  %"dest::BlockIterate.position_ptr131" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 40
  %"dest::BlockIterate.position132" = load atomic ptr, ptr %"dest::BlockIterate.position_ptr131" unordered, align 8
  %memoryref_data134 = load ptr, ptr %"dest::BlockIterate.position132", align 8
  %"src::BlockIterate.storage" = load atomic ptr, ptr %"src::BlockIterate" unordered, align 8
  %"dest::BlockIterate.storage104" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  br label %L172

L172:                                             ; preds = %L278, %L172.preheader
  %value_phi64 = phi i64 [ %62, %L278 ], [ 1, %L172.preheader ]
  %memoryref_offset69 = shl i64 %value_phi64, 3
  %memoryref_byteoffset70 = add i64 %memoryref_offset69, -8
  %memoryref_data75 = getelementptr inbounds i8, ptr %memoryref_data67, i64 %memoryref_byteoffset70
  %10 = load i64, ptr %memoryref_data75, align 8
  %memoryref_offset79 = add i64 %10, -1
  %memoryref_byteoffset80 = shl i64 %memoryref_offset79, 4
  %memoryref_data85 = getelementptr inbounds i8, ptr %memoryref_data77, i64 %memoryref_byteoffset80
  %memoryref_data85.copyload = load i64, ptr %memoryref_data85, align 8
  %11 = getelementptr inbounds nuw i8, ptr %memoryref_data85, i64 8
  %memoryref_data85.copyload86 = load i64, ptr %11, align 8
  %.not200 = icmp slt i64 %memoryref_data85.copyload86, %memoryref_data85.copyload
  br i1 %.not200, label %L278, label %iter.check

iter.check:                                       ; preds = %L172
  %memoryref_data95 = load ptr, ptr %"src::BlockIterate.storage", align 8
  %memoryref_data106 = load ptr, ptr %"dest::BlockIterate.storage104", align 8
  %12 = add i64 %memoryref_data85.copyload86, 1
  %13 = sub i64 %12, %memoryref_data85.copyload
  %min.iters.check = icmp ult i64 %13, 4
  br i1 %min.iters.check, label %L225.preheader, label %vector.memcheck

vector.memcheck:                                  ; preds = %iter.check
  %scevgep205 = getelementptr i8, ptr %memoryref_data106, i64 -8
  %14 = shl i64 %memoryref_data85.copyload, 3
  %scevgep206 = getelementptr i8, ptr %scevgep205, i64 %14
  %15 = shl i64 %memoryref_data85.copyload86, 3
  %scevgep207 = getelementptr i8, ptr %memoryref_data106, i64 %15
  %scevgep208 = getelementptr i8, ptr %memoryref_data95, i64 -4
  %16 = shl i64 %memoryref_data85.copyload, 2
  %scevgep209 = getelementptr i8, ptr %scevgep208, i64 %16
  %17 = shl i64 %memoryref_data85.copyload86, 2
  %scevgep210 = getelementptr i8, ptr %memoryref_data95, i64 %17
  %bound0 = icmp ult ptr %scevgep206, %scevgep210
  %bound1 = icmp ult ptr %scevgep209, %scevgep207
  %found.conflict = and i1 %bound0, %bound1
  br i1 %found.conflict, label %L225.preheader, label %vector.main.loop.iter.check

vector.main.loop.iter.check:                      ; preds = %vector.memcheck
  %min.iters.check211 = icmp ult i64 %13, 16
  br i1 %min.iters.check211, label %vector.main.loop.iter.check.vec.epilog.ph_crit_edge, label %vector.ph

vector.main.loop.iter.check.vec.epilog.ph_crit_edge: ; preds = %vector.main.loop.iter.check
  %.pre = add i64 %memoryref_data85.copyload, -1
  br label %vec.epilog.ph

vector.ph:                                        ; preds = %vector.main.loop.iter.check
  %n.mod.vf = and i64 %13, 12
  %n.vec = and i64 %13, -16
  %invariant.op221.reass = add i64 %memoryref_data85.copyload, -1
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %.reass222 = add i64 %index, %invariant.op221.reass
  %18 = shl i64 %.reass222, 2
  %19 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %18
  %20 = getelementptr inbounds nuw i8, ptr %19, i64 16
  %21 = getelementptr inbounds nuw i8, ptr %19, i64 32
  %22 = getelementptr inbounds nuw i8, ptr %19, i64 48
  %wide.load = load <4 x float>, ptr %19, align 4
  %wide.load212 = load <4 x float>, ptr %20, align 4
  %wide.load213 = load <4 x float>, ptr %21, align 4
  %wide.load214 = load <4 x float>, ptr %22, align 4
  %23 = fpext <4 x float> %wide.load to <4 x double>
  %24 = fpext <4 x float> %wide.load212 to <4 x double>
  %25 = fpext <4 x float> %wide.load213 to <4 x double>
  %26 = fpext <4 x float> %wide.load214 to <4 x double>
  %27 = shl i64 %.reass222, 3
  %28 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %27
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %30 = getelementptr inbounds nuw i8, ptr %28, i64 64
  %31 = getelementptr inbounds nuw i8, ptr %28, i64 96
  store <4 x double> %23, ptr %28, align 8
  store <4 x double> %24, ptr %29, align 8
  store <4 x double> %25, ptr %30, align 8
  store <4 x double> %26, ptr %31, align 8
  %index.next = add nuw i64 %index, 16
  %32 = icmp eq i64 %index.next, %n.vec
  br i1 %32, label %middle.block, label %vector.body

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %13, %n.vec
  br i1 %cmp.n, label %L278, label %vec.epilog.iter.check

vec.epilog.iter.check:                            ; preds = %middle.block
  %ind.end = add i64 %memoryref_data85.copyload, %n.vec
  %min.epilog.iters.check = icmp eq i64 %n.mod.vf, 0
  br i1 %min.epilog.iters.check, label %L225.preheader, label %vec.epilog.ph

vec.epilog.ph:                                    ; preds = %vec.epilog.iter.check, %vector.main.loop.iter.check.vec.epilog.ph_crit_edge
  %invariant.op224.reass.pre-phi = phi i64 [ %.pre, %vector.main.loop.iter.check.vec.epilog.ph_crit_edge ], [ %invariant.op221.reass, %vec.epilog.iter.check ]
  %vec.epilog.resume.val = phi i64 [ 0, %vector.main.loop.iter.check.vec.epilog.ph_crit_edge ], [ %n.vec, %vec.epilog.iter.check ]
  %n.vec216 = and i64 %13, -4
  %33 = add i64 %memoryref_data85.copyload, %n.vec216
  br label %vec.epilog.vector.body

vec.epilog.vector.body:                           ; preds = %vec.epilog.vector.body, %vec.epilog.ph
  %index217 = phi i64 [ %vec.epilog.resume.val, %vec.epilog.ph ], [ %index.next219, %vec.epilog.vector.body ]
  %.reass225 = add i64 %index217, %invariant.op224.reass.pre-phi
  %34 = shl i64 %.reass225, 2
  %gep = getelementptr i8, ptr %memoryref_data95, i64 %34
  %wide.load218 = load <4 x float>, ptr %gep, align 4
  %35 = fpext <4 x float> %wide.load218 to <4 x double>
  %36 = shl i64 %.reass225, 3
  %gep228 = getelementptr i8, ptr %memoryref_data106, i64 %36
  store <4 x double> %35, ptr %gep228, align 8
  %index.next219 = add nuw i64 %index217, 4
  %37 = icmp eq i64 %index.next219, %n.vec216
  br i1 %37, label %vec.epilog.middle.block, label %vec.epilog.vector.body

vec.epilog.middle.block:                          ; preds = %vec.epilog.vector.body
  %cmp.n220 = icmp eq i64 %13, %n.vec216
  br i1 %cmp.n220, label %L278, label %L225.preheader

L225.preheader:                                   ; preds = %vec.epilog.middle.block, %vec.epilog.iter.check, %vector.memcheck, %iter.check
  %value_phi93.ph = phi i64 [ %ind.end, %vec.epilog.iter.check ], [ %memoryref_data85.copyload, %iter.check ], [ %memoryref_data85.copyload, %vector.memcheck ], [ %33, %vec.epilog.middle.block ]
  %38 = sub i64 %12, %value_phi93.ph
  %39 = sub i64 %memoryref_data85.copyload86, %value_phi93.ph
  %xtraiter = and i64 %38, 7
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %L225.prol.loopexit, label %L225.prol

L225.prol:                                        ; preds = %L225.prol, %L225.preheader
  %value_phi93.prol = phi i64 [ %42, %L225.prol ], [ %value_phi93.ph, %L225.preheader ]
  %prol.iter = phi i64 [ %prol.iter.next, %L225.prol ], [ 0, %L225.preheader ]
  %memoryref_offset97.prol = add i64 %value_phi93.prol, -1
  %memoryref_byteoffset98.prol = shl i64 %memoryref_offset97.prol, 2
  %memoryref_data103.prol = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.prol
  %40 = load float, ptr %memoryref_data103.prol, align 4
  %41 = fpext float %40 to double
  %memoryref_byteoffset109.prol = shl i64 %memoryref_offset97.prol, 3
  %memoryref_data114.prol = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.prol
  store double %41, ptr %memoryref_data114.prol, align 8
  %42 = add i64 %value_phi93.prol, 1
  %prol.iter.next = add i64 %prol.iter, 1
  %prol.iter.cmp.not = icmp eq i64 %prol.iter.next, %xtraiter
  br i1 %prol.iter.cmp.not, label %L225.prol.loopexit, label %L225.prol

L225.prol.loopexit:                               ; preds = %L225.prol, %L225.preheader
  %value_phi93.unr = phi i64 [ %value_phi93.ph, %L225.preheader ], [ %42, %L225.prol ]
  %43 = icmp ult i64 %39, 7
  br i1 %43, label %L278, label %L225

L225:                                             ; preds = %L225, %L225.prol.loopexit
  %value_phi93 = phi i64 [ %61, %L225 ], [ %value_phi93.unr, %L225.prol.loopexit ]
  %memoryref_offset97 = add i64 %value_phi93, -1
  %memoryref_byteoffset98 = shl i64 %memoryref_offset97, 2
  %memoryref_data103 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98
  %44 = load float, ptr %memoryref_data103, align 4
  %45 = fpext float %44 to double
  %memoryref_byteoffset109 = shl i64 %memoryref_offset97, 3
  %memoryref_data114 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109
  store double %45, ptr %memoryref_data114, align 8
  %memoryref_byteoffset98.1 = shl i64 %value_phi93, 2
  %memoryref_data103.1 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.1
  %46 = load float, ptr %memoryref_data103.1, align 4
  %47 = fpext float %46 to double
  %memoryref_byteoffset109.1 = shl i64 %value_phi93, 3
  %memoryref_data114.1 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.1
  store double %47, ptr %memoryref_data114.1, align 8
  %memoryref_offset97.2 = add i64 %value_phi93, 1
  %memoryref_byteoffset98.2 = shl i64 %memoryref_offset97.2, 2
  %memoryref_data103.2 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.2
  %48 = load float, ptr %memoryref_data103.2, align 4
  %49 = fpext float %48 to double
  %memoryref_byteoffset109.2 = shl i64 %memoryref_offset97.2, 3
  %memoryref_data114.2 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.2
  store double %49, ptr %memoryref_data114.2, align 8
  %memoryref_offset97.3 = add i64 %value_phi93, 2
  %memoryref_byteoffset98.3 = shl i64 %memoryref_offset97.3, 2
  %memoryref_data103.3 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.3
  %50 = load float, ptr %memoryref_data103.3, align 4
  %51 = fpext float %50 to double
  %memoryref_byteoffset109.3 = shl i64 %memoryref_offset97.3, 3
  %memoryref_data114.3 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.3
  store double %51, ptr %memoryref_data114.3, align 8
  %memoryref_offset97.4 = add i64 %value_phi93, 3
  %memoryref_byteoffset98.4 = shl i64 %memoryref_offset97.4, 2
  %memoryref_data103.4 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.4
  %52 = load float, ptr %memoryref_data103.4, align 4
  %53 = fpext float %52 to double
  %memoryref_byteoffset109.4 = shl i64 %memoryref_offset97.4, 3
  %memoryref_data114.4 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.4
  store double %53, ptr %memoryref_data114.4, align 8
  %memoryref_offset97.5 = add i64 %value_phi93, 4
  %memoryref_byteoffset98.5 = shl i64 %memoryref_offset97.5, 2
  %memoryref_data103.5 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.5
  %54 = load float, ptr %memoryref_data103.5, align 4
  %55 = fpext float %54 to double
  %memoryref_byteoffset109.5 = shl i64 %memoryref_offset97.5, 3
  %memoryref_data114.5 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.5
  store double %55, ptr %memoryref_data114.5, align 8
  %memoryref_offset97.6 = add i64 %value_phi93, 5
  %memoryref_byteoffset98.6 = shl i64 %memoryref_offset97.6, 2
  %memoryref_data103.6 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.6
  %56 = load float, ptr %memoryref_data103.6, align 4
  %57 = fpext float %56 to double
  %memoryref_byteoffset109.6 = shl i64 %memoryref_offset97.6, 3
  %memoryref_data114.6 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.6
  store double %57, ptr %memoryref_data114.6, align 8
  %58 = add i64 %value_phi93, 7
  %memoryref_offset97.7 = add i64 %value_phi93, 6
  %memoryref_byteoffset98.7 = shl i64 %memoryref_offset97.7, 2
  %memoryref_data103.7 = getelementptr inbounds i8, ptr %memoryref_data95, i64 %memoryref_byteoffset98.7
  %59 = load float, ptr %memoryref_data103.7, align 4
  %60 = fpext float %59 to double
  %memoryref_byteoffset109.7 = shl i64 %memoryref_offset97.7, 3
  %memoryref_data114.7 = getelementptr inbounds i8, ptr %memoryref_data106, i64 %memoryref_byteoffset109.7
  store double %60, ptr %memoryref_data114.7, align 8
  %.not201.7 = icmp eq i64 %58, %memoryref_data85.copyload86
  %61 = add i64 %value_phi93, 8
  br i1 %.not201.7, label %L278, label %L225

L278:                                             ; preds = %L225, %L225.prol.loopexit, %vec.epilog.middle.block, %middle.block, %L172
  %memoryref_data130 = getelementptr inbounds i8, ptr %memoryref_data122, i64 %memoryref_byteoffset70
  store i64 %10, ptr %memoryref_data130, align 8
  %memoryref_byteoffset137 = shl i64 %memoryref_offset79, 3
  %memoryref_data142 = getelementptr inbounds i8, ptr %memoryref_data134, i64 %memoryref_byteoffset137
  store i64 %value_phi64, ptr %memoryref_data142, align 8
  %.not202 = icmp eq i64 %value_phi64, %".src::BlockIterate.nactive"
  %62 = add nuw i64 %value_phi64, 1
  br i1 %.not202, label %L327, label %L172

L327:                                             ; preds = %L278, %L155
  store i64 %"src::BlockIterate.nactive", ptr %"dest::BlockIterate.nactive_ptr", align 8
  ret ptr %"dest::BlockIterate"
}
