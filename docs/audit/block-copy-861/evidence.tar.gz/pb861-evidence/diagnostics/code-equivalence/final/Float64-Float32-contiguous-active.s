	.file	"_copy_active!"
	.section	.ltext,"axl",@progbits
	.globl	"julia__copy_active!_1214"      # -- Begin function julia__copy_active!_1214
	.p2align	4
	.type	"julia__copy_active!_1214",@function
"julia__copy_active!_1214":             # @"julia__copy_active!_1214"
; Function Signature: _copy_active!(ProximalBase.BlockIterate{Float64, Array{Base.UnitRange{Int64}, 1}}, ProximalBase.BlockIterate{Float32, Array{Base.UnitRange{Int64}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: _copy_active!:dest <- [$rdi+0]
	#DEBUG_VALUE: _copy_active!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r13
	push	r12
	push	rbx
	sub	rsp, 72
	mov	qword ptr [rbp - 48], rsi       # 8-byte Spill
	mov	qword ptr [rbp - 56], rdi       # 8-byte Spill
	mov	rax, qword ptr [rdi + 48]
	xor	esi, esi
	test	rax, rax
	cmovg	rsi, rax
	jle	.LBB0_6
# %bb.1:                                # %L18.preheader
	mov	rcx, qword ptr [rbp - 56]       # 8-byte Reload
	mov	rax, qword ptr [rcx + 32]
	mov	r15, qword ptr [rax]
	mov	rax, qword ptr [rbp - 48]       # 8-byte Reload
	mov	rax, qword ptr [rax + 40]
	mov	r12, qword ptr [rax]
	mov	rax, qword ptr [rcx + 40]
	mov	r13, qword ptr [rax]
	mov	rdi, qword ptr [rcx + 8]
	mov	rax, qword ptr [rcx]
	mov	qword ptr [rbp - 64], rax       # 8-byte Spill
	xor	r14d, r14d
	mov	qword ptr [rbp - 80], rsi       # 8-byte Spill
	mov	qword ptr [rbp - 72], rdi       # 8-byte Spill
	jmp	.LBB0_2
	.p2align	4
.LBB0_5:                                # %L125
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	qword ptr [r13 + 8*rbx - 8], 0
	inc	r14
	cmp	rsi, r14
	je	.LBB0_6
.LBB0_2:                                # %L18
                                        # =>This Inner Loop Header: Depth=1
	mov	rbx, qword ptr [r15 + 8*r14]
	cmp	qword ptr [r12 + 8*rbx - 8], 0
	jne	.LBB0_5
# %bb.3:                                # %L60
                                        #   in Loop: Header=BB0_2 Depth=1
	lea	rcx, [rbx - 1]
	mov	rdx, qword ptr [rdi]
	shl	rcx, 4
	mov	rax, qword ptr [rdx + rcx]
	mov	rcx, qword ptr [rdx + rcx + 8]
	sub	rcx, rax
	jl	.LBB0_5
# %bb.4:                                # %L92.preheader
                                        #   in Loop: Header=BB0_2 Depth=1
	mov	rdx, qword ptr [rbp - 64]       # 8-byte Reload
	mov	rdx, qword ptr [rdx]
	lea	rdi, [rdx + 8*rax]
	add	rdi, -8
	lea	rdx, [8*rcx + 8]
	xor	esi, esi
	movabs	rax, offset memset
	call	rax
	mov	rdi, qword ptr [rbp - 72]       # 8-byte Reload
	mov	rsi, qword ptr [rbp - 80]       # 8-byte Reload
	jmp	.LBB0_5
.LBB0_6:                                # %L155
	mov	rdx, qword ptr [rbp - 48]       # 8-byte Reload
	mov	rax, qword ptr [rdx + 48]
	xor	esi, esi
	test	rax, rax
	mov	qword ptr [rbp - 104], rax      # 8-byte Spill
	cmovg	rsi, rax
	jle	.LBB0_29
# %bb.7:                                # %L172.preheader
	mov	rax, qword ptr [rdx + 32]
	mov	r8, qword ptr [rax]
	mov	rax, qword ptr [rdx + 8]
	mov	rax, qword ptr [rax]
	mov	qword ptr [rbp - 80], rax       # 8-byte Spill
	mov	rcx, qword ptr [rbp - 56]       # 8-byte Reload
	mov	rax, qword ptr [rcx + 32]
	mov	rax, qword ptr [rax]
	mov	qword ptr [rbp - 72], rax       # 8-byte Spill
	mov	rax, qword ptr [rcx + 40]
	mov	rax, qword ptr [rax]
	mov	qword ptr [rbp - 64], rax       # 8-byte Spill
	mov	rax, qword ptr [rdx]
	mov	qword ptr [rbp - 48], rax       # 8-byte Spill
	mov	rax, qword ptr [rcx]
	mov	qword ptr [rbp - 112], rax      # 8-byte Spill
	mov	r11d, 1
	mov	qword ptr [rbp - 96], rsi       # 8-byte Spill
	mov	qword ptr [rbp - 88], r8        # 8-byte Spill
	jmp	.LBB0_8
	.p2align	4
.LBB0_28:                               # %L278
                                        #   in Loop: Header=BB0_8 Depth=1
	mov	rax, qword ptr [rbp - 72]       # 8-byte Reload
	mov	qword ptr [rax + 8*r11 - 8], r14
	mov	rax, qword ptr [rbp - 64]       # 8-byte Reload
	mov	qword ptr [rax + 8*r14 - 8], r11
	lea	rax, [r11 + 1]
	cmp	r11, rsi
	mov	r11, rax
	je	.LBB0_29
.LBB0_8:                                # %L172
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_18 Depth 2
                                        #     Child Loop BB0_15 Depth 2
                                        #     Child Loop BB0_24 Depth 2
                                        #     Child Loop BB0_27 Depth 2
	mov	r14, qword ptr [r8 + 8*r11 - 8]
	mov	rax, r14
	shl	rax, 4
	mov	rcx, qword ptr [rbp - 80]       # 8-byte Reload
	mov	r13, qword ptr [rax + rcx - 16]
	mov	r15, qword ptr [rax + rcx - 8]
	cmp	r15, r13
	jl	.LBB0_28
# %bb.9:                                # %iter.check
                                        #   in Loop: Header=BB0_8 Depth=1
	mov	rax, qword ptr [rbp - 48]       # 8-byte Reload
	mov	r12, qword ptr [rax]
	mov	rax, qword ptr [rbp - 112]      # 8-byte Reload
	mov	rax, qword ptr [rax]
	lea	rbx, [r15 + 1]
	mov	rdi, rbx
	sub	rdi, r13
	cmp	rdi, 4
	jb	.LBB0_22
# %bb.10:                               # %vector.memcheck
                                        #   in Loop: Header=BB0_8 Depth=1
	lea	r10, [rax + 8*r13]
	add	r10, -8
	lea	rdx, [r12 + 4*r13]
	add	rdx, -4
	lea	rcx, [r12 + 4*r15]
	cmp	r10, rcx
	jae	.LBB0_12
# %bb.11:                               # %vector.memcheck
                                        #   in Loop: Header=BB0_8 Depth=1
	lea	rcx, [rax + 8*r15]
	cmp	rdx, rcx
	jb	.LBB0_22
.LBB0_12:                               # %vector.main.loop.iter.check
                                        #   in Loop: Header=BB0_8 Depth=1
	cmp	rdi, 16
	jae	.LBB0_17
# %bb.13:                               #   in Loop: Header=BB0_8 Depth=1
	xor	r9d, r9d
	jmp	.LBB0_14
.LBB0_17:                               # %vector.ph
                                        #   in Loop: Header=BB0_8 Depth=1
	mov	r9, rdi
	and	r9, -16
	lea	r8, [rax + 8*r13]
	add	r8, 88
	lea	rcx, [r12 + 4*r13]
	add	rcx, 44
	xor	esi, esi
	.p2align	4
.LBB0_18:                               # %vector.body
                                        #   Parent Loop BB0_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vcvtps2pd	ymm0, xmmword ptr [rcx + 4*rsi - 48]
	vcvtps2pd	ymm1, xmmword ptr [rcx + 4*rsi - 32]
	vcvtps2pd	ymm2, xmmword ptr [rcx + 4*rsi - 16]
	vcvtps2pd	ymm3, xmmword ptr [rcx + 4*rsi]
	vmovups	ymmword ptr [r8 + 8*rsi - 96], ymm0
	vmovups	ymmword ptr [r8 + 8*rsi - 64], ymm1
	vmovups	ymmword ptr [r8 + 8*rsi - 32], ymm2
	vmovups	ymmword ptr [r8 + 8*rsi], ymm3
	add	rsi, 16
	cmp	r9, rsi
	jne	.LBB0_18
# %bb.19:                               # %middle.block
                                        #   in Loop: Header=BB0_8 Depth=1
	cmp	rdi, r9
	mov	rsi, qword ptr [rbp - 96]       # 8-byte Reload
	mov	r8, qword ptr [rbp - 88]        # 8-byte Reload
	je	.LBB0_28
# %bb.20:                               # %vec.epilog.iter.check
                                        #   in Loop: Header=BB0_8 Depth=1
	test	dil, 12
	je	.LBB0_21
.LBB0_14:                               # %vec.epilog.ph
                                        #   in Loop: Header=BB0_8 Depth=1
	mov	rcx, rdi
	and	rcx, -4
	add	r13, rcx
	.p2align	4
.LBB0_15:                               # %vec.epilog.vector.body
                                        #   Parent Loop BB0_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vcvtps2pd	ymm0, xmmword ptr [rdx + 4*r9]
	vmovups	ymmword ptr [r10 + 8*r9], ymm0
	add	r9, 4
	cmp	rcx, r9
	jne	.LBB0_15
# %bb.16:                               # %vec.epilog.middle.block
                                        #   in Loop: Header=BB0_8 Depth=1
	cmp	rdi, rcx
	je	.LBB0_28
	jmp	.LBB0_22
.LBB0_21:                               #   in Loop: Header=BB0_8 Depth=1
	add	r13, r9
	.p2align	4
.LBB0_22:                               # %L225.preheader
                                        #   in Loop: Header=BB0_8 Depth=1
	sub	ebx, r13d
	mov	rdi, r13
	and	ebx, 7
	je	.LBB0_25
# %bb.23:                               # %L225.prol.preheader
                                        #   in Loop: Header=BB0_8 Depth=1
	mov	rdi, r13
	.p2align	4
.LBB0_24:                               # %L225.prol
                                        #   Parent Loop BB0_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovss	xmm0, dword ptr [r12 + 4*rdi - 4] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi - 8], xmm0
	inc	rdi
	dec	rbx
	jne	.LBB0_24
.LBB0_25:                               # %L225.prol.loopexit
                                        #   in Loop: Header=BB0_8 Depth=1
	mov	rcx, r15
	sub	rcx, r13
	cmp	rcx, 7
	jb	.LBB0_28
# %bb.26:                               # %L225.preheader1
                                        #   in Loop: Header=BB0_8 Depth=1
	lea	rax, [rax + 8*rdi]
	add	rax, 48
	lea	rdx, [r12 + 4*rdi]
	add	rdx, 24
	sub	r15, rdi
	mov	rdi, -1
	.p2align	4
.LBB0_27:                               # %L225
                                        #   Parent Loop BB0_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	vmovss	xmm0, dword ptr [rdx + 4*rdi - 24] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi - 48], xmm0
	vmovss	xmm0, dword ptr [rdx + 4*rdi - 20] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi - 40], xmm0
	vmovss	xmm0, dword ptr [rdx + 4*rdi - 16] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi - 32], xmm0
	vmovss	xmm0, dword ptr [rdx + 4*rdi - 12] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi - 24], xmm0
	vmovss	xmm0, dword ptr [rdx + 4*rdi - 8] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi - 16], xmm0
	vmovss	xmm0, dword ptr [rdx + 4*rdi - 4] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi - 8], xmm0
	vmovss	xmm0, dword ptr [rdx + 4*rdi]   # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi], xmm0
	vmovss	xmm0, dword ptr [rdx + 4*rdi + 4] # xmm0 = mem[0],zero,zero,zero
	vcvtss2sd	xmm0, xmm0, xmm0
	vmovsd	qword ptr [rax + 8*rdi + 8], xmm0
	add	rdi, 8
	cmp	r15, rdi
	jne	.LBB0_27
	jmp	.LBB0_28
.LBB0_29:                               # %L327
	mov	rax, qword ptr [rbp - 56]       # 8-byte Reload
	mov	rcx, qword ptr [rbp - 104]      # 8-byte Reload
	mov	qword ptr [rax + 48], rcx
	add	rsp, 72
	pop	rbx
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	vzeroupper
	ret
.Lfunc_end0:
	.size	"julia__copy_active!_1214", .Lfunc_end0-"julia__copy_active!_1214"
                                        # -- End function
	.section	".note.GNU-stack","",@progbits
