	.file	"copyto!"
	.section	.ltext,"axl",@progbits
	.globl	"julia_copyto!_1238"            # -- Begin function julia_copyto!_1238
	.p2align	4
	.type	"julia_copyto!_1238",@function
"julia_copyto!_1238":                   # @"julia_copyto!_1238"
; Function Signature: copyto!(ProximalBase.BlockIterate{Float64, Array{Base.StepRange{Int64, Int64}, 1}}, ProximalBase.BlockIterate{Float32, Array{Base.StepRange{Int64, Int64}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: copyto!:dest <- [$rdi+0]
	#DEBUG_VALUE: copyto!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r13
	push	r12
	push	rbx
	sub	rsp, 40
	vxorps	xmm0, xmm0, xmm0
	vmovaps	xmmword ptr [rbp - 80], xmm0
	mov	qword ptr [rbp - 64], 0
	#APP
	mov	rax, qword ptr fs:[0]
	#NO_APP
	mov	r15, qword ptr [rax - 8]
	mov	qword ptr [rbp - 80], 4
	mov	rax, qword ptr [r15]
	mov	qword ptr [rbp - 72], rax
	lea	rax, [rbp - 80]
	mov	qword ptr [r15], rax
	mov	rax, qword ptr [rdi]
	mov	rax, qword ptr [rax + 16]
	mov	rcx, qword ptr [rsi]
	cmp	rax, qword ptr [rcx + 16]
	jne	.LBB0_26
# %bb.1:                                # %L10
	mov	r8, qword ptr [rsi + 8]
	cmp	qword ptr [rdi + 8], r8
	je	.LBB0_24
# %bb.2:                                # %L16
	mov	rax, qword ptr [rdi + 24]
	movabs	rcx, offset jl_nothing
	cmp	rax, qword ptr [rcx]
	je	.LBB0_7
# %bb.3:                                # %L20
	mov	rcx, qword ptr [rsi + 24]
	cmp	rax, rcx
	je	.LBB0_24
# %bb.4:                                # %guard_pass
	mov	rdx, qword ptr [rax - 8]
	and	rdx, -16
	mov	r9, qword ptr [rcx - 8]
	and	r9, -16
	cmp	rdx, r9
	jne	.LBB0_7
# %bb.5:                                # %L25
	movabs	r8, offset jl_egal__unboxed
	mov	rbx, rdi
	mov	rdi, rax
	mov	r14, rsi
	mov	rsi, rcx
	call	r8
	mov	rdi, rbx
	mov	rsi, r14
	test	al, 1
	jne	.LBB0_24
# %bb.6:                                # %L25.L28_crit_edge
	mov	rax, qword ptr [rdi + 24]
	mov	r8, qword ptr [rsi + 8]
.LBB0_7:                                # %L28
	cmp	rax, r8
	je	.LBB0_24
# %bb.8:                                # %L33
	mov	rcx, qword ptr [rdi + 8]
	cmp	qword ptr [rsi + 24], rcx
	je	.LBB0_24
# %bb.9:                                # %L33.L40_crit_edge
	mov	rax, qword ptr [r8 + 16]
	cmp	qword ptr [rcx + 16], rax
	jne	.LBB0_16
# %bb.10:                               # %L59
	test	rax, rax
	je	.LBB0_24
# %bb.11:                               # %L94
	mov	qword ptr [rbp - 48], r15       # 8-byte Spill
	mov	rcx, qword ptr [rcx]
	mov	rdx, qword ptr [r8]
	dec	rax
	mov	r8d, 16
	.p2align	4
.LBB0_12:                               # %L148
                                        # =>This Inner Loop Header: Depth=1
	mov	r9, qword ptr [rcx + r8]
	mov	r15, qword ptr [rcx + r8 - 16]
	mov	r11, qword ptr [rcx + r8 - 8]
	test	r11, r11
	setg	r13b
	mov	r10, qword ptr [rdx + r8]
	mov	rbx, qword ptr [rdx + r8 - 16]
	mov	r12, qword ptr [rdx + r8 - 8]
	cmp	r15, r9
	setge	r14b
	je	.LBB0_17
# %bb.13:                               # %L148
                                        #   in Loop: Header=BB0_12 Depth=1
	xor	r13b, r14b
	jne	.LBB0_17
# %bb.14:                               # %L165
                                        #   in Loop: Header=BB0_12 Depth=1
	test	r12, r12
	setg	r9b
	cmp	rbx, r10
	setl	r10b
	mov	r15, qword ptr [rbp - 48]       # 8-byte Reload
	je	.LBB0_16
# %bb.15:                               # %L165
                                        #   in Loop: Header=BB0_12 Depth=1
	xor	r9b, r10b
	jne	.LBB0_23
	jmp	.LBB0_16
	.p2align	4
.LBB0_17:                               # %L178
                                        #   in Loop: Header=BB0_12 Depth=1
	cmp	r15, r9
	jne	.LBB0_20
# %bb.18:                               # %L182
                                        #   in Loop: Header=BB0_12 Depth=1
	cmp	rbx, r10
	mov	r15, qword ptr [rbp - 48]       # 8-byte Reload
	jne	.LBB0_16
# %bb.19:                               # %L182
                                        #   in Loop: Header=BB0_12 Depth=1
	cmp	r9, rbx
	je	.LBB0_23
	jmp	.LBB0_16
	.p2align	4
.LBB0_20:                               # %L202
                                        #   in Loop: Header=BB0_12 Depth=1
	cmp	r15, rbx
	mov	r15, qword ptr [rbp - 48]       # 8-byte Reload
	jne	.LBB0_16
# %bb.21:                               # %L202
                                        #   in Loop: Header=BB0_12 Depth=1
	cmp	r11, r12
	jne	.LBB0_16
# %bb.22:                               # %L202
                                        #   in Loop: Header=BB0_12 Depth=1
	cmp	r9, r10
	jne	.LBB0_16
.LBB0_23:                               # %L206
                                        #   in Loop: Header=BB0_12 Depth=1
	sub	rax, 1
	jb	.LBB0_24
# %bb.27:                               # %guard_exit161
                                        #   in Loop: Header=BB0_12 Depth=1
	add	r8, 24
	jmp	.LBB0_12
.LBB0_24:                               # %L299
	movabs	rax, offset "j__copy_active!_1240"
	call	rax
.LBB0_25:                               # %common.ret
	mov	rcx, qword ptr [rbp - 72]
	mov	qword ptr [r15], rcx
	add	rsp, 40
	pop	rbx
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB0_16:                               # %L305
	movabs	rax, offset "j_copyto!_1241"
	call	rax
	jmp	.LBB0_25
.LBB0_26:                               # %L307
	movabs	rdi, offset ".Ljl_global#1244.jit"
	movabs	rax, offset j_DimensionMismatch_1243
	call	rax
	mov	rbx, rax
	mov	qword ptr [rbp - 64], rax
	mov	rdi, qword ptr [r15 + 16]
	movabs	rax, offset ijl_gc_small_alloc
	movabs	r14, 136082836598848
	mov	esi, 360
	mov	edx, 16
	mov	rcx, r14
	call	rax
	mov	qword ptr [rax - 8], r14
	mov	qword ptr [rax], rbx
	mov	qword ptr [rbp - 64], 0
	movabs	rcx, offset ijl_throw
	mov	rdi, rax
	call	rcx
.Lfunc_end0:
	.size	"julia_copyto!_1238", .Lfunc_end0-"julia_copyto!_1238"
                                        # -- End function
.set ".L+Main.Base.DimensionMismatch#1245.jit", 136082836598848
	.size	".L+Main.Base.DimensionMismatch#1245.jit", 8
.set ".Ljl_global#1244.jit", 136082965839056
	.size	".Ljl_global#1244.jit", 8
	.section	".note.GNU-stack","",@progbits
