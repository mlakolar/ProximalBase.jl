; Function Signature: _copy_active!(ProximalBase.BlockIterate{Float64, Array{Base.StepRange{Int64, Int64}, 1}}, ProximalBase.BlockIterate{Float64, Array{Base.StepRange{Int64, Int64}, 1}})
define nonnull ptr @"julia__copy_active!_1397"(ptr noundef nonnull align 8 dereferenceable(56) %"dest::BlockIterate", ptr noundef nonnull align 8 dereferenceable(56) %"src::BlockIterate") local_unnamed_addr #0 {
top:
  %"dest::BlockIterate.nactive_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 48
  %"dest::BlockIterate.nactive" = load i64, ptr %"dest::BlockIterate.nactive_ptr", align 8
  %".dest::BlockIterate.nactive" = call i64 @llvm.smax.i64(i64 %"dest::BlockIterate.nactive", i64 0)
  %0 = icmp slt i64 %"dest::BlockIterate.nactive", 1
  br i1 %0, label %L165, label %L18.preheader

L18.preheader:                                    ; preds = %top
  %"dest::BlockIterate.active_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 32
  %"dest::BlockIterate.active" = load atomic ptr, ptr %"dest::BlockIterate.active_ptr" unordered, align 8
  %memoryref_data = load ptr, ptr %"dest::BlockIterate.active", align 8
  %invariant.gep217 = getelementptr i8, ptr %memoryref_data, i64 -8
  %"src::BlockIterate.position_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 40
  %"src::BlockIterate.position" = load atomic ptr, ptr %"src::BlockIterate.position_ptr" unordered, align 8
  %memoryref_data8 = load ptr, ptr %"src::BlockIterate.position", align 8
  %"dest::BlockIterate.position_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 40
  %"dest::BlockIterate.position" = load atomic ptr, ptr %"dest::BlockIterate.position_ptr" unordered, align 8
  %memoryref_data49 = load ptr, ptr %"dest::BlockIterate.position", align 8
  %"dest::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 8
  %"dest::BlockIterate.groups" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %"dest::BlockIterate.storage" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  br label %L18

L18:                                              ; preds = %L135, %L18.preheader
  %value_phi4 = phi i64 [ %7, %L135 ], [ 1, %L18.preheader ]
  %memoryref_offset = shl i64 %value_phi4, 3
  %gep218 = getelementptr i8, ptr %invariant.gep217, i64 %memoryref_offset
  %1 = load i64, ptr %gep218, align 8
  %memoryref_offset10 = add i64 %1, -1
  %memoryref_byteoffset11 = shl i64 %memoryref_offset10, 3
  %memoryref_data16 = getelementptr inbounds i8, ptr %memoryref_data8, i64 %memoryref_byteoffset11
  %2 = load i64, ptr %memoryref_data16, align 8
  %.not = icmp eq i64 %2, 0
  br i1 %.not, label %L60, label %L135

L60:                                              ; preds = %L18
  %memoryref_data18 = load ptr, ptr %"dest::BlockIterate.groups", align 8
  %memoryref_byteoffset21 = mul i64 %memoryref_offset10, 24
  %memoryref_data26 = getelementptr inbounds i8, ptr %memoryref_data18, i64 %memoryref_byteoffset21
  %.sroa.0201.0.copyload = load i64, ptr %memoryref_data26, align 8
  %.sroa.2202.0.memoryref_data26.sroa_idx = getelementptr inbounds nuw i8, ptr %memoryref_data26, i64 8
  %.sroa.2202.0.copyload = load i64, ptr %.sroa.2202.0.memoryref_data26.sroa_idx, align 8
  %.sroa.4203.0.memoryref_data26.sroa_idx = getelementptr inbounds nuw i8, ptr %memoryref_data26, i64 16
  %.sroa.4203.0.copyload = load i64, ptr %.sroa.4203.0.memoryref_data26.sroa_idx, align 8
  %3 = icmp ne i64 %.sroa.0201.0.copyload, %.sroa.4203.0.copyload
  %4 = icmp sgt i64 %.sroa.2202.0.copyload, 0
  %5 = icmp slt i64 %.sroa.0201.0.copyload, %.sroa.4203.0.copyload
  %.not206.not = xor i1 %4, %5
  %.not207.not = and i1 %3, %.not206.not
  br i1 %.not207.not, label %L135, label %L101.preheader

L101.preheader:                                   ; preds = %L60
  %memoryref_data35 = load ptr, ptr %"dest::BlockIterate.storage", align 8
  %invariant.gep = getelementptr i8, ptr %memoryref_data35, i64 -8
  br label %L101

L101:                                             ; preds = %L101, %L101.preheader
  %value_phi33 = phi i64 [ %6, %L101 ], [ %.sroa.0201.0.copyload, %L101.preheader ]
  %memoryref_offset37 = shl i64 %value_phi33, 3
  %gep = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset37
  store i64 0, ptr %gep, align 8
  %.not209 = icmp eq i64 %value_phi33, %.sroa.4203.0.copyload
  %6 = add i64 %value_phi33, %.sroa.2202.0.copyload
  br i1 %.not209, label %L135, label %L101

L135:                                             ; preds = %L101, %L60, %L18
  %memoryref_data57 = getelementptr inbounds i8, ptr %memoryref_data49, i64 %memoryref_byteoffset11
  store i64 0, ptr %memoryref_data57, align 8
  %.not210 = icmp eq i64 %value_phi4, %".dest::BlockIterate.nactive"
  %7 = add nuw i64 %value_phi4, 1
  br i1 %.not210, label %L165, label %L18

L165:                                             ; preds = %L135, %top
  %"src::BlockIterate.nactive_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 48
  %"src::BlockIterate.nactive" = load i64, ptr %"src::BlockIterate.nactive_ptr", align 8
  %".src::BlockIterate.nactive" = call i64 @llvm.smax.i64(i64 %"src::BlockIterate.nactive", i64 0)
  %8 = icmp slt i64 %"src::BlockIterate.nactive", 1
  br i1 %8, label %L346, label %L182.preheader

L182.preheader:                                   ; preds = %L165
  %"src::BlockIterate.active_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 32
  %"src::BlockIterate.active" = load atomic ptr, ptr %"src::BlockIterate.active_ptr" unordered, align 8
  %memoryref_data68 = load ptr, ptr %"src::BlockIterate.active", align 8
  %"src::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 8
  %"src::BlockIterate.groups" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  %memoryref_data78 = load ptr, ptr %"src::BlockIterate.groups", align 8
  %"dest::BlockIterate.active_ptr122" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 32
  %"dest::BlockIterate.active123" = load atomic ptr, ptr %"dest::BlockIterate.active_ptr122" unordered, align 8
  %memoryref_data125 = load ptr, ptr %"dest::BlockIterate.active123", align 8
  %"dest::BlockIterate.position_ptr134" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 40
  %"dest::BlockIterate.position135" = load atomic ptr, ptr %"dest::BlockIterate.position_ptr134" unordered, align 8
  %memoryref_data137 = load ptr, ptr %"dest::BlockIterate.position135", align 8
  %"src::BlockIterate.storage" = load atomic ptr, ptr %"src::BlockIterate" unordered, align 8
  %"dest::BlockIterate.storage107" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  br label %L182

L182:                                             ; preds = %L297, %L182.preheader
  %value_phi65 = phi i64 [ %15, %L297 ], [ 1, %L182.preheader ]
  %memoryref_offset70 = shl i64 %value_phi65, 3
  %memoryref_byteoffset71 = add i64 %memoryref_offset70, -8
  %memoryref_data76 = getelementptr inbounds i8, ptr %memoryref_data68, i64 %memoryref_byteoffset71
  %9 = load i64, ptr %memoryref_data76, align 8
  %memoryref_offset80 = add i64 %9, -1
  %memoryref_byteoffset81 = mul i64 %memoryref_offset80, 24
  %memoryref_data86 = getelementptr inbounds i8, ptr %memoryref_data78, i64 %memoryref_byteoffset81
  %.sroa.0.0.copyload = load i64, ptr %memoryref_data86, align 8
  %.sroa.2.0.memoryref_data86.sroa_idx = getelementptr inbounds nuw i8, ptr %memoryref_data86, i64 8
  %.sroa.2.0.copyload = load i64, ptr %.sroa.2.0.memoryref_data86.sroa_idx, align 8
  %.sroa.4.0.memoryref_data86.sroa_idx = getelementptr inbounds nuw i8, ptr %memoryref_data86, i64 16
  %.sroa.4.0.copyload = load i64, ptr %.sroa.4.0.memoryref_data86.sroa_idx, align 8
  %10 = icmp ne i64 %.sroa.0.0.copyload, %.sroa.4.0.copyload
  %11 = icmp sgt i64 %.sroa.2.0.copyload, 0
  %12 = icmp slt i64 %.sroa.0.0.copyload, %.sroa.4.0.copyload
  %.not212.not = xor i1 %11, %12
  %.not213.not = and i1 %10, %.not212.not
  br i1 %.not213.not, label %L297, label %L244.preheader

L244.preheader:                                   ; preds = %L182
  %memoryref_data98 = load ptr, ptr %"src::BlockIterate.storage", align 8
  %memoryref_data109 = load ptr, ptr %"dest::BlockIterate.storage107", align 8
  br label %L244

L244:                                             ; preds = %L244, %L244.preheader
  %value_phi96 = phi i64 [ %14, %L244 ], [ %.sroa.0.0.copyload, %L244.preheader ]
  %memoryref_offset100 = shl i64 %value_phi96, 3
  %memoryref_byteoffset101 = add i64 %memoryref_offset100, -8
  %memoryref_data106 = getelementptr inbounds i8, ptr %memoryref_data98, i64 %memoryref_byteoffset101
  %13 = load double, ptr %memoryref_data106, align 8
  %memoryref_data117 = getelementptr inbounds i8, ptr %memoryref_data109, i64 %memoryref_byteoffset101
  store double %13, ptr %memoryref_data117, align 8
  %.not215 = icmp eq i64 %value_phi96, %.sroa.4.0.copyload
  %14 = add i64 %value_phi96, %.sroa.2.0.copyload
  br i1 %.not215, label %L297, label %L244

L297:                                             ; preds = %L244, %L182
  %memoryref_data133 = getelementptr inbounds i8, ptr %memoryref_data125, i64 %memoryref_byteoffset71
  store i64 %9, ptr %memoryref_data133, align 8
  %memoryref_byteoffset140 = shl i64 %memoryref_offset80, 3
  %memoryref_data145 = getelementptr inbounds i8, ptr %memoryref_data137, i64 %memoryref_byteoffset140
  store i64 %value_phi65, ptr %memoryref_data145, align 8
  %.not216 = icmp eq i64 %value_phi65, %".src::BlockIterate.nactive"
  %15 = add nuw i64 %value_phi65, 1
  br i1 %.not216, label %L346, label %L182

L346:                                             ; preds = %L297, %L165
  store i64 %"src::BlockIterate.nactive", ptr %"dest::BlockIterate.nactive_ptr", align 8
  ret ptr %"dest::BlockIterate"
}
