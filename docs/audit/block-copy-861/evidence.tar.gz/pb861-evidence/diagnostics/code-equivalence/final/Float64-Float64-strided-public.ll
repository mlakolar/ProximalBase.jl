; Function Signature: copyto!(ProximalBase.BlockIterate{Float64, Array{Base.StepRange{Int64, Int64}, 1}}, ProximalBase.BlockIterate{Float64, Array{Base.StepRange{Int64, Int64}, 1}})
define nonnull ptr @"julia_copyto!_1371"(ptr noundef nonnull align 8 dereferenceable(56) %"dest::BlockIterate", ptr noundef nonnull align 8 dereferenceable(56) %"src::BlockIterate") local_unnamed_addr #0 {
top:
  %gcframe5 = alloca [3 x ptr], align 16
  call void @llvm.memset.p0.i64(ptr align 16 %gcframe5, i8 0, i64 24, i1 true)
  %thread_ptr = call ptr asm "movq %fs:0, $0", "=r"() #15
  %tls_ppgcstack = getelementptr inbounds i8, ptr %thread_ptr, i64 -8
  %tls_pgcstack = load ptr, ptr %tls_ppgcstack, align 8
  store i64 4, ptr %gcframe5, align 8
  %frame.prev = getelementptr inbounds nuw i8, ptr %gcframe5, i64 8
  %task.gcstack = load ptr, ptr %tls_pgcstack, align 8
  store ptr %task.gcstack, ptr %frame.prev, align 8
  store ptr %gcframe5, ptr %tls_pgcstack, align 8
  %.not = icmp eq ptr %"dest::BlockIterate", %"src::BlockIterate"
  br i1 %.not, label %common.ret, label %L4

common.ret:                                       ; preds = %L307, %L301, %top
  %common.ret.op = phi ptr [ %23, %L301 ], [ %24, %L307 ], [ %"dest::BlockIterate", %top ]
  %frame.prev417 = load ptr, ptr %frame.prev, align 8
  store ptr %frame.prev417, ptr %tls_pgcstack, align 8
  ret ptr %common.ret.op

L4:                                               ; preds = %top
  %"dest::BlockIterate.storage" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  %"dest::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.storage", i64 16
  %"dest::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"dest::BlockIterate.storage.size_ptr", align 8
  %"src::BlockIterate.storage" = load atomic ptr, ptr %"src::BlockIterate" unordered, align 8
  %"src::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate.storage", i64 16
  %"src::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"src::BlockIterate.storage.size_ptr", align 8
  %.not294 = icmp eq i64 %"dest::BlockIterate.storage.size_ptr.copyload", %"src::BlockIterate.storage.size_ptr.copyload"
  br i1 %.not294, label %L12, label %L309

L12:                                              ; preds = %L4
  %"dest::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 8
  %"dest::BlockIterate.groups" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %"src::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 8
  %"src::BlockIterate.groups" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  %0 = icmp eq ptr %"dest::BlockIterate.groups", %"src::BlockIterate.groups"
  br i1 %0, label %L301, label %L18

L18:                                              ; preds = %L12
  %"dest::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 24
  %"dest::BlockIterate.layout_cache" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %jl_nothing = load ptr, ptr @jl_nothing, align 8
  %1 = icmp eq ptr %"dest::BlockIterate.layout_cache", %jl_nothing
  br i1 %1, label %L30, label %L22

L22:                                              ; preds = %L18
  %"src::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr" unordered, align 8
  %.not295 = icmp eq ptr %"dest::BlockIterate.layout_cache", %"src::BlockIterate.layout_cache"
  br i1 %.not295, label %L301, label %guard_pass

L27:                                              ; preds = %guard_pass
  %2 = call i32 @jl_egal__unboxed(ptr nonnull %"dest::BlockIterate.layout_cache", ptr nonnull %"src::BlockIterate.layout_cache", i64 %27)
  %3 = trunc i32 %2 to i1
  br i1 %3, label %L301, label %L27.L30_crit_edge

L27.L30_crit_edge:                                ; preds = %L27
  %"dest::BlockIterate.layout_cache114.pre" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %"src::BlockIterate.groups116.pre" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  br label %L30

L30:                                              ; preds = %guard_pass, %L27.L30_crit_edge, %L18
  %gclift409 = phi ptr [ %"src::BlockIterate.groups116.pre", %L27.L30_crit_edge ], [ %"src::BlockIterate.groups", %L18 ], [ %"src::BlockIterate.groups", %guard_pass ]
  %gclift = phi ptr [ %"dest::BlockIterate.layout_cache114.pre", %L27.L30_crit_edge ], [ %"dest::BlockIterate.layout_cache", %L18 ], [ %"dest::BlockIterate.layout_cache", %guard_pass ]
  %4 = icmp eq ptr %gclift, %gclift409
  br i1 %4, label %L301, label %L35

L35:                                              ; preds = %L30
  %"src::BlockIterate.layout_cache_ptr117" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache118" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr117" unordered, align 8
  %"dest::BlockIterate.groups120" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %5 = icmp eq ptr %"src::BlockIterate.layout_cache118", %"dest::BlockIterate.groups120"
  br i1 %5, label %L301, label %L35.L42_crit_edge

L35.L42_crit_edge:                                ; preds = %L35
  %"src::BlockIterate.groups5.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %gclift409, i64 16
  %"src::BlockIterate.groups5.size_ptr.copyload.pre" = load i64, ptr %"src::BlockIterate.groups5.size_ptr.phi.trans.insert", align 8
  %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.groups120", i64 16
  %"dest::BlockIterate.groups3.size_ptr.copyload.pre" = load i64, ptr %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert", align 8
  %.not296 = icmp eq i64 %"dest::BlockIterate.groups3.size_ptr.copyload.pre", %"src::BlockIterate.groups5.size_ptr.copyload.pre"
  br i1 %.not296, label %L61, label %L307

L61:                                              ; preds = %L35.L42_crit_edge
  %.not297.not = icmp eq i64 %"src::BlockIterate.groups5.size_ptr.copyload.pre", 0
  br i1 %.not297.not, label %L301, label %L96

L96:                                              ; preds = %L61
  %memoryref_data = load ptr, ptr %"dest::BlockIterate.groups120", align 8
  %memoryref_data91 = load ptr, ptr %gclift409, align 8
  %6 = add i64 %"src::BlockIterate.groups5.size_ptr.copyload.pre", 1
  br label %L150

L150:                                             ; preds = %guard_exit161, %L96
  %.sroa.0204.0.in = phi ptr [ %memoryref_data91, %L96 ], [ %memoryref_data66, %guard_exit161 ]
  %.sroa.0217.0.in = phi ptr [ %memoryref_data, %L96 ], [ %memoryref_data44, %guard_exit161 ]
  %value_phi21 = phi i64 [ 2, %L96 ], [ %31, %guard_exit161 ]
  %.sroa.7222.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0217.0.in, i64 16
  %.sroa.7222.0 = load i64, ptr %.sroa.7222.0.in, align 8
  %.sroa.6219.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0217.0.in, i64 8
  %.sroa.6219.0 = load i64, ptr %.sroa.6219.0.in, align 8
  %.sroa.0217.0 = load i64, ptr %.sroa.0217.0.in, align 8
  %.sroa.7.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0204.0.in, i64 16
  %.sroa.7.0 = load i64, ptr %.sroa.7.0.in, align 8
  %.sroa.6206.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0204.0.in, i64 8
  %.sroa.6206.0 = load i64, ptr %.sroa.6206.0.in, align 8
  %.sroa.0204.0 = load i64, ptr %.sroa.0204.0.in, align 8
  %7 = icmp eq i64 %.sroa.0217.0, %.sroa.7222.0
  %8 = icmp sgt i64 %.sroa.6219.0, 0
  %9 = icmp sge i64 %.sroa.0217.0, %.sroa.7222.0
  %.not300 = xor i1 %8, %9
  %.not301 = or i1 %7, %.not300
  br i1 %.not301, label %L180, label %L167

L167:                                             ; preds = %L150
  %10 = icmp ne i64 %.sroa.0204.0, %.sroa.7.0
  %11 = icmp sgt i64 %.sroa.6206.0, 0
  %12 = icmp slt i64 %.sroa.0204.0, %.sroa.7.0
  %13 = xor i1 %11, %12
  %14 = and i1 %10, %13
  br i1 %14, label %L208, label %L307

L180:                                             ; preds = %L150
  br i1 %7, label %L184, label %L204

L184:                                             ; preds = %L180
  %15 = icmp eq i64 %.sroa.0204.0, %.sroa.7.0
  %16 = icmp eq i64 %.sroa.7222.0, %.sroa.0204.0
  %17 = and i1 %15, %16
  br i1 %17, label %L208, label %L307

L204:                                             ; preds = %L180
  %18 = icmp eq i64 %.sroa.0217.0, %.sroa.0204.0
  %19 = icmp eq i64 %.sroa.6219.0, %.sroa.6206.0
  %20 = and i1 %18, %19
  %21 = icmp eq i64 %.sroa.7222.0, %.sroa.7.0
  %22 = and i1 %20, %21
  br i1 %22, label %L208, label %L307

L208:                                             ; preds = %L204, %L184, %L167
  %exitcond.not.not = icmp eq i64 %value_phi21, %6
  br i1 %exitcond.not.not, label %L301, label %guard_exit161

L301:                                             ; preds = %L208, %L61, %L35, %L30, %L27, %L22, %L12
  %23 = call nonnull ptr @"j__copy_active!_1373"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L307:                                             ; preds = %L204, %L184, %L167, %L35.L42_crit_edge
  %24 = call nonnull ptr @"j_copyto!_1374"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L309:                                             ; preds = %L4
  %25 = call [1 x ptr] @j_DimensionMismatch_1376(ptr nonnull @"jl_global#1377.jit")
  %gc_slot_addr_0 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 16
  %26 = extractvalue [1 x ptr] %25, 0
  store ptr %26, ptr %gc_slot_addr_0, align 8
  %ptls_field = getelementptr inbounds nuw i8, ptr %tls_pgcstack, i64 16
  %ptls_load = load ptr, ptr %ptls_field, align 8
  %"box::DimensionMismatch" = call noalias nonnull align 8 dereferenceable(16) ptr @ijl_gc_small_alloc(ptr %ptls_load, i32 360, i32 16, i64 136082836598848) #11
  %"box::DimensionMismatch.tag_addr" = getelementptr inbounds i8, ptr %"box::DimensionMismatch", i64 -8
  store atomic i64 136082836598848, ptr %"box::DimensionMismatch.tag_addr" unordered, align 8
  store ptr %26, ptr %"box::DimensionMismatch", align 8
  store ptr null, ptr %gc_slot_addr_0, align 8
  call void @ijl_throw(ptr nonnull %"box::DimensionMismatch")
  unreachable

guard_pass:                                       ; preds = %L22
  %"dest::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"dest::BlockIterate.layout_cache", i64 -8
  %"dest::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"dest::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %27 = and i64 %"dest::BlockIterate.layout_cache.tag", -16
  %"src::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"src::BlockIterate.layout_cache", i64 -8
  %"src::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"src::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %28 = and i64 %"src::BlockIterate.layout_cache.tag", -16
  %29 = icmp eq i64 %27, %28
  br i1 %29, label %L27, label %L30

guard_exit161:                                    ; preds = %L208
  %30 = mul i64 %value_phi21, 24
  %memoryref_byteoffset = add i64 %30, -24
  %memoryref_data44 = getelementptr inbounds i8, ptr %memoryref_data, i64 %memoryref_byteoffset
  %31 = add i64 %value_phi21, 1
  %memoryref_data66 = getelementptr inbounds i8, ptr %memoryref_data91, i64 %memoryref_byteoffset
  br label %L150
}
