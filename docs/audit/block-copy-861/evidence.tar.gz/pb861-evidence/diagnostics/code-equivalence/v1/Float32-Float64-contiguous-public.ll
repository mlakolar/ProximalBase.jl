; Function Signature: copyto!(ProximalBase.BlockIterate{Float32, Array{Base.UnitRange{Int64}, 1}}, ProximalBase.BlockIterate{Float64, Array{Base.UnitRange{Int64}, 1}})
define nonnull ptr @"julia_copyto!_979"(ptr noundef nonnull align 8 dereferenceable(56) %"dest::BlockIterate", ptr noundef nonnull align 8 dereferenceable(56) %"src::BlockIterate") local_unnamed_addr #0 {
top:
  %gcframe5 = alloca [3 x ptr], align 16
  call void @llvm.memset.p0.i64(ptr align 16 %gcframe5, i8 0, i64 24, i1 true)
  %thread_ptr = call ptr asm "movq %fs:0, $0", "=r"() #15
  %tls_ppgcstack = getelementptr inbounds i8, ptr %thread_ptr, i64 -8
  %tls_pgcstack = load ptr, ptr %tls_ppgcstack, align 8
  store i64 4, ptr %gcframe5, align 8
  %frame.prev = getelementptr inbounds nuw i8, ptr %gcframe5, i64 8
  %task.gcstack = load ptr, ptr %tls_pgcstack, align 8
  store ptr %task.gcstack, ptr %frame.prev, align 8
  store ptr %gcframe5, ptr %tls_pgcstack, align 8
  %"dest::BlockIterate.storage" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  %"dest::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.storage", i64 16
  %"dest::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"dest::BlockIterate.storage.size_ptr", align 8
  %"src::BlockIterate.storage" = load atomic ptr, ptr %"src::BlockIterate" unordered, align 8
  %"src::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate.storage", i64 16
  %"src::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"src::BlockIterate.storage.size_ptr", align 8
  %.not = icmp eq i64 %"dest::BlockIterate.storage.size_ptr.copyload", %"src::BlockIterate.storage.size_ptr.copyload"
  br i1 %.not, label %L10, label %L271

L10:                                              ; preds = %top
  %"dest::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 8
  %"dest::BlockIterate.groups" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %"src::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 8
  %"src::BlockIterate.groups" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  %0 = icmp eq ptr %"dest::BlockIterate.groups", %"src::BlockIterate.groups"
  br i1 %0, label %L263, label %L16

L16:                                              ; preds = %L10
  %"dest::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 24
  %"dest::BlockIterate.layout_cache" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %jl_nothing = load ptr, ptr @jl_nothing, align 8
  %1 = icmp eq ptr %"dest::BlockIterate.layout_cache", %jl_nothing
  br i1 %1, label %L28, label %L20

L20:                                              ; preds = %L16
  %"src::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr" unordered, align 8
  %.not272 = icmp eq ptr %"dest::BlockIterate.layout_cache", %"src::BlockIterate.layout_cache"
  br i1 %.not272, label %L263, label %guard_pass

L25:                                              ; preds = %guard_pass
  %2 = call i32 @jl_egal__unboxed(ptr nonnull %"dest::BlockIterate.layout_cache", ptr nonnull %"src::BlockIterate.layout_cache", i64 %19)
  %3 = trunc i32 %2 to i1
  br i1 %3, label %L263, label %L25.L28_crit_edge

L25.L28_crit_edge:                                ; preds = %L25
  %"dest::BlockIterate.layout_cache104.pre" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %"src::BlockIterate.groups106.pre" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  br label %L28

L28:                                              ; preds = %guard_pass, %L25.L28_crit_edge, %L16
  %gclift358 = phi ptr [ %"src::BlockIterate.groups106.pre", %L25.L28_crit_edge ], [ %"src::BlockIterate.groups", %L16 ], [ %"src::BlockIterate.groups", %guard_pass ]
  %gclift = phi ptr [ %"dest::BlockIterate.layout_cache104.pre", %L25.L28_crit_edge ], [ %"dest::BlockIterate.layout_cache", %L16 ], [ %"dest::BlockIterate.layout_cache", %guard_pass ]
  %4 = icmp eq ptr %gclift, %gclift358
  br i1 %4, label %L263, label %L33

L33:                                              ; preds = %L28
  %"src::BlockIterate.layout_cache_ptr107" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache108" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr107" unordered, align 8
  %"dest::BlockIterate.groups110" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %5 = icmp eq ptr %"src::BlockIterate.layout_cache108", %"dest::BlockIterate.groups110"
  br i1 %5, label %L263, label %L33.L40_crit_edge

L33.L40_crit_edge:                                ; preds = %L33
  %"src::BlockIterate.groups5.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %gclift358, i64 16
  %"src::BlockIterate.groups5.size_ptr.copyload.pre" = load i64, ptr %"src::BlockIterate.groups5.size_ptr.phi.trans.insert", align 8
  %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.groups110", i64 16
  %"dest::BlockIterate.groups3.size_ptr.copyload.pre" = load i64, ptr %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert", align 8
  %.not273 = icmp eq i64 %"dest::BlockIterate.groups3.size_ptr.copyload.pre", %"src::BlockIterate.groups5.size_ptr.copyload.pre"
  br i1 %.not273, label %L59, label %L269

L59:                                              ; preds = %L33.L40_crit_edge
  %.not274.not = icmp eq i64 %"src::BlockIterate.groups5.size_ptr.copyload.pre", 0
  br i1 %.not274.not, label %L263, label %L94

L94:                                              ; preds = %L59
  %memoryref_data = load ptr, ptr %"dest::BlockIterate.groups110", align 8
  %6 = getelementptr inbounds nuw i8, ptr %memoryref_data, i64 8
  %memoryref_data13.copyload14 = load i64, ptr %6, align 8
  %memoryref_data13.copyload = load i64, ptr %memoryref_data, align 8
  %memoryref_data80 = load ptr, ptr %gclift358, align 8
  %7 = getelementptr inbounds nuw i8, ptr %memoryref_data80, i64 8
  %memoryref_data86.copyload87 = load i64, ptr %7, align 8
  %memoryref_data86.copyload = load i64, ptr %memoryref_data80, align 8
  %8 = icmp slt i64 %memoryref_data13.copyload14, %memoryref_data13.copyload
  %9 = icmp slt i64 %memoryref_data86.copyload87, %memoryref_data86.copyload
  %10 = and i1 %8, %9
  %11 = icmp eq i64 %memoryref_data13.copyload, %memoryref_data86.copyload
  %12 = icmp eq i64 %memoryref_data13.copyload14, %memoryref_data86.copyload87
  %13 = and i1 %12, %11
  %14 = or i1 %10, %13
  br i1 %14, label %L170.lr.ph, label %L269

L170:                                             ; preds = %guard_exit164, %L170.lr.ph
  %value_phi23352 = phi i64 [ 2, %L170.lr.ph ], [ %25, %guard_exit164 ]
  %exitcond353.not.not = icmp eq i64 %value_phi23352, %22
  br i1 %exitcond353.not.not, label %L263, label %guard_exit164

common.ret:                                       ; preds = %L269, %L263
  %common.ret.op = phi ptr [ %15, %L263 ], [ %16, %L269 ]
  %frame.prev364 = load ptr, ptr %frame.prev, align 8
  store ptr %frame.prev364, ptr %tls_pgcstack, align 8
  ret ptr %common.ret.op

L263:                                             ; preds = %L170, %L59, %L33, %L28, %L25, %L20, %L10
  %15 = call nonnull ptr @"j__copy_active!_981"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L269:                                             ; preds = %guard_exit164, %L94, %L33.L40_crit_edge
  %16 = call nonnull ptr @"j_copyto!_982"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L271:                                             ; preds = %top
  %17 = call [1 x ptr] @j_DimensionMismatch_984(ptr nonnull @"jl_global#985.jit")
  %gc_slot_addr_0 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 16
  %18 = extractvalue [1 x ptr] %17, 0
  store ptr %18, ptr %gc_slot_addr_0, align 8
  %ptls_field = getelementptr inbounds nuw i8, ptr %tls_pgcstack, i64 16
  %ptls_load = load ptr, ptr %ptls_field, align 8
  %"box::DimensionMismatch" = call noalias nonnull align 8 dereferenceable(16) ptr @ijl_gc_small_alloc(ptr %ptls_load, i32 360, i32 16, i64 140702277349440) #11
  %"box::DimensionMismatch.tag_addr" = getelementptr inbounds i8, ptr %"box::DimensionMismatch", i64 -8
  store atomic i64 140702277349440, ptr %"box::DimensionMismatch.tag_addr" unordered, align 8
  store ptr %18, ptr %"box::DimensionMismatch", align 8
  store ptr null, ptr %gc_slot_addr_0, align 8
  call void @ijl_throw(ptr nonnull %"box::DimensionMismatch")
  unreachable

guard_pass:                                       ; preds = %L20
  %"dest::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"dest::BlockIterate.layout_cache", i64 -8
  %"dest::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"dest::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %19 = and i64 %"dest::BlockIterate.layout_cache.tag", -16
  %"src::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"src::BlockIterate.layout_cache", i64 -8
  %"src::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"src::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %20 = and i64 %"src::BlockIterate.layout_cache.tag", -16
  %21 = icmp eq i64 %19, %20
  br i1 %21, label %L25, label %L28

L170.lr.ph:                                       ; preds = %L94
  %22 = add i64 %"src::BlockIterate.groups5.size_ptr.copyload.pre", 1
  br label %L170

guard_exit164:                                    ; preds = %L170
  %23 = shl i64 %value_phi23352, 4
  %memoryref_byteoffset = add i64 %23, -16
  %memoryref_data43 = getelementptr inbounds i8, ptr %memoryref_data, i64 %memoryref_byteoffset
  %memoryref_data43.copyload = load i64, ptr %memoryref_data43, align 8
  %24 = getelementptr inbounds nuw i8, ptr %memoryref_data43, i64 8
  %memoryref_data43.copyload44 = load i64, ptr %24, align 8
  %25 = add i64 %value_phi23352, 1
  %memoryref_data66 = getelementptr inbounds i8, ptr %memoryref_data80, i64 %memoryref_byteoffset
  %26 = getelementptr inbounds nuw i8, ptr %memoryref_data66, i64 8
  %memoryref_data66.copyload67 = load i64, ptr %26, align 8
  %memoryref_data66.copyload = load i64, ptr %memoryref_data66, align 8
  %27 = icmp slt i64 %memoryref_data43.copyload44, %memoryref_data43.copyload
  %28 = icmp slt i64 %memoryref_data66.copyload67, %memoryref_data66.copyload
  %29 = and i1 %27, %28
  %30 = icmp eq i64 %memoryref_data43.copyload, %memoryref_data66.copyload
  %31 = icmp eq i64 %memoryref_data43.copyload44, %memoryref_data66.copyload67
  %32 = and i1 %31, %30
  %33 = or i1 %29, %32
  br i1 %33, label %L170, label %L269
}
