; Function Signature: copyto!(ProximalBase.BlockIterate{Float64, Array{Base.StepRange{Int64, Int64}, 1}}, ProximalBase.BlockIterate{Float32, Array{Base.StepRange{Int64, Int64}, 1}})
define nonnull ptr @"julia_copyto!_1225"(ptr noundef nonnull align 8 dereferenceable(56) %"dest::BlockIterate", ptr noundef nonnull align 8 dereferenceable(56) %"src::BlockIterate") local_unnamed_addr #0 {
top:
  %gcframe5 = alloca [3 x ptr], align 16
  call void @llvm.memset.p0.i64(ptr align 16 %gcframe5, i8 0, i64 24, i1 true)
  %thread_ptr = call ptr asm "movq %fs:0, $0", "=r"() #15
  %tls_ppgcstack = getelementptr inbounds i8, ptr %thread_ptr, i64 -8
  %tls_pgcstack = load ptr, ptr %tls_ppgcstack, align 8
  store i64 4, ptr %gcframe5, align 8
  %frame.prev = getelementptr inbounds nuw i8, ptr %gcframe5, i64 8
  %task.gcstack = load ptr, ptr %tls_pgcstack, align 8
  store ptr %task.gcstack, ptr %frame.prev, align 8
  store ptr %gcframe5, ptr %tls_pgcstack, align 8
  %"dest::BlockIterate.storage" = load atomic ptr, ptr %"dest::BlockIterate" unordered, align 8
  %"dest::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.storage", i64 16
  %"dest::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"dest::BlockIterate.storage.size_ptr", align 8
  %"src::BlockIterate.storage" = load atomic ptr, ptr %"src::BlockIterate" unordered, align 8
  %"src::BlockIterate.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate.storage", i64 16
  %"src::BlockIterate.storage.size_ptr.copyload" = load i64, ptr %"src::BlockIterate.storage.size_ptr", align 8
  %.not = icmp eq i64 %"dest::BlockIterate.storage.size_ptr.copyload", %"src::BlockIterate.storage.size_ptr.copyload"
  br i1 %.not, label %L10, label %L307

L10:                                              ; preds = %top
  %"dest::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 8
  %"dest::BlockIterate.groups" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %"src::BlockIterate.groups_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 8
  %"src::BlockIterate.groups" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  %0 = icmp eq ptr %"dest::BlockIterate.groups", %"src::BlockIterate.groups"
  br i1 %0, label %L299, label %L16

L16:                                              ; preds = %L10
  %"dest::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate", i64 24
  %"dest::BlockIterate.layout_cache" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %jl_nothing = load ptr, ptr @jl_nothing, align 8
  %1 = icmp eq ptr %"dest::BlockIterate.layout_cache", %jl_nothing
  br i1 %1, label %L28, label %L20

L20:                                              ; preds = %L16
  %"src::BlockIterate.layout_cache_ptr" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr" unordered, align 8
  %.not294 = icmp eq ptr %"dest::BlockIterate.layout_cache", %"src::BlockIterate.layout_cache"
  br i1 %.not294, label %L299, label %guard_pass

L25:                                              ; preds = %guard_pass
  %2 = call i32 @jl_egal__unboxed(ptr nonnull %"dest::BlockIterate.layout_cache", ptr nonnull %"src::BlockIterate.layout_cache", i64 %27)
  %3 = trunc i32 %2 to i1
  br i1 %3, label %L299, label %L25.L28_crit_edge

L25.L28_crit_edge:                                ; preds = %L25
  %"dest::BlockIterate.layout_cache114.pre" = load atomic ptr, ptr %"dest::BlockIterate.layout_cache_ptr" unordered, align 8
  %"src::BlockIterate.groups116.pre" = load atomic ptr, ptr %"src::BlockIterate.groups_ptr" unordered, align 8
  br label %L28

L28:                                              ; preds = %guard_pass, %L25.L28_crit_edge, %L16
  %gclift408 = phi ptr [ %"src::BlockIterate.groups116.pre", %L25.L28_crit_edge ], [ %"src::BlockIterate.groups", %L16 ], [ %"src::BlockIterate.groups", %guard_pass ]
  %gclift = phi ptr [ %"dest::BlockIterate.layout_cache114.pre", %L25.L28_crit_edge ], [ %"dest::BlockIterate.layout_cache", %L16 ], [ %"dest::BlockIterate.layout_cache", %guard_pass ]
  %4 = icmp eq ptr %gclift, %gclift408
  br i1 %4, label %L299, label %L33

L33:                                              ; preds = %L28
  %"src::BlockIterate.layout_cache_ptr117" = getelementptr inbounds nuw i8, ptr %"src::BlockIterate", i64 24
  %"src::BlockIterate.layout_cache118" = load atomic ptr, ptr %"src::BlockIterate.layout_cache_ptr117" unordered, align 8
  %"dest::BlockIterate.groups120" = load atomic ptr, ptr %"dest::BlockIterate.groups_ptr" unordered, align 8
  %5 = icmp eq ptr %"src::BlockIterate.layout_cache118", %"dest::BlockIterate.groups120"
  br i1 %5, label %L299, label %L33.L40_crit_edge

L33.L40_crit_edge:                                ; preds = %L33
  %"src::BlockIterate.groups5.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %gclift408, i64 16
  %"src::BlockIterate.groups5.size_ptr.copyload.pre" = load i64, ptr %"src::BlockIterate.groups5.size_ptr.phi.trans.insert", align 8
  %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert" = getelementptr inbounds nuw i8, ptr %"dest::BlockIterate.groups120", i64 16
  %"dest::BlockIterate.groups3.size_ptr.copyload.pre" = load i64, ptr %"dest::BlockIterate.groups3.size_ptr.phi.trans.insert", align 8
  %.not295 = icmp eq i64 %"dest::BlockIterate.groups3.size_ptr.copyload.pre", %"src::BlockIterate.groups5.size_ptr.copyload.pre"
  br i1 %.not295, label %L59, label %L305

L59:                                              ; preds = %L33.L40_crit_edge
  %.not296.not = icmp eq i64 %"src::BlockIterate.groups5.size_ptr.copyload.pre", 0
  br i1 %.not296.not, label %L299, label %L94

L94:                                              ; preds = %L59
  %memoryref_data = load ptr, ptr %"dest::BlockIterate.groups120", align 8
  %memoryref_data91 = load ptr, ptr %gclift408, align 8
  %6 = add i64 %"src::BlockIterate.groups5.size_ptr.copyload.pre", 1
  br label %L148

L148:                                             ; preds = %guard_exit161, %L94
  %.sroa.0204.0.in = phi ptr [ %memoryref_data91, %L94 ], [ %memoryref_data66, %guard_exit161 ]
  %.sroa.0217.0.in = phi ptr [ %memoryref_data, %L94 ], [ %memoryref_data44, %guard_exit161 ]
  %value_phi21 = phi i64 [ 2, %L94 ], [ %31, %guard_exit161 ]
  %.sroa.7222.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0217.0.in, i64 16
  %.sroa.7222.0 = load i64, ptr %.sroa.7222.0.in, align 8
  %.sroa.6219.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0217.0.in, i64 8
  %.sroa.6219.0 = load i64, ptr %.sroa.6219.0.in, align 8
  %.sroa.0217.0 = load i64, ptr %.sroa.0217.0.in, align 8
  %.sroa.7.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0204.0.in, i64 16
  %.sroa.7.0 = load i64, ptr %.sroa.7.0.in, align 8
  %.sroa.6206.0.in = getelementptr inbounds nuw i8, ptr %.sroa.0204.0.in, i64 8
  %.sroa.6206.0 = load i64, ptr %.sroa.6206.0.in, align 8
  %.sroa.0204.0 = load i64, ptr %.sroa.0204.0.in, align 8
  %7 = icmp eq i64 %.sroa.0217.0, %.sroa.7222.0
  %8 = icmp sgt i64 %.sroa.6219.0, 0
  %9 = icmp sge i64 %.sroa.0217.0, %.sroa.7222.0
  %.not299 = xor i1 %8, %9
  %.not300 = or i1 %7, %.not299
  br i1 %.not300, label %L178, label %L165

L165:                                             ; preds = %L148
  %10 = icmp ne i64 %.sroa.0204.0, %.sroa.7.0
  %11 = icmp sgt i64 %.sroa.6206.0, 0
  %12 = icmp slt i64 %.sroa.0204.0, %.sroa.7.0
  %13 = xor i1 %11, %12
  %14 = and i1 %10, %13
  br i1 %14, label %L206, label %L305

L178:                                             ; preds = %L148
  br i1 %7, label %L182, label %L202

L182:                                             ; preds = %L178
  %15 = icmp eq i64 %.sroa.0204.0, %.sroa.7.0
  %16 = icmp eq i64 %.sroa.7222.0, %.sroa.0204.0
  %17 = and i1 %15, %16
  br i1 %17, label %L206, label %L305

L202:                                             ; preds = %L178
  %18 = icmp eq i64 %.sroa.0217.0, %.sroa.0204.0
  %19 = icmp eq i64 %.sroa.6219.0, %.sroa.6206.0
  %20 = and i1 %18, %19
  %21 = icmp eq i64 %.sroa.7222.0, %.sroa.7.0
  %22 = and i1 %20, %21
  br i1 %22, label %L206, label %L305

L206:                                             ; preds = %L202, %L182, %L165
  %exitcond.not.not = icmp eq i64 %value_phi21, %6
  br i1 %exitcond.not.not, label %L299, label %guard_exit161

common.ret:                                       ; preds = %L305, %L299
  %common.ret.op = phi ptr [ %23, %L299 ], [ %24, %L305 ]
  %frame.prev416 = load ptr, ptr %frame.prev, align 8
  store ptr %frame.prev416, ptr %tls_pgcstack, align 8
  ret ptr %common.ret.op

L299:                                             ; preds = %L206, %L59, %L33, %L28, %L25, %L20, %L10
  %23 = call nonnull ptr @"j__copy_active!_1227"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L305:                                             ; preds = %L202, %L182, %L165, %L33.L40_crit_edge
  %24 = call nonnull ptr @"j_copyto!_1228"(ptr nonnull %"dest::BlockIterate", ptr nonnull %"src::BlockIterate")
  br label %common.ret

L307:                                             ; preds = %top
  %25 = call [1 x ptr] @j_DimensionMismatch_1230(ptr nonnull @"jl_global#1231.jit")
  %gc_slot_addr_0 = getelementptr inbounds nuw i8, ptr %gcframe5, i64 16
  %26 = extractvalue [1 x ptr] %25, 0
  store ptr %26, ptr %gc_slot_addr_0, align 8
  %ptls_field = getelementptr inbounds nuw i8, ptr %tls_pgcstack, i64 16
  %ptls_load = load ptr, ptr %ptls_field, align 8
  %"box::DimensionMismatch" = call noalias nonnull align 8 dereferenceable(16) ptr @ijl_gc_small_alloc(ptr %ptls_load, i32 360, i32 16, i64 140702277349440) #11
  %"box::DimensionMismatch.tag_addr" = getelementptr inbounds i8, ptr %"box::DimensionMismatch", i64 -8
  store atomic i64 140702277349440, ptr %"box::DimensionMismatch.tag_addr" unordered, align 8
  store ptr %26, ptr %"box::DimensionMismatch", align 8
  store ptr null, ptr %gc_slot_addr_0, align 8
  call void @ijl_throw(ptr nonnull %"box::DimensionMismatch")
  unreachable

guard_pass:                                       ; preds = %L20
  %"dest::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"dest::BlockIterate.layout_cache", i64 -8
  %"dest::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"dest::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %27 = and i64 %"dest::BlockIterate.layout_cache.tag", -16
  %"src::BlockIterate.layout_cache.tag_addr" = getelementptr inbounds i8, ptr %"src::BlockIterate.layout_cache", i64 -8
  %"src::BlockIterate.layout_cache.tag" = load atomic volatile i64, ptr %"src::BlockIterate.layout_cache.tag_addr" unordered, align 8
  %28 = and i64 %"src::BlockIterate.layout_cache.tag", -16
  %29 = icmp eq i64 %27, %28
  br i1 %29, label %L25, label %L28

guard_exit161:                                    ; preds = %L206
  %30 = mul i64 %value_phi21, 24
  %memoryref_byteoffset = add i64 %30, -24
  %memoryref_data44 = getelementptr inbounds i8, ptr %memoryref_data, i64 %memoryref_byteoffset
  %31 = add i64 %value_phi21, 1
  %memoryref_data66 = getelementptr inbounds i8, ptr %memoryref_data91, i64 %memoryref_byteoffset
  br label %L148
}
