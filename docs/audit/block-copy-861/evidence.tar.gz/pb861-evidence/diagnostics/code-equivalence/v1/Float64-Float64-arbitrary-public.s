	.file	"copyto!"
	.section	.ltext,"axl",@progbits
	.globl	"julia_copyto!_1432"            # -- Begin function julia_copyto!_1432
	.p2align	4
	.type	"julia_copyto!_1432",@function
"julia_copyto!_1432":                   # @"julia_copyto!_1432"
; Function Signature: copyto!(ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}}, ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: copyto!:dest <- [$rdi+0]
	#DEBUG_VALUE: copyto!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r13
	push	r12
	push	rbx
	sub	rsp, 72
	vxorps	xmm0, xmm0, xmm0
	vmovups	ymmword ptr [rbp - 96], ymm0
	mov	qword ptr [rbp - 56], 0
	mov	qword ptr [rbp - 64], 0
	#APP
	mov	rax, qword ptr fs:[0]
	#NO_APP
	mov	r14, qword ptr [rax - 8]
	mov	qword ptr [rbp - 96], 16
	mov	rax, qword ptr [r14]
	mov	qword ptr [rbp - 88], rax
	lea	rax, [rbp - 96]
	mov	qword ptr [r14], rax
	cmp	rdi, rsi
	je	.LBB0_29
# %bb.1:                                # %L4
	mov	rax, qword ptr [rdi]
	mov	rax, qword ptr [rax + 16]
	mov	rcx, qword ptr [rsi]
	cmp	rax, qword ptr [rcx + 16]
	jne	.LBB0_24
# %bb.2:                                # %L12
	mov	rbx, qword ptr [rsi + 8]
	cmp	qword ptr [rdi + 8], rbx
	je	.LBB0_5
# %bb.3:                                # %L18
	mov	rax, qword ptr [rdi + 24]
	movabs	rcx, offset jl_nothing
	cmp	rax, qword ptr [rcx]
	je	.LBB0_9
# %bb.4:                                # %L22
	mov	rcx, qword ptr [rsi + 24]
	cmp	rax, rcx
	je	.LBB0_5
# %bb.6:                                # %guard_pass
	mov	rdx, qword ptr [rax - 8]
	and	rdx, -16
	mov	r8, qword ptr [rcx - 8]
	and	r8, -16
	cmp	rdx, r8
	jne	.LBB0_9
# %bb.7:                                # %L27
	movabs	r8, offset jl_egal__unboxed
	mov	rbx, rdi
	mov	rdi, rax
	mov	r15, rsi
	mov	rsi, rcx
	vzeroupper
	call	r8
	mov	rsi, r15
	mov	rdi, rbx
	test	al, 1
	jne	.LBB0_5
# %bb.8:                                # %L27.L30_crit_edge
	mov	rax, qword ptr [rdi + 24]
	mov	rbx, qword ptr [rsi + 8]
.LBB0_9:                                # %L30
	cmp	rax, rbx
	je	.LBB0_5
# %bb.10:                               # %L35
	mov	r13, qword ptr [rdi + 8]
	cmp	qword ptr [rsi + 24], r13
	je	.LBB0_5
# %bb.11:                               # %L35.L42_crit_edge
	mov	rax, qword ptr [rbx + 16]
	cmp	qword ptr [r13 + 16], rax
	jne	.LBB0_28
# %bb.12:                               # %L61
	test	rax, rax
	je	.LBB0_5
# %bb.13:                               # %L82
	mov	rax, qword ptr [r13]
	mov	rcx, qword ptr [rax]
	test	rcx, rcx
	je	.LBB0_25
# %bb.14:                               # %L117
	mov	rax, qword ptr [rbx]
	mov	r8, qword ptr [rax]
	test	r8, r8
	je	.LBB0_27
# %bb.15:                               # %L136
	mov	rdx, qword ptr [rcx + 16]
	cmp	rdx, qword ptr [r8 + 16]
	jne	.LBB0_28
# %bb.16:                               # %L179.preheader
	mov	r12d, 1
	mov	qword ptr [rbp - 104], rdi      # 8-byte Spill
.LBB0_18:                               # %L179
                                        # =>This Inner Loop Header: Depth=1
	mov	rdi, qword ptr [rcx]
	mov	r9, qword ptr [rcx + 8]
	mov	rcx, qword ptr [r8]
	mov	r8, qword ptr [r8 + 8]
	shl	rdx, 3
	mov	qword ptr [rbp - 56], rbx
	mov	qword ptr [rbp - 64], r13
	mov	qword ptr [rbp - 72], r8
	mov	qword ptr [rbp - 80], r9
	mov	r15, rsi
	mov	rsi, rcx
	movabs	rax, offset .Ljlplt_memcmp_1437_got.jit
	vzeroupper
	call	rax
	mov	rsi, r15
	mov	rdi, qword ptr [rbp - 104]      # 8-byte Reload
	test	eax, eax
	jne	.LBB0_28
# %bb.19:                               # %L183
                                        #   in Loop: Header=BB0_18 Depth=1
	cmp	r12, qword ptr [r13 + 16]
	jae	.LBB0_5
# %bb.20:                               # %L204
                                        #   in Loop: Header=BB0_18 Depth=1
	mov	rax, qword ptr [r13]
	mov	rcx, qword ptr [rax + 8*r12]
	test	rcx, rcx
	je	.LBB0_26
# %bb.21:                               # %L217
                                        #   in Loop: Header=BB0_18 Depth=1
	cmp	r12, qword ptr [rbx + 16]
	jae	.LBB0_5
# %bb.22:                               # %L238
                                        #   in Loop: Header=BB0_18 Depth=1
	mov	rax, qword ptr [rbx]
	mov	r8, qword ptr [rax + 8*r12]
	test	r8, r8
	je	.LBB0_23
# %bb.17:                               # %L150
                                        #   in Loop: Header=BB0_18 Depth=1
	mov	rdx, qword ptr [rcx + 16]
	inc	r12
	cmp	rdx, qword ptr [r8 + 16]
	je	.LBB0_18
.LBB0_28:                               # %L282
	movabs	rax, offset "j_copyto!_1435"
	vzeroupper
	call	rax
	mov	rdi, rax
	jmp	.LBB0_29
.LBB0_5:                                # %L276
	movabs	rax, offset "j__copy_active!_1434"
	vzeroupper
	call	rax
	mov	rdi, rax
.LBB0_29:                               # %common.ret
	mov	rax, qword ptr [rbp - 88]
	mov	qword ptr [r14], rax
	mov	rax, rdi
	add	rsp, 72
	pop	rbx
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	pop	rbp
	vzeroupper
	ret
.LBB0_24:                               # %L284
	movabs	rdi, offset ".Ljl_global#1440.jit"
	movabs	rax, offset j_DimensionMismatch_1439
	vzeroupper
	call	rax
	mov	rbx, rax
	mov	qword ptr [rbp - 80], rax
	mov	rdi, qword ptr [r14 + 16]
	movabs	rax, offset ijl_gc_small_alloc
	movabs	r14, 140702277349440
	mov	esi, 360
	mov	edx, 16
	mov	rcx, r14
	call	rax
	mov	qword ptr [rax - 8], r14
	mov	qword ptr [rax], rbx
	mov	qword ptr [rbp - 80], 0
	movabs	rcx, offset ijl_throw
	mov	rdi, rax
	call	rcx
.LBB0_26:                               # %fail46
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	vxorps	xmm0, xmm0, xmm0
	vmovups	ymmword ptr [rbp - 80], ymm0
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.LBB0_23:                               # %fail75
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	vxorps	xmm0, xmm0, xmm0
	vmovups	ymmword ptr [rbp - 80], ymm0
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.LBB0_25:                               # %fail
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.LBB0_27:                               # %fail98
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
.Lfunc_end0:
	.size	"julia_copyto!_1432", .Lfunc_end0-"julia_copyto!_1432"
                                        # -- End function
.set ".L+Main.Base.DimensionMismatch#1441.jit", 140702277349440
	.size	".L+Main.Base.DimensionMismatch#1441.jit", 8
.set ".Ljl_global#1440.jit", 140702406589648
	.size	".Ljl_global#1440.jit", 8
.set .Ljlplt_memcmp_1437_got.jit, 140702570284576
	.size	.Ljlplt_memcmp_1437_got.jit, 8
	.section	".note.GNU-stack","",@progbits
