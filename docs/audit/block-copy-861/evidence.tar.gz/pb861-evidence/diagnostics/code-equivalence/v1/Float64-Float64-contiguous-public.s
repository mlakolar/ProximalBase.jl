	.file	"copyto!"
	.section	.ltext,"axl",@progbits
	.globl	"julia_copyto!_1338"            # -- Begin function julia_copyto!_1338
	.p2align	4
	.type	"julia_copyto!_1338",@function
"julia_copyto!_1338":                   # @"julia_copyto!_1338"
; Function Signature: copyto!(ProximalBase.BlockIterate{Float64, Array{Base.UnitRange{Int64}, 1}}, ProximalBase.BlockIterate{Float64, Array{Base.UnitRange{Int64}, 1}})
# %bb.0:                                # %top
	#DEBUG_VALUE: copyto!:dest <- [$rdi+0]
	#DEBUG_VALUE: copyto!:src <- [$rsi+0]
	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r12
	push	rbx
	sub	rsp, 32
	vxorps	xmm0, xmm0, xmm0
	vmovaps	xmmword ptr [rbp - 64], xmm0
	mov	qword ptr [rbp - 48], 0
	#APP
	mov	rax, qword ptr fs:[0]
	#NO_APP
	mov	r14, qword ptr [rax - 8]
	mov	qword ptr [rbp - 64], 4
	mov	rax, qword ptr [r14]
	mov	qword ptr [rbp - 56], rax
	lea	rax, [rbp - 64]
	mov	qword ptr [r14], rax
	cmp	rdi, rsi
	je	.LBB0_15
# %bb.1:                                # %L4
	mov	rax, qword ptr [rdi]
	mov	rax, qword ptr [rax + 16]
	mov	rcx, qword ptr [rsi]
	cmp	rax, qword ptr [rcx + 16]
	jne	.LBB0_19
# %bb.2:                                # %L12
	mov	r8, qword ptr [rsi + 8]
	cmp	qword ptr [rdi + 8], r8
	je	.LBB0_18
# %bb.3:                                # %L18
	mov	rax, qword ptr [rdi + 24]
	movabs	rcx, offset jl_nothing
	cmp	rax, qword ptr [rcx]
	je	.LBB0_8
# %bb.4:                                # %L22
	mov	rcx, qword ptr [rsi + 24]
	cmp	rax, rcx
	je	.LBB0_18
# %bb.5:                                # %guard_pass
	mov	rdx, qword ptr [rax - 8]
	and	rdx, -16
	mov	r9, qword ptr [rcx - 8]
	and	r9, -16
	cmp	rdx, r9
	jne	.LBB0_8
# %bb.6:                                # %L27
	movabs	r8, offset jl_egal__unboxed
	mov	rbx, rdi
	mov	rdi, rax
	mov	r15, rsi
	mov	rsi, rcx
	call	r8
	mov	rsi, r15
	mov	rdi, rbx
	test	al, 1
	jne	.LBB0_18
# %bb.7:                                # %L27.L30_crit_edge
	mov	rax, qword ptr [rdi + 24]
	mov	r8, qword ptr [rsi + 8]
.LBB0_8:                                # %L30
	cmp	rax, r8
	je	.LBB0_18
# %bb.9:                                # %L35
	mov	rcx, qword ptr [rdi + 8]
	cmp	qword ptr [rsi + 24], rcx
	je	.LBB0_18
# %bb.10:                               # %L35.L42_crit_edge
	mov	rax, qword ptr [r8 + 16]
	cmp	qword ptr [rcx + 16], rax
	jne	.LBB0_14
# %bb.11:                               # %L61
	test	rax, rax
	je	.LBB0_18
# %bb.12:                               # %L96
	mov	rcx, qword ptr [rcx]
	mov	r9, qword ptr [rcx]
	mov	r10, qword ptr [rcx + 8]
	mov	rdx, qword ptr [r8]
	mov	r8, qword ptr [rdx]
	mov	r11, qword ptr [rdx + 8]
	cmp	r10, r9
	setl	bl
	cmp	r11, r8
	setl	r15b
	xor	r9, r8
	xor	r10, r11
	or	r10, r9
	sete	r8b
	test	bl, r15b
	jne	.LBB0_16
# %bb.13:                               # %L96
	test	r8b, r8b
	je	.LBB0_14
.LBB0_16:                               # %L172.lr.ph
	mov	r9d, 24
	.p2align	4
.LBB0_17:                               # %L172
                                        # =>This Inner Loop Header: Depth=1
	dec	rax
	je	.LBB0_18
# %bb.20:                               # %guard_exit164
                                        #   in Loop: Header=BB0_17 Depth=1
	lea	r8, [r9 + 16]
	mov	r10, qword ptr [rcx + r9 - 8]
	mov	r11, qword ptr [rcx + r9]
	mov	rbx, qword ptr [rdx + r9 - 8]
	mov	r9, qword ptr [rdx + r9]
	cmp	r11, r10
	setl	r15b
	cmp	r9, rbx
	setl	r12b
	xor	r10, rbx
	xor	r11, r9
	or	r11, r10
	sete	r10b
	mov	r9, r8
	test	r15b, r12b
	jne	.LBB0_17
# %bb.21:                               # %guard_exit164
                                        #   in Loop: Header=BB0_17 Depth=1
	mov	r9, r8
	test	r10b, r10b
	jne	.LBB0_17
.LBB0_14:                               # %L271
	movabs	rax, offset "j_copyto!_1341"
	call	rax
	mov	rdi, rax
	jmp	.LBB0_15
.LBB0_18:                               # %L265
	movabs	rax, offset "j__copy_active!_1340"
	call	rax
	mov	rdi, rax
.LBB0_15:                               # %common.ret
	mov	rax, qword ptr [rbp - 56]
	mov	qword ptr [r14], rax
	mov	rax, rdi
	add	rsp, 32
	pop	rbx
	pop	r12
	pop	r14
	pop	r15
	pop	rbp
	ret
.LBB0_19:                               # %L273
	movabs	rdi, offset ".Ljl_global#1344.jit"
	movabs	rax, offset j_DimensionMismatch_1343
	call	rax
	mov	rbx, rax
	mov	qword ptr [rbp - 48], rax
	mov	rdi, qword ptr [r14 + 16]
	movabs	rax, offset ijl_gc_small_alloc
	movabs	r14, 140702277349440
	mov	esi, 360
	mov	edx, 16
	mov	rcx, r14
	call	rax
	mov	qword ptr [rax - 8], r14
	mov	qword ptr [rax], rbx
	mov	qword ptr [rbp - 48], 0
	movabs	rcx, offset ijl_throw
	mov	rdi, rax
	call	rcx
.Lfunc_end0:
	.size	"julia_copyto!_1338", .Lfunc_end0-"julia_copyto!_1338"
                                        # -- End function
.set ".L+Main.Base.DimensionMismatch#1345.jit", 140702277349440
	.size	".L+Main.Base.DimensionMismatch#1345.jit", 8
.set ".Ljl_global#1344.jit", 140702406589648
	.size	".Ljl_global#1344.jit", 8
	.section	".note.GNU-stack","",@progbits
