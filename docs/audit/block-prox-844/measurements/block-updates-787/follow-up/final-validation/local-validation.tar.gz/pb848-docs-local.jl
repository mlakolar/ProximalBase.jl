let source = read(joinpath(pwd(), "docs", "make.jl"), String)
    source = first(split(source, "\ndeploydocs("; limit=2))
    source = replace(source, "makedocs(\n" => "makedocs(\n    root = @__DIR__,\n"; count=1)
    include_string(Main, source, joinpath(pwd(), "docs", "make.jl"))
end
println("PB_LOCAL_DOC_BUILD_OK deployment=false")
