using ProximalBase,InteractiveUtils
x=BlockIterate(ones(Float32,64),[collect(1:32),collect(33:64)]);u=ones(Float32,32)
for v in (blockview(x,1),ProximalBase._block_storage(x,1))
 println("LOOP ",typeof(v));println("METHOD ",which(Base.copyto_unaliased!,Tuple{typeof(IndexStyle(v)),typeof(v),typeof(IndexStyle(u)),typeof(u)}))
 show(stdout,MIME"text/plain"(),code_typed(Base.copyto_unaliased!,Tuple{typeof(IndexStyle(v)),typeof(v),typeof(IndexStyle(u)),typeof(u)};optimize=true));println()
 code_llvm(stdout,Base.copyto_unaliased!,Tuple{typeof(IndexStyle(v)),typeof(v),typeof(IndexStyle(u)),typeof(u)};debuginfo=:none)
end
