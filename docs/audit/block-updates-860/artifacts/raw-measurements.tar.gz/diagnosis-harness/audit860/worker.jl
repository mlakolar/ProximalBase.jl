using BenchmarkTools, LinearAlgebra, Statistics, TOML, SHA, InteractiveUtils
BLAS.set_num_threads(1)
source, output, seedstr = ARGS[1:3]
include(joinpath(source,"src/ProximalBase.jl")); const PB = Main.ProximalBase
include("kernels.jl")
seed = parse(Int,seedstr)
function measure(op,prep)
    for _ in 1:3; prep(); op(); end
    run(@benchmarkable $op() setup=($prep()) evals=1 samples=3 seconds=.001)
    t = run(@benchmarkable $op() setup=($prep()) evals=1 samples=80 seconds=.1)
    Dict("median_ns"=>median(t).time,"bytes"=>t.memory,"allocs"=>t.allocs,
         "times_ns"=>t.times,"gc_ns"=>t.gctimes)
end
function main()
    results = Dict{String,Any}()
    specs = [(T,n,b,l) for T in (Float32,Float64), n in (8192,65536),
             b in (1,8,64), l in ("contiguous","strided","arbitrary","reversed")]
    isodd(seed) || reverse!(specs)
    for (T,n,b,l) in specs
        f = make_fixture(T,n,b,l,seed)
        f.prep(); f.bcd(); f.check()
        key = "$T/n$n/b$b/$l"
        results[key*"/residual_bcd"] = measure(f.bcd,f.prep)
        f.prep(); f.bulk(); f.check()
        results[key*"/residual_bulk"] = measure(f.bulk,f.prep)
        for route in (Val(:owner),Val(:raw),Val(:once))
            ORIGINAL && route == Val(:once) && continue
            op = () -> diagnostic_sweep!(f.x,f.ks,route)
            f.prep();op()
            expected=copy(f.base)
            for _ in 1:4,k in f.ks,i in f.groups[k]
                expected[i]=max(T(7/8)*expected[i]+T(1/4)-T(1/16),zero(T))
            end
            reference_equal(f.x.storage,expected)
            results[key*"/sweep_"*string(typeof(route).parameters[1])] = measure(op,f.prep)
        end
    end
    meta = Dict("julia"=>string(VERSION),"cpu"=>Sys.CPU_NAME,"threads"=>Threads.nthreads(),
        "blas"=>string(BLAS.get_config()),"blas_threads"=>BLAS.get_num_threads(),
        "bounds"=>Base.JLOptions().check_bounds,"opt"=>Base.JLOptions().opt_level,
        "seed"=>seed,"source"=>source,"binary_sha256"=>bytes2hex(sha256(read(joinpath(Sys.BINDIR,"julia")))),
        "source_hashes"=>Dict(p=>bytes2hex(sha256(read(joinpath(source,"src",p)))) for p in readdir(joinpath(source,"src")) if endswith(p,".jl")))
    open(output,"w") do io; TOML.print(io,Dict("meta"=>meta,"results"=>results)); end
end
main()
