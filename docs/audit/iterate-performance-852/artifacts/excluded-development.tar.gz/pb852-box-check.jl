using BenchmarkTools,LinearAlgebra,Random,SparseArrays,InteractiveUtils
include("/tmp/pb852-frozen/post850/src/ProximalBase.jl");const PB=ProximalBase
include("/tmp/pb852-audit/benchmark/audit852/adapters.jl")
include("/tmp/pb852-audit/benchmark/audit852/cases.jl")
for (fam,ops,n) in [("sparse",["construct_empty","construct_populated","activate_batch","write_active","repeat_update","active_sweep","read_random","read_sequential","read_scalar","write_scalar","dense_import","copy","copyto","clear","zero_active","dropzeros","dot","matvec","cd_fixed","cd_expand","prune_rebuild"],10000),("symmetric",["construct_empty","construct_populated","activate_batch","write_active","repeat_update","active_sweep","read_diagonal","read_offdiagonal","copy","copyto","clear","zero_active","dropzeros","bilinear","matmat","symmetric_updates"],144),("block",["construct_empty","construct_populated","activate_batch","write_active","block_read","block_sweep","copy","copyto","clear","dropzeros","dot","matvec","block_cd"],8192)]
 cases,src=fam=="block" ? block_cases(Float64,n,100,8,"contiguous",ops,852101) : scalar_cases(fam,Float64,n,100,ops,852101)
 for p in cases
   @assert !(Core.Box in fieldtypes(typeof(p.op))) (fam,p.id,fieldtypes(typeof(p.op)))
   p.setup();p.op();p.setup();t=@benchmark $(p.op)() setup=($(p.setup)()) evals=1 samples=3 seconds=.001
   println(fam,'/',p.id," bytes=",minimum(t).memory," allocs=",minimum(t).allocs)
 end
end
