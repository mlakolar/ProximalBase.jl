; Function Signature: copyto_unaliased!(Base.IndexCartesian, Base.SubArray{Float64, 1, ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}}, Tuple{Array{Int64, 1}}, false}, Base.IndexLinear, Array{Float64, 1})
define void @"julia_copyto_unaliased!_3741"(ptr noalias nocapture noundef nonnull sret({ ptr, [1 x ptr], i64, i64 }) align 8 dereferenceable(32) %sret_return, ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %return_roots, ptr nocapture noundef nonnull readonly align 8 dereferenceable(32) %"dest::SubArray", ptr nocapture noundef nonnull readonly align 8 dereferenceable(16) %.roots.dest, ptr noundef nonnull align 8 dereferenceable(24) %"src::Array") local_unnamed_addr #0 {
top:
  %gcframe1 = alloca [3 x ptr], align 16
  call void @llvm.memset.p0.i64(ptr align 16 %gcframe1, i8 0, i64 24, i1 true)
  %"new::LinearIndices" = alloca [1 x [1 x [1 x i64]]], align 8
  %"new::Tuple101" = alloca [1 x i64], align 8
  %"new::Tuple246" = alloca [1 x i64], align 8
  %thread_ptr = call ptr asm "movq %fs:0, $0", "=r"() #14
  %tls_ppgcstack = getelementptr inbounds i8, ptr %thread_ptr, i64 -8
  %tls_pgcstack = load ptr, ptr %tls_ppgcstack, align 8
  store i64 4, ptr %gcframe1, align 8
  %frame.prev = getelementptr inbounds nuw i8, ptr %gcframe1, i64 8
  %task.gcstack = load ptr, ptr %tls_pgcstack, align 8
  store ptr %task.gcstack, ptr %frame.prev, align 8
  store ptr %gcframe1, ptr %tls_pgcstack, align 8
  %"src::Array.size_ptr" = getelementptr inbounds nuw i8, ptr %"src::Array", i64 16
  %"src::Array.size_ptr.copyload" = load i64, ptr %"src::Array.size_ptr", align 8
  %.not = icmp eq i64 %"src::Array.size_ptr.copyload", 0
  br i1 %.not, label %L5, label %L6

common.ret:                                       ; preds = %L496, %L5
  %.sink = phi ptr [ %5, %L496 ], [ %3, %L5 ]
  %0 = getelementptr inbounds nuw i8, ptr %return_roots, i64 8
  store ptr %.sink, ptr %0, align 8
  %frame.prev319 = load ptr, ptr %frame.prev, align 8
  store ptr %frame.prev319, ptr %tls_pgcstack, align 8
  ret void

L5:                                               ; preds = %top
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %sret_return, ptr noundef nonnull align 8 dereferenceable(32) %"dest::SubArray", i64 32, i1 false)
  %1 = load ptr, ptr %.roots.dest, align 8
  store ptr %1, ptr %return_roots, align 8
  %2 = getelementptr inbounds nuw i8, ptr %.roots.dest, i64 8
  %3 = load ptr, ptr %2, align 8
  br label %common.ret

L6:                                               ; preds = %top
  %4 = getelementptr inbounds nuw i8, ptr %.roots.dest, i64 8
  %5 = load ptr, ptr %4, align 8
  %.size_ptr = getelementptr inbounds nuw i8, ptr %5, i64 16
  %.size_ptr.copyload = load i64, ptr %.size_ptr, align 8
  store i64 %"src::Array.size_ptr.copyload", ptr %"new::LinearIndices", align 8
  %6 = add i64 %"src::Array.size_ptr.copyload", -1
  %.not277 = icmp ult i64 %6, %.size_ptr.copyload
  br i1 %.not277, label %L26, label %L497

L26:                                              ; preds = %L6
  %.not278 = icmp eq i64 %.size_ptr.copyload, %"src::Array.size_ptr.copyload"
  br i1 %.not278, label %L38, label %L241

L38:                                              ; preds = %L26
  %7 = icmp slt i64 %"src::Array.size_ptr.copyload", 1
  %.pre301 = load ptr, ptr %.roots.dest, align 8
  br i1 %7, label %L496, label %L47.preheader

L47.preheader:                                    ; preds = %L38
  %memoryref_data = load ptr, ptr %"src::Array", align 8
  %memoryref_data23 = load ptr, ptr %5, align 8
  %.group_of_ptr = getelementptr inbounds nuw i8, ptr %.pre301, i64 16
  %.position_ptr = getelementptr inbounds nuw i8, ptr %.pre301, i64 40
  %.nactive_ptr = getelementptr inbounds nuw i8, ptr %.pre301, i64 48
  %.active_ptr = getelementptr inbounds nuw i8, ptr %.pre301, i64 32
  %.storage.pre = load atomic ptr, ptr %.pre301 unordered, align 8
  %memoryref_data33.pre = load ptr, ptr %.storage.pre, align 8
  br label %L47

L47:                                              ; preds = %L229, %L47.preheader
  %value_phi11 = phi i64 [ %15, %L229 ], [ 1, %L47.preheader ]
  %memoryref_offset = shl i64 %value_phi11, 3
  %memoryref_byteoffset = add i64 %memoryref_offset, -8
  %memoryref_data16 = getelementptr inbounds i8, ptr %memoryref_data, i64 %memoryref_byteoffset
  %8 = load double, ptr %memoryref_data16, align 8
  %memoryref_data31 = getelementptr inbounds i8, ptr %memoryref_data23, i64 %memoryref_byteoffset
  %9 = load i64, ptr %memoryref_data31, align 8
  %memoryref_offset35 = shl i64 %9, 3
  %memoryref_byteoffset36 = add i64 %memoryref_offset35, -8
  %memoryref_data41 = getelementptr inbounds i8, ptr %memoryref_data33.pre, i64 %memoryref_byteoffset36
  store double %8, ptr %memoryref_data41, align 8
  %10 = fcmp une double %8, 0.000000e+00
  br i1 %10, label %L129, label %L229

L129:                                             ; preds = %L47
  %.group_of = load atomic ptr, ptr %.group_of_ptr unordered, align 8
  %memoryref_data47 = load ptr, ptr %.group_of, align 8
  %memoryref_data55 = getelementptr inbounds i8, ptr %memoryref_data47, i64 %memoryref_byteoffset36
  %11 = load i64, ptr %memoryref_data55, align 8
  %.position = load atomic ptr, ptr %.position_ptr unordered, align 8
  %12 = add i64 %11, -1
  %.position.size_ptr = getelementptr inbounds nuw i8, ptr %.position, i64 16
  %.position.size_ptr.copyload = load i64, ptr %.position.size_ptr, align 8
  %.not279 = icmp ult i64 %12, %.position.size_ptr.copyload
  br i1 %.not279, label %L160, label %L157

L157:                                             ; preds = %L129
  store i64 %11, ptr %"new::Tuple101", align 8
  %gc_slot_addr_0 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 16
  store ptr %.position, ptr %gc_slot_addr_0, align 8
  call void @j_throw_boundserror_3743(ptr nonnull %.position, ptr nocapture nonnull readonly %"new::Tuple101") #7
  unreachable

L160:                                             ; preds = %L129
  %memoryref_data60 = load ptr, ptr %.position, align 8
  %memoryref_byteoffset63 = shl i64 %12, 3
  %memoryref_data68 = getelementptr inbounds i8, ptr %memoryref_data60, i64 %memoryref_byteoffset63
  %13 = load i64, ptr %memoryref_data68, align 8
  %.not280 = icmp eq i64 %13, 0
  br i1 %.not280, label %L181, label %L229

L181:                                             ; preds = %L160
  %.nactive = load i64, ptr %.nactive_ptr, align 8
  %14 = add i64 %.nactive, 1
  store i64 %14, ptr %.nactive_ptr, align 8
  %.active = load atomic ptr, ptr %.active_ptr unordered, align 8
  %memoryref_data73 = load ptr, ptr %.active, align 8
  %memoryref_byteoffset76 = shl i64 %.nactive, 3
  %memoryref_data81 = getelementptr inbounds i8, ptr %memoryref_data73, i64 %memoryref_byteoffset76
  store i64 %11, ptr %memoryref_data81, align 8
  store i64 %14, ptr %memoryref_data68, align 8
  br label %L229

L229:                                             ; preds = %L181, %L160, %L47
  %.not281 = icmp eq i64 %value_phi11, %"src::Array.size_ptr.copyload"
  %15 = add nuw i64 %value_phi11, 1
  br i1 %.not281, label %L496, label %L47

L241:                                             ; preds = %L26
  %16 = icmp slt i64 %.size_ptr.copyload, 1
  %17 = icmp slt i64 %"src::Array.size_ptr.copyload", 1
  %or.cond = or i1 %16, %17
  %.pre = load ptr, ptr %.roots.dest, align 8
  br i1 %or.cond, label %L496, label %L272.preheader

L272.preheader:                                   ; preds = %L241
  %memoryref_data128 = load ptr, ptr %"src::Array", align 8
  %invariant.gep = getelementptr i8, ptr %memoryref_data128, i64 -8
  %memoryref_data145 = load ptr, ptr %5, align 8
  %invariant.gep291 = getelementptr i8, ptr %memoryref_data145, i64 -8
  %.group_of_ptr182 = getelementptr inbounds nuw i8, ptr %.pre, i64 16
  %.position_ptr194 = getelementptr inbounds nuw i8, ptr %.pre, i64 40
  %.nactive_ptr209 = getelementptr inbounds nuw i8, ptr %.pre, i64 48
  %.active_ptr212 = getelementptr inbounds nuw i8, ptr %.pre, i64 32
  %18 = add nsw i64 %.size_ptr.copyload, -1
  %umin = call i64 @llvm.umin.i64(i64 %6, i64 %18)
  %.storage154.pre = load atomic ptr, ptr %.pre unordered, align 8
  %memoryref_data156.pre = load ptr, ptr %.storage154.pre, align 8
  %19 = add nuw nsw i64 %umin, 1
  br label %L272

L272:                                             ; preds = %L456, %L272.preheader
  %value_phi120 = phi i64 [ 1, %L272.preheader ], [ %27, %L456 ]
  %memoryref_offset130 = shl i64 %value_phi120, 3
  %gep = getelementptr i8, ptr %invariant.gep, i64 %memoryref_offset130
  %20 = load double, ptr %gep, align 8
  %gep292 = getelementptr i8, ptr %invariant.gep291, i64 %memoryref_offset130
  %21 = load i64, ptr %gep292, align 8
  %memoryref_offset158 = shl i64 %21, 3
  %memoryref_byteoffset159 = add i64 %memoryref_offset158, -8
  %memoryref_data164 = getelementptr inbounds i8, ptr %memoryref_data156.pre, i64 %memoryref_byteoffset159
  store double %20, ptr %memoryref_data164, align 8
  %22 = fcmp une double %20, 0.000000e+00
  br i1 %22, label %L356, label %L456

L356:                                             ; preds = %L272
  %.group_of183 = load atomic ptr, ptr %.group_of_ptr182 unordered, align 8
  %memoryref_data185 = load ptr, ptr %.group_of183, align 8
  %memoryref_data193 = getelementptr inbounds i8, ptr %memoryref_data185, i64 %memoryref_byteoffset159
  %23 = load i64, ptr %memoryref_data193, align 8
  %.position195 = load atomic ptr, ptr %.position_ptr194 unordered, align 8
  %24 = add i64 %23, -1
  %.position195.size_ptr = getelementptr inbounds nuw i8, ptr %.position195, i64 16
  %.position195.size_ptr.copyload = load i64, ptr %.position195.size_ptr, align 8
  %.not282 = icmp ult i64 %24, %.position195.size_ptr.copyload
  br i1 %.not282, label %L387, label %L384

L384:                                             ; preds = %L356
  store i64 %23, ptr %"new::Tuple246", align 8
  %gc_slot_addr_0309 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 16
  store ptr %.position195, ptr %gc_slot_addr_0309, align 8
  call void @j_throw_boundserror_3743(ptr nonnull %.position195, ptr nocapture nonnull readonly %"new::Tuple246") #7
  unreachable

L387:                                             ; preds = %L356
  %memoryref_data200 = load ptr, ptr %.position195, align 8
  %memoryref_byteoffset203 = shl i64 %24, 3
  %memoryref_data208 = getelementptr inbounds i8, ptr %memoryref_data200, i64 %memoryref_byteoffset203
  %25 = load i64, ptr %memoryref_data208, align 8
  %.not283 = icmp eq i64 %25, 0
  br i1 %.not283, label %L408, label %L456

L408:                                             ; preds = %L387
  %.nactive210 = load i64, ptr %.nactive_ptr209, align 8
  %26 = add i64 %.nactive210, 1
  store i64 %26, ptr %.nactive_ptr209, align 8
  %.active213 = load atomic ptr, ptr %.active_ptr212 unordered, align 8
  %memoryref_data217 = load ptr, ptr %.active213, align 8
  %memoryref_byteoffset220 = shl i64 %.nactive210, 3
  %memoryref_data225 = getelementptr inbounds i8, ptr %memoryref_data217, i64 %memoryref_byteoffset220
  store i64 %23, ptr %memoryref_data225, align 8
  store i64 %26, ptr %memoryref_data208, align 8
  br label %L456

L456:                                             ; preds = %L408, %L387, %L272
  %27 = add nuw i64 %value_phi120, 1
  %exitcond = icmp eq i64 %value_phi120, %19
  br i1 %exitcond, label %L496, label %L272

L496:                                             ; preds = %L456, %L241, %L229, %L38
  %28 = phi ptr [ %.pre, %L241 ], [ %.pre301, %L38 ], [ %.pre301, %L229 ], [ %.pre, %L456 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %sret_return, ptr noundef nonnull align 8 dereferenceable(32) %"dest::SubArray", i64 32, i1 false)
  store ptr %28, ptr %return_roots, align 8
  br label %common.ret

L497:                                             ; preds = %L6
  %ptls_field = getelementptr inbounds nuw i8, ptr %tls_pgcstack, i64 16
  %ptls_load = load ptr, ptr %ptls_field, align 8
  %"box::SubArray" = call noalias nonnull align 8 dereferenceable(48) ptr @ijl_gc_small_alloc(ptr %ptls_load, i32 456, i32 48, i64 125309751476048) #10
  %"box::SubArray.tag_addr" = getelementptr inbounds i8, ptr %"box::SubArray", i64 -8
  store atomic i64 125309751476048, ptr %"box::SubArray.tag_addr" unordered, align 8
  %29 = load ptr, ptr %.roots.dest, align 8
  store atomic ptr %29, ptr %"box::SubArray" unordered, align 8
  %30 = getelementptr inbounds nuw i8, ptr %"box::SubArray", i64 8
  store atomic ptr %5, ptr %30 unordered, align 8
  %31 = getelementptr inbounds nuw i8, ptr %"dest::SubArray", i64 16
  %32 = getelementptr inbounds nuw i8, ptr %"box::SubArray", i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %32, ptr noundef nonnull align 8 dereferenceable(16) %31, i64 16, i1 false)
  %gc_slot_addr_0310 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 16
  store ptr %"box::SubArray", ptr %gc_slot_addr_0310, align 8
  %33 = call nonnull ptr @j_BoundsError_3746(ptr nonnull %"box::SubArray", ptr nocapture nonnull readonly %"new::LinearIndices")
  store ptr null, ptr %gc_slot_addr_0310, align 8
  call void @ijl_throw(ptr nonnull %33)
  unreachable
}
