	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r12
	push	rbx
	sub	rsp, 80
	vxorpd	xmm0, xmm0, xmm0
	vmovapd	xmmword ptr [rbp - 80], xmm0
	mov	qword ptr [rbp - 64], 0
	mov	qword ptr [rbp - 80], 4
	mov	r8, qword ptr [r13]
	mov	qword ptr [rbp - 72], r8
	lea	r8, [rbp - 80]
	mov	qword ptr [r13], r8
	mov	qword ptr [rbp - 48], rsi
	mov	r8, qword ptr [r13 + 16]
	mov	r8, qword ptr [r8 + 16]
	mov	r8, qword ptr [r8]
	mov	r9, qword ptr [rcx + 16]
	test	r9, r9
	je	L268
	mov	r15, qword ptr [rdx + 8]
	mov	r8, qword ptr [r15 + 16]
	mov	qword ptr [rbp - 104], r9
	lea	r11, [r9 - 1]
	cmp	r11, r8
	jae	L576
	cmp	r8, r9
	jne	L295
	mov	rdx, qword ptr [rdx]
	test	r9, r9
	jle	L479
	mov	rsi, qword ptr [rcx]
	mov	qword ptr [rbp - 40], r15
	mov	r10, qword ptr [r15]
	mov	rcx, qword ptr [rdx]
	mov	r11, qword ptr [rcx]
	xor	ebx, ebx
	vxorpd	xmm0, xmm0, xmm0
	jmp	L172
	nop	word ptr [rax + rax]
L160:
	inc	rbx
	cmp	r9, rbx
	je	L469
L172:
	vmovsd	xmm1, qword ptr [rsi + 8*rbx]
	mov	rcx, qword ptr [r10 + 8*rbx]
	vmovsd	qword ptr [r11 + 8*rcx - 8], xmm1
	vucomisd	xmm1, xmm0
	jne	L196
	jnp	L160
L196:
	mov	r15, qword ptr [rdx + 16]
	mov	r15, qword ptr [r15]
	mov	r15, qword ptr [r15 + 8*rcx - 8]
	mov	rcx, qword ptr [rdx + 40]
	lea	r12, [r15 - 1]
	cmp	r12, qword ptr [rcx + 16]
	jae	L522
	mov	rcx, qword ptr [rcx]
	cmp	qword ptr [rcx + 8*r15 - 8], 0
	jne	L160
	mov	r12, qword ptr [rdx + 48]
	lea	r14, [r12 + 1]
	mov	qword ptr [rdx + 48], r14
	mov	r8, qword ptr [rdx + 32]
	mov	r8, qword ptr [r8]
	mov	qword ptr [r8 + 8*r12], r15
	mov	qword ptr [rcx + 8*r15 - 8], r14
	jmp	L160
L268:
	mov	rcx, qword ptr [rbp - 48]
	vmovups	ymm0, ymmword ptr [rcx]
	vmovups	ymmword ptr [rax], ymm0
	mov	rax, qword ptr [rdx]
	mov	r15, qword ptr [rdx + 8]
	mov	qword ptr [rdi], rax
	jmp	L494
L295:
	test	r8, r8
	setle	sil
	test	r9, r9
	setle	r9b
	or	r9b, sil
	mov	rdx, qword ptr [rdx]
	jne	L479
	mov	r9, qword ptr [rcx]
	mov	qword ptr [rbp - 40], r15
	mov	r10, qword ptr [r15]
	dec	r8
	cmp	r11, r8
	cmovb	r8, r11
	mov	rcx, qword ptr [rdx]
	mov	r11, qword ptr [rcx]
	inc	r8
	xor	ebx, ebx
	vxorpd	xmm0, xmm0, xmm0
	jmp	L376
	nop	word ptr cs:[rax + rax]
L368:
	inc	rbx
	cmp	r8, rbx
	je	L475
L376:
	vmovsd	xmm1, qword ptr [r9 + 8*rbx]
	mov	rcx, qword ptr [r10 + 8*rbx]
	vmovsd	qword ptr [r11 + 8*rcx - 8], xmm1
	vucomisd	xmm1, xmm0
	jne	L401
	jnp	L368
L401:
	mov	rsi, qword ptr [rdx + 16]
	mov	rsi, qword ptr [rsi]
	mov	r15, qword ptr [rsi + 8*rcx - 8]
	mov	rcx, qword ptr [rdx + 40]
	lea	rsi, [r15 - 1]
	cmp	rsi, qword ptr [rcx + 16]
	jae	L549
	mov	rcx, qword ptr [rcx]
	cmp	qword ptr [rcx + 8*r15 - 8], 0
	jne	L368
	mov	rsi, qword ptr [rdx + 48]
	lea	r14, [rsi + 1]
	mov	qword ptr [rdx + 48], r14
	mov	r12, qword ptr [rdx + 32]
	mov	r12, qword ptr [r12]
	mov	qword ptr [r12 + 8*rsi], r15
	mov	qword ptr [rcx + 8*r15 - 8], r14
	jmp	L368
L469:
	mov	r15, qword ptr [rbp - 40]
	jmp	L479
L475:
	mov	r15, qword ptr [rbp - 40]
L479:
	mov	rcx, qword ptr [rbp - 48]
	vmovups	ymm0, ymmword ptr [rcx]
	vmovups	ymmword ptr [rax], ymm0
	mov	qword ptr [rdi], rdx
L494:
	mov	qword ptr [rdi + 8], r15
	mov	rax, qword ptr [rbp - 72]
	mov	qword ptr [r13], rax
	add	rsp, 80
	pop	rbx
	pop	r12
	pop	r14
	pop	r15
	pop	rbp
	vzeroupper
	ret
L522:
	mov	qword ptr [rbp - 96], r15
	mov	qword ptr [rbp - 64], rcx
	movabs	rax, offset throw_boundserror
	lea	rsi, [rbp - 96]
	mov	rdi, rcx
	call	rax
L549:
	mov	qword ptr [rbp - 88], r15
	mov	qword ptr [rbp - 64], rcx
	movabs	rax, offset throw_boundserror
	lea	rsi, [rbp - 88]
	mov	rdi, rcx
	call	rax
L576:
	mov	rdi, qword ptr [r13 + 16]
	movabs	rax, offset ijl_gc_small_alloc
	movabs	rbx, 125309751476048
	mov	esi, 456
	mov	r14, rdx
	mov	edx, 48
	mov	rcx, rbx
	call	rax
	mov	qword ptr [rax - 8], rbx
	mov	rcx, qword ptr [r14]
	mov	qword ptr [rax], rcx
	mov	qword ptr [rax + 8], r15
	mov	rcx, qword ptr [rbp - 48]
	vmovups	xmm0, xmmword ptr [rcx + 16]
	vmovups	xmmword ptr [rax + 16], xmm0
	mov	qword ptr [rbp - 64], rax
	movabs	rcx, offset BoundsError
	lea	rsi, [rbp - 104]
	mov	rdi, rax
	call	rcx
	mov	qword ptr [rbp - 64], 0
	movabs	rcx, offset ijl_throw
	mov	rdi, rax
	call	rcx
	nop	word ptr cs:[rax + rax]
