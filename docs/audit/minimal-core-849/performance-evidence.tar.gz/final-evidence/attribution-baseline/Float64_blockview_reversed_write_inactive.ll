; Function Signature: (::Suite.var"#makeprobes##79#makeprobes##80"{Array{Float64, 1}, ProximalBase.BlockIterate{Float64, Array{Array{Int64, 1}, 1}}})()
define void @"julia_#makeprobes##79_3802"(ptr nocapture noundef nonnull readonly align 8 dereferenceable(16) %"#self#::#makeprobes##79#makeprobes##80") local_unnamed_addr #0 {
top:
  %gcframe1 = alloca [8 x ptr], align 16
  call void @llvm.memset.p0.i64(ptr align 16 %gcframe1, i8 0, i64 64, i1 true)
  %0 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 32
  %1 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 16
  %"new::SubArray" = alloca [4 x i64], align 8
  %sret_box = alloca [4 x i64], align 8
  %thread_ptr = call ptr asm "movq %fs:0, $0", "=r"() #13
  %tls_ppgcstack = getelementptr inbounds i8, ptr %thread_ptr, i64 -8
  %tls_pgcstack = load ptr, ptr %tls_ppgcstack, align 8
  store i64 24, ptr %gcframe1, align 8
  %frame.prev = getelementptr inbounds nuw i8, ptr %gcframe1, i64 8
  %task.gcstack = load ptr, ptr %tls_pgcstack, align 8
  store ptr %task.gcstack, ptr %frame.prev, align 8
  store ptr %gcframe1, ptr %tls_pgcstack, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x_ptr" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80", i64 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x_ptr" unordered, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.groups_ptr" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x", i64 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.groups" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.groups_ptr" unordered, align 8
  %memoryref_data = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.groups", align 8
  %2 = load atomic ptr, ptr %memoryref_data unordered, align 8
  %.not = icmp eq ptr %2, null
  br i1 %.not, label %fail, label %pass

L22:                                              ; preds = %pass
  %.size_ptr = getelementptr inbounds nuw i8, ptr %2, i64 16
  %.size_ptr.copyload = load i64, ptr %.size_ptr, align 8
  %3 = icmp eq i64 %.size_ptr.copyload, 0
  br i1 %3, label %L190, label %L27

L27:                                              ; preds = %L22
  %4 = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage", i64 8
  %5 = load ptr, ptr %4, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage2.ref.mem.ptr_ptr" = getelementptr inbounds nuw i8, ptr %5, i64 8
  %bitcast3 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage2.ref.mem.ptr_ptr", align 8
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %7 = load ptr, ptr %6, align 8
  %.ref.mem.ptr_ptr = getelementptr inbounds nuw i8, ptr %7, i64 8
  %bitcast8 = load ptr, ptr %.ref.mem.ptr_ptr, align 8
  %.not160 = icmp eq ptr %bitcast3, %bitcast8
  br i1 %.not160, label %nonemptymem, label %L69

L69:                                              ; preds = %L27
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position_ptr" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x", i64 40
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position_ptr" unordered, align 8
  %8 = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position", i64 8
  %9 = load ptr, ptr %8, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position.ref.mem.ptr_ptr" = getelementptr inbounds nuw i8, ptr %9, i64 8
  %bitcast6 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position.ref.mem.ptr_ptr", align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active_ptr" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x", i64 32
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active_ptr" unordered, align 8
  %10 = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active", i64 8
  %11 = load ptr, ptr %10, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active.ref.mem.ptr_ptr" = getelementptr inbounds nuw i8, ptr %11, i64 8
  %bitcast4 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active.ref.mem.ptr_ptr", align 8
  %.not161 = icmp ne ptr %bitcast4, %bitcast8
  %.not162 = icmp ne ptr %bitcast6, %bitcast8
  %narrow.not = select i1 %.not161, i1 %.not162, i1 false
  br i1 %narrow.not, label %L190, label %nonemptymem

L103:                                             ; preds = %nonemptymem
  %memoryref_data141 = load ptr, ptr %2, align 8
  %12 = shl nuw nsw i64 %.size_ptr.copyload, 3
  %ptls_field = getelementptr inbounds nuw i8, ptr %tls_pgcstack, i64 16
  %ptls_load = load ptr, ptr %ptls_field, align 8
  %gc_slot_addr_5 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 56
  store ptr %2, ptr %gc_slot_addr_5, align 8
  %gc_slot_addr_4 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 48
  store ptr %7, ptr %gc_slot_addr_4, align 8
  %"Memory{Int64}[]" = call noalias nonnull align 16 ptr @jl_alloc_genericmemory_unchecked(ptr %ptls_load, i64 %12, ptr nonnull @"+Core.GenericMemory#3805.jit") #14
  store i64 %.size_ptr.copyload, ptr %"Memory{Int64}[]", align 8
  %memory_data_ptr = getelementptr inbounds nuw i8, ptr %"Memory{Int64}[]", i64 8
  %memoryref_data134 = load ptr, ptr %memory_data_ptr, align 8
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %memoryref_data134, ptr align 1 %memoryref_data141, i64 %12, i1 false)
  %.size_ptr22.copyload.pre = load i64, ptr %.size_ptr, align 8
  store ptr null, ptr %gc_slot_addr_5, align 8
  store ptr %"Memory{Int64}[]", ptr %gc_slot_addr_4, align 8
  %ptls_load202 = load ptr, ptr %ptls_field, align 8
  %"new::Array" = call noalias nonnull align 8 dereferenceable(32) ptr @ijl_gc_small_alloc(ptr %ptls_load202, i32 408, i32 32, i64 125309881287104) #10
  %"new::Array.tag_addr" = getelementptr inbounds i8, ptr %"new::Array", i64 -8
  store atomic i64 125309881287104, ptr %"new::Array.tag_addr" unordered, align 8
  %13 = getelementptr inbounds nuw i8, ptr %"new::Array", i64 8
  store ptr %memoryref_data134, ptr %"new::Array", align 8
  store ptr %"Memory{Int64}[]", ptr %13, align 8
  %"new::Array.size_ptr" = getelementptr inbounds nuw i8, ptr %"new::Array", i64 16
  store i64 %.size_ptr22.copyload.pre, ptr %"new::Array.size_ptr", align 8
  br label %L190

L190:                                             ; preds = %pass, %L103, %L69, %L22
  %value_phi25 = phi ptr [ %"new::Array", %L103 ], [ %2, %L69 ], [ %2, %L22 ], [ %2, %pass ]
  %14 = getelementptr inbounds nuw i8, ptr %"new::SubArray", i64 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %14, i8 0, i64 16, i1 false)
  %"#self#::#makeprobes##79#makeprobes##80.u" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80" unordered, align 8
  %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.u", i64 16
  %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr.copyload" = load i64, ptr %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr", align 8
  %.not166 = icmp eq i64 %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr.copyload", 0
  br i1 %.not166, label %L302, label %L201

L201:                                             ; preds = %L190
  %value_phi25.size_ptr64 = getelementptr inbounds nuw i8, ptr %value_phi25, i64 16
  %value_phi25.size_ptr64.copyload = load i64, ptr %value_phi25.size_ptr64, align 8
  %15 = icmp eq i64 %value_phi25.size_ptr64.copyload, 0
  br i1 %15, label %L299, label %L212

L212:                                             ; preds = %L201
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage68" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x" unordered, align 8
  %16 = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage68", i64 8
  %17 = load ptr, ptr %16, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage68.ref.mem.ptr_ptr" = getelementptr inbounds nuw i8, ptr %17, i64 8
  %bitcast69 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage68.ref.mem.ptr_ptr", align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active_ptr71" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x", i64 32
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active72" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active_ptr71" unordered, align 8
  %18 = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active72", i64 8
  %19 = load ptr, ptr %18, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active72.ref.mem.ptr_ptr" = getelementptr inbounds nuw i8, ptr %19, i64 8
  %bitcast73 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.active72.ref.mem.ptr_ptr", align 8
  %20 = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.u", i64 8
  %21 = load ptr, ptr %20, align 8
  %"#self#::#makeprobes##79#makeprobes##80.u.ref.mem.ptr_ptr" = getelementptr inbounds nuw i8, ptr %21, i64 8
  %bitcast82 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.u.ref.mem.ptr_ptr", align 8
  %22 = icmp ne ptr %bitcast69, %bitcast82
  %23 = icmp ne ptr %bitcast73, %bitcast82
  %or.cond = select i1 %22, i1 %23, i1 false
  br i1 %or.cond, label %L260, label %nonemptymem91

L260:                                             ; preds = %L212
  %24 = getelementptr inbounds nuw i8, ptr %value_phi25, i64 8
  %25 = load ptr, ptr %24, align 8
  %value_phi25.ref79.mem.ptr_ptr = getelementptr inbounds nuw i8, ptr %25, i64 8
  %bitcast80 = load ptr, ptr %value_phi25.ref79.mem.ptr_ptr, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position_ptr75" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x", i64 40
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position76" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position_ptr75" unordered, align 8
  %26 = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position76", i64 8
  %27 = load ptr, ptr %26, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position76.ref.mem.ptr_ptr" = getelementptr inbounds nuw i8, ptr %27, i64 8
  %bitcast77 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.position76.ref.mem.ptr_ptr", align 8
  %.not167 = icmp ne ptr %bitcast77, %bitcast82
  %.not168 = icmp ne ptr %bitcast80, %bitcast82
  %narrow.not169 = select i1 %.not167, i1 %.not168, i1 false
  br i1 %narrow.not169, label %L299, label %nonemptymem91

L278:                                             ; preds = %nonemptymem91
  %memoryref_data119 = load ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.u", align 8
  %28 = shl nuw nsw i64 %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr.copyload", 3
  %ptls_field95 = getelementptr inbounds nuw i8, ptr %tls_pgcstack, i64 16
  %ptls_load96 = load ptr, ptr %ptls_field95, align 8
  %gc_slot_addr_5188 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 56
  store ptr %value_phi25, ptr %gc_slot_addr_5188, align 8
  %gc_slot_addr_4189 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 48
  store ptr %21, ptr %gc_slot_addr_4189, align 8
  %"Memory{Float64}[]" = call noalias nonnull align 16 dereferenceable(16) ptr @jl_alloc_genericmemory_unchecked(ptr %ptls_load96, i64 %28, ptr nonnull @"+Core.GenericMemory#3808.jit") #14
  store i64 %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr.copyload", ptr %"Memory{Float64}[]", align 8
  %memory_data_ptr98 = getelementptr inbounds nuw i8, ptr %"Memory{Float64}[]", i64 8
  %memoryref_data112 = load ptr, ptr %memory_data_ptr98, align 8
  call void @llvm.memmove.p0.p0.i64(ptr nonnull align 1 %memoryref_data112, ptr align 1 %memoryref_data119, i64 %28, i1 false)
  %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr106.copyload" = load i64, ptr %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr", align 8
  store ptr %"Memory{Float64}[]", ptr %gc_slot_addr_4189, align 8
  %ptls_load209 = load ptr, ptr %ptls_field95, align 8
  %"new::Array110" = call noalias nonnull align 8 dereferenceable(32) ptr @ijl_gc_small_alloc(ptr %ptls_load209, i32 408, i32 32, i64 125309882081360) #10
  %"new::Array110.tag_addr" = getelementptr inbounds i8, ptr %"new::Array110", i64 -8
  store atomic i64 125309882081360, ptr %"new::Array110.tag_addr" unordered, align 8
  %29 = getelementptr inbounds nuw i8, ptr %"new::Array110", i64 8
  store ptr %memoryref_data112, ptr %"new::Array110", align 8
  store ptr %"Memory{Float64}[]", ptr %29, align 8
  %"new::Array110.size_ptr" = getelementptr inbounds nuw i8, ptr %"new::Array110", i64 16
  store i64 %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr106.copyload", ptr %"new::Array110.size_ptr", align 8
  br label %L299

L299:                                             ; preds = %L278, %L260, %L201
  %value_phi111 = phi ptr [ %"new::Array110", %L278 ], [ %"#self#::#makeprobes##79#makeprobes##80.u", %L260 ], [ %"#self#::#makeprobes##79#makeprobes##80.u", %L201 ]
  store ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x", ptr %0, align 8
  %30 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 40
  store ptr %value_phi25, ptr %30, align 8
  %gc_slot_addr_4192 = getelementptr inbounds nuw i8, ptr %gcframe1, i64 48
  store ptr %value_phi111, ptr %gc_slot_addr_4192, align 8
  call void @"j_copyto_unaliased!_3810"(ptr noalias nocapture noundef nonnull sret({ ptr, [1 x ptr], i64, i64 }) align 8 %sret_box, ptr noalias nocapture noundef nonnull %1, ptr nocapture nonnull readonly %"new::SubArray", ptr nocapture nonnull readonly %0, ptr nonnull %value_phi111)
  br label %L302

L302:                                             ; preds = %L299, %L190
  %frame.prev211 = load ptr, ptr %frame.prev, align 8
  store ptr %frame.prev211, ptr %tls_pgcstack, align 8
  ret void

fail:                                             ; preds = %top
  %jl_undefref_exception = load ptr, ptr @jl_undefref_exception, align 8
  call void @ijl_throw(ptr nonnull %jl_undefref_exception)
  unreachable

pass:                                             ; preds = %top
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage" = load atomic ptr, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x" unordered, align 8
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage.size_ptr" = getelementptr inbounds nuw i8, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage", i64 16
  %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage.size_ptr.copyload" = load i64, ptr %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage.size_ptr", align 8
  %31 = icmp eq i64 %"#self#::#makeprobes##79#makeprobes##80.#3831#x.storage.size_ptr.copyload", 0
  br i1 %31, label %L190, label %L22

nonemptymem:                                      ; preds = %L69, %L27
  %32 = icmp ult i64 %.size_ptr.copyload, 1152921504606846976
  br i1 %32, label %L103, label %fail14

fail14:                                           ; preds = %nonemptymem
  call void @jl_argument_error(ptr nonnull @"_j_str_invalid GenericMemory siz...#1")
  unreachable

nonemptymem91:                                    ; preds = %L260, %L212
  %33 = icmp ult i64 %"#self#::#makeprobes##79#makeprobes##80.u.size_ptr.copyload", 1152921504606846976
  br i1 %33, label %L278, label %fail92

fail92:                                           ; preds = %nonemptymem91
  call void @jl_argument_error(ptr nonnull @"_j_str_invalid GenericMemory siz...#1")
  unreachable
}
