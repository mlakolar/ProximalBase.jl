	push	rbp
	mov	rbp, rsp
	push	r15
	push	r14
	push	r12
	push	rbx
	sub	rsp, 176
	vxorps	xmm0, xmm0, xmm0
	vmovups	ymmword ptr [rbp - 144], ymm0
	vmovups	ymmword ptr [rbp - 112], ymm0
	mov	qword ptr [rbp - 144], 24
	mov	rax, qword ptr [r13]
	mov	qword ptr [rbp - 136], rax
	lea	rax, [rbp - 144]
	mov	qword ptr [r13], rax
	mov	rax, qword ptr [r13 + 16]
	mov	rax, qword ptr [rax + 16]
	mov	rax, qword ptr [rax]
	mov	r8, qword ptr [rdi + 8]
	mov	rax, qword ptr [r8 + 8]
	mov	rax, qword ptr [rax]
	mov	rbx, qword ptr [rax]
	test	rbx, rbx
	je	L753
	mov	rax, qword ptr [r8]
	cmp	qword ptr [rax + 16], 0
	je	L379
	mov	r12, qword ptr [rbx + 16]
	test	r12, r12
	je	L379
	mov	rdx, qword ptr [rax + 8]
	mov	rax, qword ptr [rbx + 8]
	mov	rcx, qword ptr [rax + 8]
	cmp	qword ptr [rdx + 8], rcx
	je	L179
	mov	rdx, qword ptr [r8 + 32]
	mov	rdx, qword ptr [rdx + 8]
	cmp	qword ptr [rdx + 8], rcx
	je	L179
	mov	rdx, qword ptr [r8 + 40]
	mov	rdx, qword ptr [rdx + 8]
	cmp	qword ptr [rdx + 8], rcx
	jne	L379
L179:
	mov	qword ptr [rbp - 72], r8
	mov	qword ptr [rbp - 64], rdi
	movabs	r14, 124095041939520
	mov	rcx, r12
	shr	rcx, 60
	jne	L806
	mov	rcx, qword ptr [rbx]
	mov	qword ptr [rbp - 48], rcx
	lea	rsi, [8*r12]
	mov	qword ptr [rbp - 40], rsi
	mov	rdi, qword ptr [r13 + 16]
	mov	qword ptr [rbp - 88], rbx
	mov	qword ptr [rbp - 96], rax
	lea	rdx, [r14 + 550994608]
	movabs	rax, offset jl_alloc_genericmemory_unchecked
	vzeroupper
	call	rax
	mov	r15, rax
	mov	qword ptr [rax], r12
	mov	rdi, qword ptr [rax + 8]
	mov	qword ptr [rbp - 56], rdi
	movabs	rax, 124095829675392
	mov	rsi, qword ptr [rbp - 48]
	mov	rdx, qword ptr [rbp - 40]
	call	rax
	mov	r12, qword ptr [rbx + 16]
	mov	qword ptr [rbp - 88], 0
	mov	qword ptr [rbp - 96], r15
	mov	rdi, qword ptr [r13 + 16]
	add	r14, 491870592
	movabs	rax, offset ijl_gc_small_alloc
	mov	esi, 408
	mov	edx, 32
	mov	rcx, r14
	call	rax
	mov	rbx, rax
	mov	qword ptr [rax - 8], r14
	mov	rax, qword ptr [rbp - 56]
	mov	qword ptr [rbx], rax
	mov	qword ptr [rbx + 8], r15
	mov	qword ptr [rbx + 16], r12
	mov	rdi, qword ptr [rbp - 64]
	mov	r8, qword ptr [rbp - 72]
L379:
	vxorps	xmm0, xmm0, xmm0
	vmovups	xmmword ptr [rbp - 160], xmm0
	mov	rcx, qword ptr [rdi]
	mov	r12, qword ptr [rcx + 16]
	test	r12, r12
	je	L723
	cmp	qword ptr [rbx + 16], 0
	je	L673
	mov	rax, qword ptr [r8]
	mov	rsi, qword ptr [rax + 8]
	mov	rax, qword ptr [rcx + 8]
	mov	rdx, qword ptr [rax + 8]
	cmp	qword ptr [rsi + 8], rdx
	je	L481
	mov	rsi, qword ptr [r8 + 32]
	mov	rsi, qword ptr [rsi + 8]
	cmp	qword ptr [rsi + 8], rdx
	je	L481
	mov	rsi, qword ptr [r8 + 40]
	mov	rsi, qword ptr [rsi + 8]
	cmp	qword ptr [rsi + 8], rdx
	je	L481
	mov	rsi, qword ptr [rbx + 8]
	cmp	qword ptr [rsi + 8], rdx
	jne	L673
L481:
	mov	qword ptr [rbp - 72], r8
	mov	rdx, r12
	shr	rdx, 60
	jne	L781
	mov	rdx, qword ptr [rcx]
	mov	qword ptr [rbp - 56], rdx
	lea	rsi, [8*r12]
	mov	qword ptr [rbp - 40], rsi
	mov	rdi, qword ptr [r13 + 16]
	mov	qword ptr [rbp - 88], rbx
	mov	qword ptr [rbp - 96], rax
	movabs	r14, 124095041939520
	lea	rdx, [r14 + 550858752]
	movabs	rax, offset jl_alloc_genericmemory_unchecked
	mov	qword ptr [rbp - 48], rcx
	vzeroupper
	call	rax
	mov	r15, rax
	mov	qword ptr [rax], r12
	mov	rdi, qword ptr [rax + 8]
	mov	qword ptr [rbp - 64], rdi
	movabs	rax, 124095829675392
	mov	rsi, qword ptr [rbp - 56]
	mov	rdx, qword ptr [rbp - 40]
	call	rax
	mov	rax, qword ptr [rbp - 48]
	mov	r12, qword ptr [rax + 16]
	mov	qword ptr [rbp - 96], r15
	mov	rdi, qword ptr [r13 + 16]
	add	r14, 492664848
	movabs	rax, offset ijl_gc_small_alloc
	mov	esi, 408
	mov	edx, 32
	mov	rcx, r14
	call	rax
	mov	rcx, rax
	mov	qword ptr [rax - 8], r14
	mov	rax, qword ptr [rbp - 64]
	mov	qword ptr [rcx], rax
	mov	qword ptr [rcx + 8], r15
	mov	qword ptr [rcx + 16], r12
	mov	r8, qword ptr [rbp - 72]
L673:
	lea	rdx, [rbp - 112]
	lea	rdi, [rbp - 128]
	mov	qword ptr [rbp - 112], r8
	mov	qword ptr [rbp - 104], rbx
	mov	qword ptr [rbp - 96], rcx
	movabs	r8, offset "copyto_unaliased!"
	lea	rax, [rbp - 208]
	lea	rsi, [rbp - 176]
	vzeroupper
	call	r8
L723:
	mov	rax, qword ptr [rbp - 136]
	mov	qword ptr [r13], rax
	add	rsp, 176
	pop	rbx
	pop	r12
	pop	r14
	pop	r15
	pop	rbp
	vzeroupper
	ret
L753:
	movabs	rax, offset jl_undefref_exception
	mov	rdi, qword ptr [rax]
	movabs	rax, offset ijl_throw
	vzeroupper
	call	rax
L781:
	movabs	rax, offset jl_argument_error
	movabs	rdi, 124095041939520
	vzeroupper
	call	rax
L806:
	movabs	rax, offset jl_argument_error
	mov	rdi, r14
	vzeroupper
	call	rax
	nop	dword ptr [rax + rax]
