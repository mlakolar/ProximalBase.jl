using BenchmarkTools,LinearAlgebra,InteractiveUtils,SHA
BLAS.set_num_threads(1)
Base.include(Main,joinpath(ARGS[1],"src","ProximalBase.jl"))
module Suite
const PB=Main.ProximalBase
include("probes.jl")
end
PB=Main.ProximalBase
probes=vcat(Suite.makeprobes(Float32),Suite.makeprobes(Float64))
filter!(p->occursin(r"Float64/blockview/(arbitrary|reversed)/write_inactive",p.id),probes)
mkpath(ARGS[2])
open(joinpath(ARGS[2],"diagnostics.txt"),"w") do io
for p in probes
 println(io,"CASE ",p.id)
 println(io,"closure fields: ",fieldnames(typeof(p.op)))
 x=nothing;u=nothing
 for f in fieldnames(typeof(p.op))
  val=getfield(p.op,f)
  val isa PB.BlockIterate && (x=val)
  val isa Vector{Float64} && (u=val)
 end
 x===nothing && error("no captured block owner")
 u===nothing && error("no captured numerical source")
 for rep in 1:1000
  p.setup()
  @assert PB.nactive(x)==0
  @assert !PB.isactive(x,1)
  @assert all(iszero,x.storage)
  @assert all(iszero,x.position)
  p.op()
  @assert PB.nactive(x)==1
  @assert PB.isactive(x,1)
  @assert collect(PB.activecoordinates(x))==[1]
  @assert collect(PB.blockview(x,1))==u
 end
 p.setup()
 v=PB.blockview(x,1)
 println(io,"1000 setup/op state checks pass; target inactive and zero before each op; nactive1/value u after")
 println(io,"alias source-owner: ",Base.mightalias(u,x)," source-view: ",Base.mightalias(u,v))
 println(io,"u pointer modulo64: ",UInt(pointer(u))%64," storage modulo64: ",UInt(pointer(x.storage))%64," group ids modulo64: ",UInt(pointer(x.groups[1]))%64)
 println(io,"copyto dispatch: ",which(copyto!,(typeof(v),typeof(u))))
 println(io,"owner setindex dispatch: ",which(setindex!,(typeof(x),Float64,Int)))
 println(io,"activate dispatch: ",which(PB.activate!,(typeof(x),Int)))
 println(io,"op inferred return: ",Base.return_types(p.op,Tuple{}))
 stem=replace(p.id,'/'=>'_')
 types=(typeof(IndexStyle(v)),typeof(v),typeof(IndexStyle(u)),typeof(u))
 println(io,"unalias-copy dispatch: ",which(Base.copyto_unaliased!,types))
 open(joinpath(ARGS[2],stem*"_kernel.ll"),"w") do target
  code_llvm(target,Base.copyto_unaliased!,types;debuginfo=:none,dump_module=false,optimize=true)
 end
 open(joinpath(ARGS[2],stem*"_kernel.s"),"w") do target
  code_native(target,Base.copyto_unaliased!,types;debuginfo=:none,dump_module=false,syntax=:intel)
 end
 open(joinpath(ARGS[2],stem*".ll"),"w") do target
  code_llvm(target,p.op,Tuple{};debuginfo=:none,dump_module=false,optimize=true)
 end
 open(joinpath(ARGS[2],stem*".s"),"w") do target
  code_native(target,p.op,Tuple{};debuginfo=:none,dump_module=false,syntax=:intel)
 end
end
end
