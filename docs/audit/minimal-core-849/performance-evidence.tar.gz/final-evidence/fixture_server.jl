using BenchmarkTools, LinearAlgebra, Statistics, SHA
BLAS.set_num_threads(1)
Base.include(Main,joinpath(ARGS[1],"src","ProximalBase.jl"))
module Suite
const PB=Main.ProximalBase
include("probes.jl")
end
PB=Main.ProximalBase
held=Any[];fixtures=Any[]
for fixture in 1:24
    for j in 1:(fixture%7+1)
        push!(held,zeros(UInt8,2^(6+(fixture*17+j)%7)))
    end
    suite=Suite.makeprobes(Float64)
    push!(held,suite)
    for p in suite
        occursin(r"Float64/blockview/(arbitrary|reversed)/write_inactive",p.id) || continue
        x=nothing;u=nothing
        for f in fieldnames(typeof(p.op))
            val=getfield(p.op,f)
            val isa PB.BlockIterate && (x=val)
            val isa Vector{Float64} && (u=val)
        end
        x===nothing && error("no block owner")
        u===nothing && error("no source vector")
        for _ in 1:10
            p.setup();@assert PB.nactive(x)==0;@assert !PB.isactive(x,1)
            @assert all(iszero,x.storage);@assert all(iszero,x.position)
            @assert !Base.mightalias(x,u)
            p.op();@assert PB.nactive(x)==1;@assert collect(PB.activecoordinates(x))==[1]
            @assert collect(PB.blockview(x,1))==u
        end
        push!(fixtures,(fixture,p,x,u))
    end
end
function bench(p)
    op=p.op;prep=p.setup
    b=@benchmarkable $op() setup=($prep()) evals=1 samples=180 seconds=.04
    for _ in 1:3; prep();op();end
    run(b)
end
foreach(f->bench(f[2]),fixtures)
println("READY");flush(stdout)
for line in eachline(stdin)
    open(line,"w") do io
        for (id,p,x,u) in fixtures
            t=bench(p);e=median(t)
            println(io,p.id,',',id,',',e.time,',',minimum(t).time,',',e.memory,',',e.allocs,',',UInt(pointer(u))%64,',',UInt(pointer(x.storage))%64,',',UInt(pointer(x.groups[1]))%64,',',UInt(pointer(u))%4096,',',UInt(pointer(x.storage))%4096,',',UInt(pointer(x.groups[1]))%4096)
        end
    end
    println("DONE");flush(stdout)
end
