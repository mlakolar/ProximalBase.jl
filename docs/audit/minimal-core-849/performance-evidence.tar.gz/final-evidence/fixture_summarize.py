import csv,statistics as st,pathlib,random,json
root=pathlib.Path('/tmp/pb849-performance/fixture-results');rows=list(csv.DictReader(open(root/'raw.csv')))
by={}
for r in rows:by.setdefault(r['case'],{}).setdefault(int(r['fixture']),{}).setdefault(int(r['round']),{})[r['side']]=r
rng=random.Random(849);summary=[];details=[]
for case,fixtures in by.items():
 ratios=[];controls=[]
 for fixture,rounds in fixtures.items():
  ratio=st.median(float(r['B']['median_ns'])/float(r['A']['median_ns']) for r in rounds.values());aa=st.median(float(r['Acontrol']['median_ns'])/float(r['A']['median_ns']) for r in rounds.values())
  ratios.append(ratio);controls.append(aa)
  d=dict(case=case,fixture=fixture,ratio=ratio,aa_ratio=aa)
  for side in ('A','B','Acontrol'):
   sample=next(iter(rounds.values()))[side]
   d[side+'_ns']=st.median(float(r[side]['median_ns']) for r in rounds.values())
   for key in ('u_mod64','storage_mod64','indices_mod64','u_mod4096','storage_mod4096','indices_mod4096'):d[side+'_'+key]=int(sample[key])
  details.append(d)
 boot=sorted(st.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
 acboot=sorted(st.median(rng.choices(controls,k=len(controls))) for _ in range(10000))
 item=dict(case=case,independent_fixtures=len(fixtures),rounds_per_fixture=7,median_ratio=st.median(ratios),ci_low=boot[250],ci_high=boot[9749],min_fixture_ratio=min(ratios),max_fixture_ratio=max(ratios),fixtures_above5=sum(x>1.05 for x in ratios),fixtures_below_minus5=sum(x<.95 for x in ratios),aa_ratio=st.median(controls),aa_ci_low=acboot[250],aa_ci_high=acboot[9749],aa_min=min(controls),aa_max=max(controls),allocation_regressions=sum(int(r['B']['memory'])>int(r['A']['memory']) or int(r['B']['allocs'])>int(r['A']['allocs']) for rounds in fixtures.values() for r in rounds.values()))
 summary.append(item)
print(json.dumps(summary,indent=2));json.dump(summary,open(root/'summary.json','w'),indent=2)
with open(root/'fixtures.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=details[0].keys());w.writeheader();w.writerows(details)
with open(root/'summary.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=summary[0].keys());w.writeheader();w.writerows(summary)
print('raw rows',len(rows))
