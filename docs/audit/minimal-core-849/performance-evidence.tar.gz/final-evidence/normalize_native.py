import re,hashlib,pathlib,json
root=pathlib.Path(__file__).resolve().parent
out={}
for layout in ('arbitrary','reversed'):
 stem='Float64_blockview_'+layout+'_write_inactive_kernel.s'
 normalized=[]
 for side in ('baseline','candidate'):
  text=(root/('attribution-'+side)/stem).read_text()
  text=re.sub(r'(?m)(\bmovabs\s+\w+,\s+)\d{9,}',r'\1<relocated-address>',text)
  (root/('attribution-'+side)/(stem+'.normalized')).write_text(text)
  normalized.append(text)
 out[layout]={'native_equal_after_absolute_address_normalization':normalized[0]==normalized[1],'baseline_normalized_sha256':hashlib.sha256(normalized[0].encode()).hexdigest(),'candidate_normalized_sha256':hashlib.sha256(normalized[1].encode()).hexdigest(),'rule':'replace only decimal absolute movabs operands of 9+ digits; preserve instruction order, registers, branch/stack offsets and all other constants'}
print(json.dumps(out,indent=2));(root/'native-attribution.json').write_text(json.dumps(out,indent=2))
