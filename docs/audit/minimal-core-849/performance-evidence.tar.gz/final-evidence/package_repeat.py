import subprocess,os,pathlib,csv,json,hashlib,datetime
root=pathlib.Path('/tmp/pb849-performance');out=root/'package-results';out.mkdir(exist_ok=True)
servers={}
paths={'A':'/tmp/pb849-baseline','B':str(root/'candidate-snapshot'),'Acontrol':'/tmp/pb849-baseline'}
env=dict(os.environ,JULIA_DEPOT_PATH='/tmp/pb848-verify-depot')
for label,path in paths.items():
 cmd=['/tmp/julia-1.13.3/bin/julia','--startup-file=no','--threads=1','--check-bounds=no','--project='+str(root),str(root/'package_server.jl'),path]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(out/(label+'-stderr.log'),'w'),env=env,text=True,bufsize=1)
 servers[label]=p
 while True:
  line=p.stdout.readline()
  if line.strip()=='READY': break
  if not line: raise RuntimeError((label,p.poll()))
 print(label,'ready',flush=True)
provenance={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roles':paths,'namespace':'Main.ProximalBase + Main.Suite in each independent persistent process','rounds':31,'same_flags':'Julia1.13.3 --startup-file=no --threads=1 --check-bounds=no BLAS1','hashes':{}}
for label,path in paths.items():
 files=sorted(pathlib.Path(path,'src').rglob('*.jl'))
 provenance['hashes'][label]=hashlib.sha256('\n'.join(str(p.relative_to(path))+':'+hashlib.sha256(p.read_bytes()).hexdigest() for p in files).encode()).hexdigest()
for name in ['package_server.jl','package_repeat.py','probes.jl','Project.toml','Manifest.toml']:
 provenance[name+'_sha256']=hashlib.sha256((root/name).read_bytes()).hexdigest()
json.dump(provenance,open(out/'provenance.json','w'),indent=2)
with open(out/'raw.csv','w') as f:
 w=csv.writer(f);w.writerow(['case','round','order','side','median_ns','min_ns','memory','allocs'])
 for round in range(1,32):
  order=['A','B','Acontrol'] if round%2 else ['Acontrol','B','A']
  for ordinal,label in enumerate(order,1):
   temp=out/'batch.csv';p=servers[label]
   p.stdin.write(str(temp)+'\n');p.stdin.flush()
   assert p.stdout.readline().strip()=='DONE'
   for row in csv.reader(open(temp)):w.writerow([row[0],round,ordinal,label]+row[1:])
  f.flush()
 print('31 package-context rounds complete',flush=True)
for p in servers.values():p.stdin.close();p.wait()
