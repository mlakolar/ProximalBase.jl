using BenchmarkTools, LinearAlgebra, Statistics, SHA
BLAS.set_num_threads(1)
Base.include(Main,joinpath(ARGS[1],"src","ProximalBase.jl"))
module Suite
const PB=Main.ProximalBase
include("probes.jl")
end
probes=vcat(Suite.makeprobes(Float32),Suite.makeprobes(Float64))
filter!(p->occursin(r"Float32/symmetric/full_sweep|Float64/block/l1_prox",p.id),probes)
function bench(p)
    op=p.op;prep=p.setup
    b=@benchmarkable $op() setup=($prep()) evals=1 samples=180 seconds=.04
    for _ in 1:3; prep();op();end
    run(b)
end
foreach(bench,probes)
println("READY");flush(stdout)
for line in eachline(stdin)
    open(line,"w") do io
        for p in probes
            t=bench(p);e=median(t)
            println(io,p.id,',',e.time,',',minimum(t).time,',',e.memory,',',e.allocs)
        end
    end
    println("DONE");flush(stdout)
end
